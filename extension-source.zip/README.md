# localized-offensive-word-filter
A browser extension that helps to filter swahili and English offensive words.
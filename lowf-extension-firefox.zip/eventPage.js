/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 9);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.dynamicList = dynamicList;
exports.escapeHTML = escapeHTML;
exports.exportToFile = exportToFile;
exports.getVersion = getVersion;
exports.isVersionOlder = isVersionOlder;
exports.readFile = readFile;
exports.removeFromArray = removeFromArray;

/* istanbul ignore next */
function dynamicList(list, selectEm, title) {
  let options = '';

  if (title !== undefined) {
    options = '<option value="" disabled selected>' + title + '</option>';
  }

  for (let i = 0; i < list.length; i++) {
    options += '<option value="' + list[i] + '">' + list[i] + '</option>';
  }

  document.getElementById(selectEm).innerHTML = options;
}

function escapeHTML(str) {
  return str.replace(/([<>&"'])/g, (match, p1) => ({
    '<': '&lt;',
    '>': '&gt;',
    '&': '&amp;',
    '"': '&quot;',
    "'": '&apos;'
  })[p1]);
}

function exportToFile(dataStr, fileName = 'data.txt') {
  let dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
  let linkElement = document.createElement('a');
  linkElement.setAttribute('href', dataUri);
  linkElement.setAttribute('download', fileName);
  linkElement.click();
  linkElement.remove();
} // /^\d+\.\d+\.\d+$/


function getVersion(version) {
  let versionValues = version.split('.');
  return {
    major: parseInt(versionValues[0]),
    minor: parseInt(versionValues[1]),
    patch: parseInt(versionValues[2])
  };
} // Is the provided version lower than the minimum version?


function isVersionOlder(version, minimum) {
  if (version.major < minimum.major) {
    return true;
  } else if (version.major == minimum.major && version.minor < minimum.minor) {
    return true;
  } else if (version.major == minimum.major && version.minor == minimum.minor && version.patch < minimum.patch) {
    return true;
  }

  return false;
}

function readFile(file) {
  return new Promise((resolve, reject) => {
    let fr = new FileReader();

    fr.onload = () => {
      resolve(fr.result);
    };

    fr.readAsText(file);
  });
}

function removeFromArray(array, element) {
  return array.filter(e => e !== element);
}

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _config = _interopRequireDefault(__webpack_require__(2));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class WebConfig extends _config.default {
  static async build(keys) {
    let asyncResult = await WebConfig.getConfig(keys);
    let instance = new WebConfig(asyncResult);
    return instance;
  } // Call build() to create a new instance


  constructor(asyncParam) {
    super(asyncParam);
  } // Compile words


  static combineWords(items) {
    items.words = {};

    if (items._words0 !== undefined) {
      // Find all _words* to combine
      let wordKeys = Object.keys(items).filter(function (key) {
        return _config.default._wordsPattern.test(key);
      }); // Add all _words* to words and remove _words*

      wordKeys.forEach(function (key) {
        Object.assign(items.words, items[key]);
        delete items[key];
      });
    } // console.log('combineWords', items); // DEBUG

  } // Persist all configs from defaults and split _words*


  dataToPersist() {
    let self = this;
    let data = {}; // Save all settings using keys from _defaults

    Object.keys(_config.default._defaults).forEach(function (key) {
      if (self[key] !== undefined) {
        data[key] = self[key];
      }
    });

    if (self.words) {
      // Split words back into _words* for storage
      let splitWords = self.splitWords();
      Object.keys(splitWords).forEach(function (key) {
        data[key] = splitWords[key];
      });
      let wordKeys = Object.keys(self).filter(function (key) {
        return _config.default._wordsPattern.test(key);
      });
      wordKeys.forEach(function (key) {
        data[key] = self[key];
      });
    } // console.log('dataToPersist', data); // DEBUG - Config


    return data;
  } // Async call to get provided keys (or default keys) from chrome storage
  // TODO: Keys: Doesn't support getting words


  static getConfig(keys) {
    return new Promise(function (resolve, reject) {
      // Generate a request to use with chrome.storage
      let request = null;

      if (keys !== undefined) {
        request = {};

        for (let k of keys) {
          request[k] = _config.default._defaults[k];
        }
      }

      chrome.storage.sync.get(request, function (items) {
        // Ensure defaults for undefined settings
        Object.keys(_config.default._defaults).forEach(function (defaultKey) {
          if (request == null || Object.keys(request).includes(defaultKey)) {
            if (items[defaultKey] === undefined) {
              items[defaultKey] = _config.default._defaults[defaultKey];
            }
          }
        }); // Add words if requested, and provide _defaultWords if needed

        if (keys === undefined || keys.includes('words')) {
          // Use default words if none were provided
          if (items._words0 === undefined || Object.keys(items._words0).length == 0) {
            items._words0 = _config.default._defaultWords;
          }

          WebConfig.combineWords(items);
        }

        resolve(items);
      });
    });
  }

  removeProp(prop) {
    chrome.storage.sync.remove(prop);
    delete this[prop];
  }

  reset() {
    return new Promise(function (resolve, reject) {
      chrome.storage.sync.clear(function () {
        resolve(chrome.runtime.lastError ? 1 : 0);
      });
    });
  } // Pass a key to save only that key, otherwise it will save everything


  save(prop) {
    let data = {};
    prop ? data[prop] = this[prop] : data = this.dataToPersist();
    return new Promise(function (resolve, reject) {
      chrome.storage.sync.set(data, function () {
        resolve(chrome.runtime.lastError ? 1 : 0);
      });
    });
  }

  splitWords() {
    let self = this;
    let currentContainerNum = 0;
    let currentWordNum = 0; // let wordsLength = JSON.stringify(self.words).length;
    // let wordContainers = Math.ceil(wordsLength/Config._maxBytes);
    // let wordsNum = Object.keys(self.words).length;

    let words = {};
    words[`_words${currentContainerNum}`] = {};
    Object.keys(self.words).sort().forEach(function (word) {
      if (currentWordNum == _config.default._maxWords) {
        currentContainerNum++;
        currentWordNum = 0;
        words[`_words${currentContainerNum}`] = {};
      }

      words[`_words${currentContainerNum}`][word] = self.words[word];
      currentWordNum++;
    });
    return words;
  }

}

exports.default = WebConfig;

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class Config {
  constructor(config) {
    _defineProperty(this, "advancedDomains", void 0);

    _defineProperty(this, "censorCharacter", void 0);

    _defineProperty(this, "censorFixedLength", void 0);

    _defineProperty(this, "customAudioSites", void 0);

    _defineProperty(this, "defaultSubstitution", void 0);

    _defineProperty(this, "defaultWordMatchMethod", void 0);

    _defineProperty(this, "defaultWordRepeat", void 0);

    _defineProperty(this, "disabledDomains", void 0);

    _defineProperty(this, "filterMethod", void 0);

    _defineProperty(this, "filterWordList", void 0);

    _defineProperty(this, "globalMatchMethod", void 0);

    _defineProperty(this, "muteAudio", void 0);

    _defineProperty(this, "muteAudioOnly", void 0);

    _defineProperty(this, "muteMethod", void 0);

    _defineProperty(this, "password", void 0);

    _defineProperty(this, "preserveCase", void 0);

    _defineProperty(this, "preserveFirst", void 0);

    _defineProperty(this, "preserveLast", void 0);

    _defineProperty(this, "showCounter", void 0);

    _defineProperty(this, "showSubtitles", void 0);

    _defineProperty(this, "showSummary", void 0);

    _defineProperty(this, "showUpdateNotification", void 0);

    _defineProperty(this, "substitutionMark", void 0);

    _defineProperty(this, "words", void 0);

    _defineProperty(this, "youTubeAutoSubsMin", void 0);

    if (typeof config === 'undefined') {
      throw new Error('Cannot be called directly. call build()');
    }

    for (let k in config) this[k] = config[k];
  }

  addWord(str, options) {
    str = str.trim().toLowerCase();

    if (Object.keys(this.words).includes(str)) {
      return false; // Already exists
    } else if (options) {
      options.sub = options.sub.trim().toLowerCase();
      this.words[str] = options;
      return true;
    } else {
      this.words[str] = {
        matchMethod: this.defaultWordMatchMethod,
        repeat: this.defaultWordRepeat,
        sub: ''
      };
      return true;
    }
  }

  repeatForWord(word) {
    if (this.words[word].repeat === true || this.words[word].repeat === false) {
      return this.words[word].repeat;
    } else {
      return this.defaultWordRepeat;
    }
  }

  sanitizeWords() {
    let sanitizedWords = {};
    Object.keys(this.words).sort().forEach(key => {
      sanitizedWords[key.trim().toLowerCase()] = this.words[key];
    });
    this.words = sanitizedWords;
  }

}

exports.default = Config;

_defineProperty(Config, "filterMethods", {
  censor: 0,
  substitute: 1,
  remove: 2
});

_defineProperty(Config, "matchMethods", {
  exact: 0,
  partial: 1,
  whole: 2,
  'Per-Word': 3,
  'RegExp': 4
});

_defineProperty(Config, "_defaults", {
  advancedDomains: [],
  censorCharacter: '',
  censorFixedLength: 0,
  customAudioSites: null,
  defaultSubstitution: '',
  defaultWordMatchMethod: 0,
  defaultWordRepeat: false,
  disabledDomains: [],
  filterMethod: 0,
  // ['Censor', 'Substitute', 'Remove'];
  filterWordList: true,
  globalMatchMethod: 3,
  // ['Exact', 'Partial', 'Whole', 'Per-Word', 'RegExp']
  muteAudio: false,
  // Filter audio
  muteAudioOnly: false,
  muteMethod: 0,
  // 0: Mute Tab, 1: Video Volume
  password: null,
  preserveCase: true,
  preserveFirst: true,
  preserveLast: false,
  showCounter: true,
  showSubtitles: 0,
  showSummary: true,
  showUpdateNotification: true,
  substitutionMark: false,
  youTubeAutoSubsMin: 0
});

_defineProperty(Config, "_maneno", {
  'ass': {
    matchMethod: 0,
    repeat: true,
    sub: 'butt'
  },
  'asses': {
    matchMethod: 0,
    repeat: false,
    sub: 'butts'
  },
  'asshole': {
    matchMethod: 1,
    repeat: true,
    sub: 'jerk'
  },
  'badass': {
    matchMethod: 1,
    repeat: true,
    sub: 'cool'
  },
  'bastard': {
    matchMethod: 1,
    repeat: true,
    sub: 'idiot'
  },
  'bitch': {
    matchMethod: 1,
    repeat: true,
    sub: 'bench'
  },
  'cocksucker': {
    matchMethod: 1,
    repeat: true,
    sub: 'suckup'
  },
  'cunt': {
    matchMethod: 1,
    repeat: true,
    sub: 'expletive'
  },
  'dammit': {
    matchMethod: 1,
    repeat: false,
    sub: 'dangit'
  },
  'damn': {
    matchMethod: 1,
    repeat: false,
    sub: 'dang'
  },
  'dumbass': {
    matchMethod: 1,
    repeat: true,
    sub: 'idiot'
  },
  'fag': {
    matchMethod: 0,
    repeat: true,
    sub: 'gay'
  },
  'faggot': {
    matchMethod: 1,
    repeat: true,
    sub: 'gay'
  },
  'fags': {
    matchMethod: 0,
    repeat: true,
    sub: 'gays'
  },
  'fuck': {
    matchMethod: 1,
    repeat: true,
    sub: 'freak'
  },
  'goddammit': {
    matchMethod: 1,
    repeat: true,
    sub: 'dangit'
  },
  'hell': {
    matchMethod: 0,
    repeat: true,
    sub: 'heck'
  },
  'jackass': {
    matchMethod: 1,
    repeat: true,
    sub: 'jerk'
  },
  'nigga': {
    matchMethod: 0,
    repeat: true,
    sub: 'bruh'
  },
  'nigger': {
    matchMethod: 0,
    repeat: true,
    sub: 'man'
  },
  'niggers': {
    matchMethod: 0,
    repeat: true,
    sub: 'people'
  },
  'piss': {
    matchMethod: 1,
    repeat: true,
    sub: 'pee'
  },
  'pissed': {
    matchMethod: 1,
    repeat: true,
    sub: 'ticked'
  },
  'pussies': {
    matchMethod: 0,
    repeat: true,
    sub: 'softies'
  },
  'pussy': {
    matchMethod: 0,
    repeat: true,
    sub: 'softie'
  },
  'shit': {
    matchMethod: 1,
    repeat: true,
    sub: 'crap'
  },
  'slut': {
    matchMethod: 1,
    repeat: true,
    sub: 'tramp'
  },
  'tits': {
    matchMethod: 1,
    repeat: true,
    sub: 'chest'
  },
  'twat': {
    matchMethod: 1,
    repeat: true,
    sub: 'dumbo'
  },
  'whore': {
    matchMethod: 1,
    repeat: true,
    sub: 'tramp'
  },
  'bolo': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'bwege': {
    matchMethod: 1,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'fala': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'fara': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'fira': {
    matchMethod: 1,
    repeat: true,
    sub: 'kinyume na maumbile'
  },
  'firwa': {
    matchMethod: 1,
    repeat: true,
    sub: 'kinyume na maumbile'
  },
  'kuma': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kike'
  },
  'kumalake': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'kumalamsenge': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'kumamae': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'kundu': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'Kusagana': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'Kutomba': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'Kutombana': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'Kahaba': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'malaya': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'matako': {
    matchMethod: 1,
    repeat: true,
    sub: 'makalio'
  },
  'mavuzi': {
    matchMethod: 1,
    repeat: true,
    sub: 'nywele za sehemu ya siri'
  },
  'mbolo': {
    matchMethod: 1,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'mboo': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'mfiraji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mfirwaji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mjanechuo': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mkundu': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'mngese': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'msagaji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'msenge': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mxenge': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'msengenyaji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mshenzi': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'nyoko': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'nyoo': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'pumbu': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'senge': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'shahawa': {
    matchMethod: 1,
    repeat: true,
    sub: 'manii'
  },
  'shenzi': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'tako': {
    matchMethod: 0,
    repeat: true,
    sub: 'kalio'
  },
  'tiana': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'tiwa': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'tomb': {
    matchMethod: 1,
    repeat: true,
    sub: 'tendo la ndoa'
  },
  'tomba': {
    matchMethod: 1,
    repeat: true,
    sub: 'tendo la ndoa'
  },
  'tombana': {
    matchMethod: 1,
    repeat: true,
    sub: 'tendo la ndoa'
  },
  'tombwa': {
    matchMethod: 1,
    repeat: true,
    sub: 'tendo la ndoa'
  },
  'uboo': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'ubolo': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'kisimi': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'kicmi': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'kixmi': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'usenge': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'ufiraji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'ufirwaji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'tahira': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  }
});

_defineProperty(Config, "_defaultWords", Config._maneno);

_defineProperty(Config, "_filterMethodNames", ['Censor', 'Substitute', 'Remove']);

_defineProperty(Config, "_matchMethodNames", ['Exact', 'Partial', 'Whole', 'Per-Word', 'Regular-Expression']);

_defineProperty(Config, "_maxBytes", 6500);

_defineProperty(Config, "_maxWords", 100);

_defineProperty(Config, "_wordsPattern", /^_words\d+/);

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _helper = __webpack_require__(0);

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class Domain {
  constructor() {
    _defineProperty(this, "tab", void 0);

    _defineProperty(this, "url", void 0);

    _defineProperty(this, "hostname", void 0);
  }

  static domainMatch(domain, domains) {
    let result = false;

    for (let x = 0; x < domains.length; x++) {
      let domainRegex = new RegExp('(^|\.)' + domains[x], 'i');

      if (domainRegex.test(domain)) {
        result = true;
        break;
      }
    }

    return result;
  } // If a parent domain (example.com) is included, it will not match all subdomains.
  // If a subdomain is included, it will match itself and the parent, if present.


  static removeFromList(domain, domains) {
    let domainRegex;
    let newDomainsList = domains;

    for (let x = 0; x < domains.length; x++) {
      domainRegex = new RegExp('(^|\.)' + domains[x], 'i');

      if (domainRegex.test(domain)) {
        newDomainsList = (0, _helper.removeFromArray)(newDomainsList, domains[x]);
      }
    }

    return newDomainsList;
  }

  static getCurrentTab() {
    /* istanbul ignore next */
    return new Promise(function (resolve, reject) {
      chrome.tabs.query({
        active: true,
        currentWindow: true
      }, function (tabs) {
        resolve(tabs[0]);
      });
    });
  }

  async load() {
    this.tab = await Domain.getCurrentTab();
    this.url = new URL(this.tab.url);
    this.hostname = this.url.hostname;
  }

}

exports.default = Domain;

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _helper = __webpack_require__(0);

var _webConfig = _interopRequireDefault(__webpack_require__(1));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class DataMigration {
  // Migration required by any version less than this
  constructor(config) {
    _defineProperty(this, "cfg", void 0);

    this.cfg = config;
  }

  static async build() {
    let cfg = await _webConfig.default.build();
    return new DataMigration(cfg);
  }

  static migrationNeeded(oldVersion) {
    return (0, _helper.isVersionOlder)((0, _helper.getVersion)(oldVersion), (0, _helper.getVersion)(DataMigration.newestMigration));
  } // This will look at the version (from before the update) and perform data migrations if necessary
  // Only append so the order stays the same (oldest first).


  byVersion(oldVersion) {
    let version = (0, _helper.getVersion)(oldVersion);
    let migrated = false;

    if ((0, _helper.isVersionOlder)(version, (0, _helper.getVersion)('1.0.13'))) {
      migrated = true;
      this.moveToNewWordsStorage();
    }

    if ((0, _helper.isVersionOlder)(version, (0, _helper.getVersion)('1.1.0'))) {
      migrated = true;
      this.sanitizeWords();
    }

    if ((0, _helper.isVersionOlder)(version, (0, _helper.getVersion)('1.2.0'))) {
      migrated = true;
      this.singleWordSubstitution();
    }

    if ((0, _helper.isVersionOlder)(version, (0, _helper.getVersion)('2.1.4'))) {
      migrated = true;
      this.updateDefaultSubs();
    }

    return migrated;
  } // [2.1.4] - Update default sub values


  updateDefaultSubs() {
    let cfg = this.cfg;
    let updatedWords = {
      bastard: {
        original: 'jerk',
        update: 'idiot'
      },
      bitch: {
        original: 'jerk',
        update: 'bench'
      },
      cocksucker: {
        original: 'idiot',
        update: 'suckup'
      },
      cunt: {
        original: 'explative',
        update: 'expletive'
      },
      fag: {
        original: 'slur',
        update: 'gay'
      },
      faggot: {
        original: 'slur',
        update: 'gay'
      },
      fags: {
        original: 'slur',
        update: 'gays'
      },
      fala: {
        original: 'fudge',
        update: 'freak'
      },
      goddammit: {
        original: 'goshdangit',
        update: 'dangit'
      },
      jackass: {
        original: 'idiot',
        update: 'jerk'
      },
      nigga: {
        original: 'ethnic slur',
        update: 'bruh'
      },
      nigger: {
        original: 'ethnic slur',
        update: 'man'
      },
      niggers: {
        original: 'ethnic slurs',
        update: 'people'
      },
      tits: {
        original: 'explative',
        update: 'chest'
      },
      twat: {
        original: 'explative',
        update: 'dumbo'
      }
    };
    Object.keys(updatedWords).forEach(updatedWord => {
      if (cfg.words[updatedWord]) {
        let wordObj = cfg.words[updatedWord];

        if (wordObj.sub == updatedWords[updatedWord].original) {
          wordObj.sub = updatedWords[updatedWord].update;
        }
      }
    });
  } // [1.0.13] - updateRemoveWordsFromStorage - transition from previous words structure under the hood


  moveToNewWordsStorage() {
    chrome.storage.sync.get({
      'words': null
    }, function (oldWords) {
      if (oldWords.words) {
        chrome.storage.sync.set({
          '_words0': oldWords.words
        }, function () {
          if (!chrome.runtime.lastError) {
            chrome.storage.sync.remove('words', function () {// Removed old words
            });
          }
        });
      }
    });
  }

  runImportMigrations() {
    this.sanitizeWords(); // 1.1.0

    this.singleWordSubstitution(); // 1.2.0

    this.updateDefaultSubs(); // 2.1.4
  } // [1.1.0] - Downcase and trim each word in the list (NOTE: This MAY result in losing some words)


  sanitizeWords() {
    this.cfg.sanitizeWords();
  } // [1.2.0] - Change from a word having many substitutions to a single substitution ({words: []} to {sub: ''})


  singleWordSubstitution() {
    let cfg = this.cfg; // console.log('before', JSON.stringify(cfg.words));

    Object.keys(cfg.words).forEach(word => {
      let wordObj = cfg.words[word];

      if (wordObj.hasOwnProperty('words')) {
        // @ts-ignore: Old 'words' doesn't exist on Interface.
        wordObj.sub = wordObj.words[0] || ''; // @ts-ignore: Old 'words' doesn't exist on Interface.

        delete wordObj.words;
      }
    }); // console.log('after', JSON.stringify(cfg.words));
  }

}

exports.default = DataMigration;

_defineProperty(DataMigration, "newestMigration", '2.1.4');

/***/ }),
/* 5 */,
/* 6 */,
/* 7 */,
/* 8 */,
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _webConfig = _interopRequireDefault(__webpack_require__(1));

var _domain = _interopRequireDefault(__webpack_require__(3));

var _dataMigration = _interopRequireDefault(__webpack_require__(4));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

////
// Actions and messaging
// Actions for extension install or upgrade
chrome.runtime.onInstalled.addListener(function (details) {
  if (details.reason == 'install') {
    chrome.runtime.openOptionsPage();
  } else if (details.reason == 'update') {
    // var thisVersion = chrome.runtime.getManifest().version;
    // console.log('Updated from ' + details.previousVersion + ' to ' + thisVersion);
    // Open options page to show new features
    // chrome.runtime.openOptionsPage();
    // Run any data migrations on update
    updateMigrations(details.previousVersion); // Display update notification

    chrome.storage.sync.get({
      showUpdateNotification: true
    }, function (data) {
      if (data.showUpdateNotification) {
        chrome.notifications.create('extensionUpdate', {
          'type': 'basic',
          'title': 'Localized offensive filter',
          'message': 'Update installed, click for changelog.',
          'iconUrl': 'img/icon48.png',
          'isClickable': true
        });
      }
    });
  }
});
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.disabled === true) {
    chrome.browserAction.setIcon({
      path: 'img/icon19-disabled.png',
      tabId: sender.tab.id
    });
  } else {
    // Set badge color
    // chrome.browserAction.setBadgeBackgroundColor({ color: [138, 43, 226, 255], tabId: sender.tab.id }); // Blue Violet
    // chrome.browserAction.setBadgeBackgroundColor({ color: [85, 85, 85, 255], tabId: sender.tab.id }); // Grey (Default)
    // chrome.browserAction.setBadgeBackgroundColor({ color: [236, 147, 41, 255], tabId: sender.tab.id }); // Orange
    if (request.setBadgeColor) {
      if (request.mutePage) {
        chrome.browserAction.setBadgeBackgroundColor({
          color: [34, 139, 34, 255],
          tabId: sender.tab.id
        }); // Forest Green - Audio
      } else if (request.advanced) {
        chrome.browserAction.setBadgeBackgroundColor({
          color: [211, 45, 39, 255],
          tabId: sender.tab.id
        }); // Red - Advanced
      } else {
        chrome.browserAction.setBadgeBackgroundColor({
          color: [66, 133, 244, 255],
          tabId: sender.tab.id
        }); // Blue - Normal
      }
    } // Show count of words filtered on badge


    if (request.counter != undefined) {
      chrome.browserAction.setBadgeText({
        text: request.counter.toString(),
        tabId: sender.tab.id
      });
    } // Set mute state for tab


    if (request.mute != undefined) {
      chrome.tabs.update(sender.tab.id, {
        muted: request.mute
      });
    } // Unmute on page reload


    if (request.clearMute === true && sender.tab != undefined) {
      let {
        muted,
        reason,
        extensionId
      } = sender.tab.mutedInfo;

      if (muted && reason == 'extension' && extensionId == chrome.runtime.id) {
        chrome.tabs.update(sender.tab.id, {
          muted: false
        });
      }
    }
  }
}); ////
// Context menu
//
// Add selected word/phrase and reload page (unless already present)

async function addSelection(selection) {
  let cfg = await _webConfig.default.build(); // TODO: Only need words here

  let result = cfg.addWord(selection);

  if (result) {
    let saved = await cfg.save();

    if (!saved) {
      chrome.tabs.reload();
    }
  }
} // Disable domain and reload page (unless already disabled)


async function disableDomain(cfg, domain, key) {
  if (!cfg[key].includes(domain)) {
    cfg[key].push(domain);
    let result = await cfg.save();

    if (!result) {
      chrome.tabs.reload();
    }
  }
} // Remove all entries that disable the filter for domain


async function enableDomain(cfg, domain, key) {
  let newDomainList = _domain.default.removeFromList(domain, cfg[key]);

  if (newDomainList.length < cfg[key].length) {
    cfg[key] = newDomainList;
    let result = await cfg.save();

    if (!result) {
      chrome.tabs.reload();
    }
  }
}

async function toggleDomain(domain, key) {
  let cfg = await _webConfig.default.build([key]);
  _domain.default.domainMatch(domain, cfg[key]) ? enableDomain(cfg, domain, key) : disableDomain(cfg, domain, key);
}

async function updateMigrations(previousVersion) {
  if (_dataMigration.default.migrationNeeded(previousVersion)) {
    let cfg = await _webConfig.default.build();
    let migration = new _dataMigration.default(cfg);
    let migrated = migration.byVersion(previousVersion);
    if (migrated) cfg.save();
  }
} ////
// Menu Items
// chrome.contextMenus.removeAll(function() {
//   chrome.contextMenus.create({
//     id: 'addSelection',
//     title: 'Add selection to filter',
//     contexts: ['selection'],
//     documentUrlPatterns: ['file://*/*', 'http://*/*', 'https://*/*']
//   });
//   chrome.contextMenus.create({
//     id: 'toggleFilterForDomain',
//     title: 'Toggle filter for domain',
//     contexts: ['all'],
//     documentUrlPatterns: ['http://*/*', 'https://*/*']
//   });
//   chrome.contextMenus.create({
//     id: 'toggleAdvancedModeForDomain',
//     title: 'Toggle advanced mode for domain',
//     contexts: ['all'],
//     documentUrlPatterns: ['http://*/*', 'https://*/*']
//   });
//   chrome.contextMenus.create({
//     id: 'options',
//     title: 'Options',
//     contexts: ['all']
//   });
// });
////
// Listeners
// chrome.contextMenus.onClicked.addListener(function(info, tab) {
//   switch(info.menuItemId) {
//     case 'addSelection':
//       addSelection(info.selectionText); break;
//     case 'toggleFilterForDomain': {
//       let url = new URL(tab.url);
//       toggleDomain(url.hostname, 'disabledDomains'); break;
//     }
//     case 'toggleAdvancedModeForDomain': {
//       let url = new URL(tab.url);
//       toggleDomain(url.hostname, 'advancedDomains'); break;
//     }
//     case 'options':
//       chrome.runtime.openOptionsPage(); break;
//   }
// });


(function (notificationId) {
  switch (notificationId) {
    case 'extensionUpdate':
      chrome.notifications.clear('extensionUpdate');
      chrome.tabs.create({
        url: 'https://ega.go.tz'
      });
      break;
  }
});

/***/ })
/******/ ]);
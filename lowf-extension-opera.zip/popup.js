/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 15);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.dynamicList = dynamicList;
exports.escapeHTML = escapeHTML;
exports.exportToFile = exportToFile;
exports.getVersion = getVersion;
exports.isVersionOlder = isVersionOlder;
exports.readFile = readFile;
exports.removeFromArray = removeFromArray;

/* istanbul ignore next */
function dynamicList(list, selectEm, title) {
  let options = '';

  if (title !== undefined) {
    options = '<option value="" disabled selected>' + title + '</option>';
  }

  for (let i = 0; i < list.length; i++) {
    options += '<option value="' + list[i] + '">' + list[i] + '</option>';
  }

  document.getElementById(selectEm).innerHTML = options;
}

function escapeHTML(str) {
  return str.replace(/([<>&"'])/g, (match, p1) => ({
    '<': '&lt;',
    '>': '&gt;',
    '&': '&amp;',
    '"': '&quot;',
    "'": '&apos;'
  })[p1]);
}

function exportToFile(dataStr, fileName = 'data.txt') {
  let dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
  let linkElement = document.createElement('a');
  linkElement.setAttribute('href', dataUri);
  linkElement.setAttribute('download', fileName);
  linkElement.click();
  linkElement.remove();
} // /^\d+\.\d+\.\d+$/


function getVersion(version) {
  let versionValues = version.split('.');
  return {
    major: parseInt(versionValues[0]),
    minor: parseInt(versionValues[1]),
    patch: parseInt(versionValues[2])
  };
} // Is the provided version lower than the minimum version?


function isVersionOlder(version, minimum) {
  if (version.major < minimum.major) {
    return true;
  } else if (version.major == minimum.major && version.minor < minimum.minor) {
    return true;
  } else if (version.major == minimum.major && version.minor == minimum.minor && version.patch < minimum.patch) {
    return true;
  }

  return false;
}

function readFile(file) {
  return new Promise((resolve, reject) => {
    let fr = new FileReader();

    fr.onload = () => {
      resolve(fr.result);
    };

    fr.readAsText(file);
  });
}

function removeFromArray(array, element) {
  return array.filter(e => e !== element);
}

/***/ }),

/***/ 1:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _config = _interopRequireDefault(__webpack_require__(2));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class WebConfig extends _config.default {
  static async build(keys) {
    let asyncResult = await WebConfig.getConfig(keys);
    let instance = new WebConfig(asyncResult);
    return instance;
  } // Call build() to create a new instance


  constructor(asyncParam) {
    super(asyncParam);
  } // Compile words


  static combineWords(items) {
    items.words = {};

    if (items._words0 !== undefined) {
      // Find all _words* to combine
      let wordKeys = Object.keys(items).filter(function (key) {
        return _config.default._wordsPattern.test(key);
      }); // Add all _words* to words and remove _words*

      wordKeys.forEach(function (key) {
        Object.assign(items.words, items[key]);
        delete items[key];
      });
    } // console.log('combineWords', items); // DEBUG

  } // Persist all configs from defaults and split _words*


  dataToPersist() {
    let self = this;
    let data = {}; // Save all settings using keys from _defaults

    Object.keys(_config.default._defaults).forEach(function (key) {
      if (self[key] !== undefined) {
        data[key] = self[key];
      }
    });

    if (self.words) {
      // Split words back into _words* for storage
      let splitWords = self.splitWords();
      Object.keys(splitWords).forEach(function (key) {
        data[key] = splitWords[key];
      });
      let wordKeys = Object.keys(self).filter(function (key) {
        return _config.default._wordsPattern.test(key);
      });
      wordKeys.forEach(function (key) {
        data[key] = self[key];
      });
    } // console.log('dataToPersist', data); // DEBUG - Config


    return data;
  } // Async call to get provided keys (or default keys) from chrome storage
  // TODO: Keys: Doesn't support getting words


  static getConfig(keys) {
    return new Promise(function (resolve, reject) {
      // Generate a request to use with chrome.storage
      let request = null;

      if (keys !== undefined) {
        request = {};

        for (let k of keys) {
          request[k] = _config.default._defaults[k];
        }
      }

      chrome.storage.sync.get(request, function (items) {
        // Ensure defaults for undefined settings
        Object.keys(_config.default._defaults).forEach(function (defaultKey) {
          if (request == null || Object.keys(request).includes(defaultKey)) {
            if (items[defaultKey] === undefined) {
              items[defaultKey] = _config.default._defaults[defaultKey];
            }
          }
        }); // Add words if requested, and provide _defaultWords if needed

        if (keys === undefined || keys.includes('words')) {
          // Use default words if none were provided
          if (items._words0 === undefined || Object.keys(items._words0).length == 0) {
            items._words0 = _config.default._defaultWords;
          }

          WebConfig.combineWords(items);
        }

        resolve(items);
      });
    });
  }

  removeProp(prop) {
    chrome.storage.sync.remove(prop);
    delete this[prop];
  }

  reset() {
    return new Promise(function (resolve, reject) {
      chrome.storage.sync.clear(function () {
        resolve(chrome.runtime.lastError ? 1 : 0);
      });
    });
  } // Pass a key to save only that key, otherwise it will save everything


  save(prop) {
    let data = {};
    prop ? data[prop] = this[prop] : data = this.dataToPersist();
    return new Promise(function (resolve, reject) {
      chrome.storage.sync.set(data, function () {
        resolve(chrome.runtime.lastError ? 1 : 0);
      });
    });
  }

  splitWords() {
    let self = this;
    let currentContainerNum = 0;
    let currentWordNum = 0; // let wordsLength = JSON.stringify(self.words).length;
    // let wordContainers = Math.ceil(wordsLength/Config._maxBytes);
    // let wordsNum = Object.keys(self.words).length;

    let words = {};
    words[`_words${currentContainerNum}`] = {};
    Object.keys(self.words).sort().forEach(function (word) {
      if (currentWordNum == _config.default._maxWords) {
        currentContainerNum++;
        currentWordNum = 0;
        words[`_words${currentContainerNum}`] = {};
      }

      words[`_words${currentContainerNum}`][word] = self.words[word];
      currentWordNum++;
    });
    return words;
  }

}

exports.default = WebConfig;

/***/ }),

/***/ 15:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _helper = __webpack_require__(0);

var _webConfig = _interopRequireDefault(__webpack_require__(1));

var _domain = _interopRequireDefault(__webpack_require__(3));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class Popup {
  static async load(instance) {
    instance.cfg = await _webConfig.default.build(['advancedDomains', 'disabledDomains', 'filterMethod', 'password']);
    instance.domain = new _domain.default();
    await instance.domain.load();
    return instance;
  }

  constructor() {
    _defineProperty(this, "cfg", void 0);

    _defineProperty(this, "domain", void 0);

    _defineProperty(this, "protected", void 0);

    _defineProperty(this, "filterMethodContainer", void 0);

    this.protected = false;
    this.filterMethodContainer = document.getElementById('filterMethodContainer');
  } ////
  // Functions for Popup


  static disable(element) {
    element.disabled = true;
    element.classList.add('disabled');
  }

  static enable(element) {
    element.disabled = false;
    element.classList.remove('disabled');
  }

  async disableAdvancedMode(cfg, domain, key) {
    let newDomainList = _domain.default.removeFromList(domain, cfg[key]);

    if (newDomainList.length < cfg[key].length) {
      cfg[key] = newDomainList;
      let result = await cfg.save();

      if (!result) {
        chrome.tabs.reload();
      }
    }
  }

  async disableDomain() {
    let popup = this;

    if (!popup.cfg.disabledDomains.includes(popup.domain.hostname)) {
      popup.cfg.disabledDomains.push(popup.domain.hostname);
      let result = await popup.cfg.save();

      if (!result) {
        Popup.disable(document.getElementById('advancedMode'));
        Popup.disable(document.getElementById('filterMethodSelect'));
        chrome.tabs.reload();
      }
    }
  }

  async enableAdvancedMode(cfg, domain, key) {
    if (!cfg[key].includes(domain)) {
      cfg[key].push(domain);
      let result = await cfg.save();

      if (!result) {
        chrome.tabs.reload();
      }
    }
  } // Remove all entries that disable the filter for domain


  async enableDomain(cfg, domain, key) {
    let newDomainList = _domain.default.removeFromList(domain, cfg[key]);

    if (newDomainList.length < cfg[key].length) {
      cfg[key] = newDomainList;
      let result = await cfg.save();

      if (!result) {
        Popup.enable(document.getElementById('advancedMode'));
        Popup.enable(document.getElementById('filterMethodSelect'));
        chrome.tabs.reload();
      }
    }
  }

  filterMethodSelect() {
    let filterMethodSelect = document.getElementById('filterMethodSelect');
    chrome.storage.sync.set({
      filterMethod: filterMethodSelect.selectedIndex
    }, function () {
      if (!chrome.runtime.lastError) {
        chrome.tabs.reload();
      }
    });
  }

  async populateOptions(event) {
    let popup = this;
    await Popup.load(popup);
    let domainFilter = document.getElementById('domainFilter');
    let domainToggle = document.getElementById('domainToggle');
    let advancedMode = document.getElementById('advancedMode');
    let filterMethodSelect = document.getElementById('filterMethodSelect');
    (0, _helper.dynamicList)(_webConfig.default._filterMethodNames, 'filterMethodSelect');
    filterMethodSelect.selectedIndex = popup.cfg.filterMethod;

    if (popup.cfg.password && popup.cfg.password != '') {
      popup.protected = true;
      Popup.disable(domainFilter);
      Popup.disable(domainToggle);
      Popup.disable(advancedMode);
      Popup.disable(filterMethodSelect);
    } // Restricted pages


    if (popup.domain.url.protocol.match(/(^chrome:|^about:|^[a-zA-Z]*-extension:)/i) || popup.domain.hostname == 'chrome.google.com') {
      domainFilter.checked = false;
      Popup.disable(domainFilter);
      Popup.disable(domainToggle);
      Popup.disable(advancedMode);
      Popup.disable(filterMethodSelect);
      return false;
    } // Set initial value for domain filter and disable options if they are not applicable


    if (_domain.default.domainMatch(popup.domain.hostname, popup.cfg['disabledDomains'])) {
      domainFilter.checked = false;
      Popup.disable(advancedMode);
      Popup.disable(filterMethodSelect);
    } // Set initial value for advanced mode


    if (_domain.default.domainMatch(popup.domain.hostname, popup.cfg['advancedDomains'])) {
      advancedMode.checked = true;
    }
  }

  populateSummary(message) {
    if (message && message.summary) {
      let summaryEl = document.getElementById('summary');
      summaryEl.innerHTML = this.summaryTableHTML(message.summary);

      if (summaryEl.classList.contains('w3-hide')) {
        summaryEl.classList.remove('w3-hide');
        summaryEl.classList.add('w3-show');
        document.getElementById('summaryDivider').classList.remove('w3-hide');
      }
    } else {// console.log('Unahndled message: ', message); // DEBUG
    }
  }

  summaryTableHTML(summary) {
    let tableInnerHTML = '';

    if (Object.keys(summary).length > 0) {
      tableInnerHTML = '<table class="w3-table w3-striped w3-border w3-bordered w3-card w3-small"><tr class="w3-flat-peter-river"><th colspan="2" class="w3-center">Filtered Words</th></tr>';
      Object.keys(summary).sort((a, b) => summary[b].count - summary[a].count).forEach(key => {
        tableInnerHTML += `<tr><td class="w3-tooltip"><span style="position:absolute;left:0;bottom:18px" class="w3-text w3-tag">${(0, _helper.escapeHTML)(key)}</span>${(0, _helper.escapeHTML)(summary[key].filtered)}</td><td class="w3-right">${summary[key].count}</td></tr>`;
      });
      tableInnerHTML += '</table>';
    }

    return tableInnerHTML;
  }

  toggleAdvancedMode() {
    let popup = this;

    if (!popup.protected) {
      let advancedMode = document.getElementById('advancedMode');

      if (advancedMode.checked) {
        popup.enableAdvancedMode(popup.cfg, popup.domain.hostname, 'advancedDomains');
      } else {
        popup.disableAdvancedMode(popup.cfg, popup.domain.hostname, 'advancedDomains');
      }
    }
  }

  toggleFilter() {
    let popup = this;

    if (!popup.protected) {
      let domainFilter = document.getElementById('domainFilter');

      if (domainFilter.checked) {
        popup.enableDomain(popup.cfg, popup.domain.hostname, 'disabledDomains');
      } else {
        popup.disableDomain();
      }
    }
  }

} // Listen for data updates from filter


chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.summary) {
    chrome.tabs.query({
      active: true,
      currentWindow: true
    }, function (tabs) {
      if (sender.tab.id == tabs[0].id) popup.populateSummary(request);
    });
  }
}); // Initial data request

chrome.tabs.query({
  active: true,
  currentWindow: true
}, tabs => {
  chrome.tabs.sendMessage(tabs[0].id, {
    popup: true
  });
});
let popup = new Popup(); ////
// Listeners

window.addEventListener('load', function (event) {
  popup.populateOptions();
});
document.getElementById('domainFilter').addEventListener('change', function (event) {
  popup.toggleFilter();
});
document.getElementById('advancedMode').addEventListener('change', function (event) {
  popup.toggleAdvancedMode();
});
document.getElementById('filterMethodSelect').addEventListener('change', function (event) {
  popup.filterMethodSelect();
});
document.getElementById('options').addEventListener('click', function () {
  chrome.runtime.openOptionsPage();
});

/***/ }),

/***/ 2:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class Config {
  constructor(config) {
    _defineProperty(this, "advancedDomains", void 0);

    _defineProperty(this, "censorCharacter", void 0);

    _defineProperty(this, "censorFixedLength", void 0);

    _defineProperty(this, "customAudioSites", void 0);

    _defineProperty(this, "defaultSubstitution", void 0);

    _defineProperty(this, "defaultWordMatchMethod", void 0);

    _defineProperty(this, "defaultWordRepeat", void 0);

    _defineProperty(this, "disabledDomains", void 0);

    _defineProperty(this, "filterMethod", void 0);

    _defineProperty(this, "filterWordList", void 0);

    _defineProperty(this, "globalMatchMethod", void 0);

    _defineProperty(this, "muteAudio", void 0);

    _defineProperty(this, "muteAudioOnly", void 0);

    _defineProperty(this, "muteMethod", void 0);

    _defineProperty(this, "password", void 0);

    _defineProperty(this, "preserveCase", void 0);

    _defineProperty(this, "preserveFirst", void 0);

    _defineProperty(this, "preserveLast", void 0);

    _defineProperty(this, "showCounter", void 0);

    _defineProperty(this, "showSubtitles", void 0);

    _defineProperty(this, "showSummary", void 0);

    _defineProperty(this, "showUpdateNotification", void 0);

    _defineProperty(this, "substitutionMark", void 0);

    _defineProperty(this, "words", void 0);

    _defineProperty(this, "youTubeAutoSubsMin", void 0);

    if (typeof config === 'undefined') {
      throw new Error('Cannot be called directly. call build()');
    }

    for (let k in config) this[k] = config[k];
  }

  addWord(str, options) {
    str = str.trim().toLowerCase();

    if (Object.keys(this.words).includes(str)) {
      return false; // Already exists
    } else if (options) {
      options.sub = options.sub.trim().toLowerCase();
      this.words[str] = options;
      return true;
    } else {
      this.words[str] = {
        matchMethod: this.defaultWordMatchMethod,
        repeat: this.defaultWordRepeat,
        sub: ''
      };
      return true;
    }
  }

  repeatForWord(word) {
    if (this.words[word].repeat === true || this.words[word].repeat === false) {
      return this.words[word].repeat;
    } else {
      return this.defaultWordRepeat;
    }
  }

  sanitizeWords() {
    let sanitizedWords = {};
    Object.keys(this.words).sort().forEach(key => {
      sanitizedWords[key.trim().toLowerCase()] = this.words[key];
    });
    this.words = sanitizedWords;
  }

}

exports.default = Config;

_defineProperty(Config, "filterMethods", {
  censor: 0,
  substitute: 1,
  remove: 2
});

_defineProperty(Config, "matchMethods", {
  exact: 0,
  partial: 1,
  whole: 2,
  'Per-Word': 3,
  'RegExp': 4
});

_defineProperty(Config, "_defaults", {
  advancedDomains: [],
  censorCharacter: '',
  censorFixedLength: 0,
  customAudioSites: null,
  defaultSubstitution: '',
  defaultWordMatchMethod: 0,
  defaultWordRepeat: false,
  disabledDomains: [],
  filterMethod: 0,
  // ['Censor', 'Substitute', 'Remove'];
  filterWordList: true,
  globalMatchMethod: 3,
  // ['Exact', 'Partial', 'Whole', 'Per-Word', 'RegExp']
  muteAudio: false,
  // Filter audio
  muteAudioOnly: false,
  muteMethod: 0,
  // 0: Mute Tab, 1: Video Volume
  password: null,
  preserveCase: true,
  preserveFirst: true,
  preserveLast: false,
  showCounter: true,
  showSubtitles: 0,
  showSummary: true,
  showUpdateNotification: true,
  substitutionMark: false,
  youTubeAutoSubsMin: 0
});

_defineProperty(Config, "_maneno", {
  'ass': {
    matchMethod: 0,
    repeat: true,
    sub: 'butt'
  },
  'asses': {
    matchMethod: 0,
    repeat: false,
    sub: 'butts'
  },
  'asshole': {
    matchMethod: 1,
    repeat: true,
    sub: 'jerk'
  },
  'badass': {
    matchMethod: 1,
    repeat: true,
    sub: 'cool'
  },
  'bastard': {
    matchMethod: 1,
    repeat: true,
    sub: 'idiot'
  },
  'bitch': {
    matchMethod: 1,
    repeat: true,
    sub: 'bench'
  },
  'cocksucker': {
    matchMethod: 1,
    repeat: true,
    sub: 'suckup'
  },
  'cunt': {
    matchMethod: 1,
    repeat: true,
    sub: 'expletive'
  },
  'dammit': {
    matchMethod: 1,
    repeat: false,
    sub: 'dangit'
  },
  'damn': {
    matchMethod: 1,
    repeat: false,
    sub: 'dang'
  },
  'dumbass': {
    matchMethod: 1,
    repeat: true,
    sub: 'idiot'
  },
  'fag': {
    matchMethod: 0,
    repeat: true,
    sub: 'gay'
  },
  'faggot': {
    matchMethod: 1,
    repeat: true,
    sub: 'gay'
  },
  'fags': {
    matchMethod: 0,
    repeat: true,
    sub: 'gays'
  },
  'fuck': {
    matchMethod: 1,
    repeat: true,
    sub: 'freak'
  },
  'goddammit': {
    matchMethod: 1,
    repeat: true,
    sub: 'dangit'
  },
  'hell': {
    matchMethod: 0,
    repeat: true,
    sub: 'heck'
  },
  'jackass': {
    matchMethod: 1,
    repeat: true,
    sub: 'jerk'
  },
  'nigga': {
    matchMethod: 0,
    repeat: true,
    sub: 'bruh'
  },
  'nigger': {
    matchMethod: 0,
    repeat: true,
    sub: 'man'
  },
  'niggers': {
    matchMethod: 0,
    repeat: true,
    sub: 'people'
  },
  'piss': {
    matchMethod: 1,
    repeat: true,
    sub: 'pee'
  },
  'pissed': {
    matchMethod: 1,
    repeat: true,
    sub: 'ticked'
  },
  'pussies': {
    matchMethod: 0,
    repeat: true,
    sub: 'softies'
  },
  'pussy': {
    matchMethod: 0,
    repeat: true,
    sub: 'softie'
  },
  'shit': {
    matchMethod: 1,
    repeat: true,
    sub: 'crap'
  },
  'slut': {
    matchMethod: 1,
    repeat: true,
    sub: 'tramp'
  },
  'tits': {
    matchMethod: 1,
    repeat: true,
    sub: 'chest'
  },
  'twat': {
    matchMethod: 1,
    repeat: true,
    sub: 'dumbo'
  },
  'whore': {
    matchMethod: 1,
    repeat: true,
    sub: 'tramp'
  },
  'bolo': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'bwege': {
    matchMethod: 1,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'fala': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'fara': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'fira': {
    matchMethod: 1,
    repeat: true,
    sub: 'kinyume na maumbile'
  },
  'firwa': {
    matchMethod: 1,
    repeat: true,
    sub: 'kinyume na maumbile'
  },
  'kuma': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kike'
  },
  'kumalake': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'kumalamsenge': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'kumamae': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'kundu': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'Kusagana': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'Kutomba': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'Kutombana': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'Kahaba': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'malaya': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'matako': {
    matchMethod: 1,
    repeat: true,
    sub: 'makalio'
  },
  'mavuzi': {
    matchMethod: 1,
    repeat: true,
    sub: 'nywele za sehemu ya siri'
  },
  'mbolo': {
    matchMethod: 1,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'mboo': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'mfiraji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mfirwaji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mjanechuo': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mkundu': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'mngese': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'msagaji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'msenge': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mxenge': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'msengenyaji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mshenzi': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'nyoko': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'nyoo': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'pumbu': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'senge': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'shahawa': {
    matchMethod: 1,
    repeat: true,
    sub: 'manii'
  },
  'shenzi': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'tako': {
    matchMethod: 0,
    repeat: true,
    sub: 'kalio'
  },
  'tiana': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'tiwa': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'tomb': {
    matchMethod: 1,
    repeat: true,
    sub: 'tendo la ndoa'
  },
  'tomba': {
    matchMethod: 1,
    repeat: true,
    sub: 'tendo la ndoa'
  },
  'tombana': {
    matchMethod: 1,
    repeat: true,
    sub: 'tendo la ndoa'
  },
  'tombwa': {
    matchMethod: 1,
    repeat: true,
    sub: 'tendo la ndoa'
  },
  'uboo': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'ubolo': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'kisimi': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'kicmi': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'kixmi': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'usenge': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'ufiraji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'ufirwaji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'tahira': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  }
});

_defineProperty(Config, "_defaultWords", Config._maneno);

_defineProperty(Config, "_filterMethodNames", ['Censor', 'Substitute', 'Remove']);

_defineProperty(Config, "_matchMethodNames", ['Exact', 'Partial', 'Whole', 'Per-Word', 'Regular-Expression']);

_defineProperty(Config, "_maxBytes", 6500);

_defineProperty(Config, "_maxWords", 100);

_defineProperty(Config, "_wordsPattern", /^_words\d+/);

/***/ }),

/***/ 3:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _helper = __webpack_require__(0);

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class Domain {
  constructor() {
    _defineProperty(this, "tab", void 0);

    _defineProperty(this, "url", void 0);

    _defineProperty(this, "hostname", void 0);
  }

  static domainMatch(domain, domains) {
    let result = false;

    for (let x = 0; x < domains.length; x++) {
      let domainRegex = new RegExp('(^|\.)' + domains[x], 'i');

      if (domainRegex.test(domain)) {
        result = true;
        break;
      }
    }

    return result;
  } // If a parent domain (example.com) is included, it will not match all subdomains.
  // If a subdomain is included, it will match itself and the parent, if present.


  static removeFromList(domain, domains) {
    let domainRegex;
    let newDomainsList = domains;

    for (let x = 0; x < domains.length; x++) {
      domainRegex = new RegExp('(^|\.)' + domains[x], 'i');

      if (domainRegex.test(domain)) {
        newDomainsList = (0, _helper.removeFromArray)(newDomainsList, domains[x]);
      }
    }

    return newDomainsList;
  }

  static getCurrentTab() {
    /* istanbul ignore next */
    return new Promise(function (resolve, reject) {
      chrome.tabs.query({
        active: true,
        currentWindow: true
      }, function (tabs) {
        resolve(tabs[0]);
      });
    });
  }

  async load() {
    this.tab = await Domain.getCurrentTab();
    this.url = new URL(this.tab.url);
    this.hostname = this.url.hostname;
  }

}

exports.default = Domain;

/***/ })

/******/ });
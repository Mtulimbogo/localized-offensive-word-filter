/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 10);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.dynamicList = dynamicList;
exports.escapeHTML = escapeHTML;
exports.exportToFile = exportToFile;
exports.getVersion = getVersion;
exports.isVersionOlder = isVersionOlder;
exports.readFile = readFile;
exports.removeFromArray = removeFromArray;

/* istanbul ignore next */
function dynamicList(list, selectEm, title) {
  let options = '';

  if (title !== undefined) {
    options = '<option value="" disabled selected>' + title + '</option>';
  }

  for (let i = 0; i < list.length; i++) {
    options += '<option value="' + list[i] + '">' + list[i] + '</option>';
  }

  document.getElementById(selectEm).innerHTML = options;
}

function escapeHTML(str) {
  return str.replace(/([<>&"'])/g, (match, p1) => ({
    '<': '&lt;',
    '>': '&gt;',
    '&': '&amp;',
    '"': '&quot;',
    "'": '&apos;'
  })[p1]);
}

function exportToFile(dataStr, fileName = 'data.txt') {
  let dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
  let linkElement = document.createElement('a');
  linkElement.setAttribute('href', dataUri);
  linkElement.setAttribute('download', fileName);
  linkElement.click();
  linkElement.remove();
} // /^\d+\.\d+\.\d+$/


function getVersion(version) {
  let versionValues = version.split('.');
  return {
    major: parseInt(versionValues[0]),
    minor: parseInt(versionValues[1]),
    patch: parseInt(versionValues[2])
  };
} // Is the provided version lower than the minimum version?


function isVersionOlder(version, minimum) {
  if (version.major < minimum.major) {
    return true;
  } else if (version.major == minimum.major && version.minor < minimum.minor) {
    return true;
  } else if (version.major == minimum.major && version.minor == minimum.minor && version.patch < minimum.patch) {
    return true;
  }

  return false;
}

function readFile(file) {
  return new Promise((resolve, reject) => {
    let fr = new FileReader();

    fr.onload = () => {
      resolve(fr.result);
    };

    fr.readAsText(file);
  });
}

function removeFromArray(array, element) {
  return array.filter(e => e !== element);
}

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _config = _interopRequireDefault(__webpack_require__(2));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class WebConfig extends _config.default {
  static async build(keys) {
    let asyncResult = await WebConfig.getConfig(keys);
    let instance = new WebConfig(asyncResult);
    return instance;
  } // Call build() to create a new instance


  constructor(asyncParam) {
    super(asyncParam);
  } // Compile words


  static combineWords(items) {
    items.words = {};

    if (items._words0 !== undefined) {
      // Find all _words* to combine
      let wordKeys = Object.keys(items).filter(function (key) {
        return _config.default._wordsPattern.test(key);
      }); // Add all _words* to words and remove _words*

      wordKeys.forEach(function (key) {
        Object.assign(items.words, items[key]);
        delete items[key];
      });
    } // console.log('combineWords', items); // DEBUG

  } // Persist all configs from defaults and split _words*


  dataToPersist() {
    let self = this;
    let data = {}; // Save all settings using keys from _defaults

    Object.keys(_config.default._defaults).forEach(function (key) {
      if (self[key] !== undefined) {
        data[key] = self[key];
      }
    });

    if (self.words) {
      // Split words back into _words* for storage
      let splitWords = self.splitWords();
      Object.keys(splitWords).forEach(function (key) {
        data[key] = splitWords[key];
      });
      let wordKeys = Object.keys(self).filter(function (key) {
        return _config.default._wordsPattern.test(key);
      });
      wordKeys.forEach(function (key) {
        data[key] = self[key];
      });
    } // console.log('dataToPersist', data); // DEBUG - Config


    return data;
  } // Async call to get provided keys (or default keys) from chrome storage
  // TODO: Keys: Doesn't support getting words


  static getConfig(keys) {
    return new Promise(function (resolve, reject) {
      // Generate a request to use with chrome.storage
      let request = null;

      if (keys !== undefined) {
        request = {};

        for (let k of keys) {
          request[k] = _config.default._defaults[k];
        }
      }

      chrome.storage.sync.get(request, function (items) {
        // Ensure defaults for undefined settings
        Object.keys(_config.default._defaults).forEach(function (defaultKey) {
          if (request == null || Object.keys(request).includes(defaultKey)) {
            if (items[defaultKey] === undefined) {
              items[defaultKey] = _config.default._defaults[defaultKey];
            }
          }
        }); // Add words if requested, and provide _defaultWords if needed

        if (keys === undefined || keys.includes('words')) {
          // Use default words if none were provided
          if (items._words0 === undefined || Object.keys(items._words0).length == 0) {
            items._words0 = _config.default._defaultWords;
          }

          WebConfig.combineWords(items);
        }

        resolve(items);
      });
    });
  }

  removeProp(prop) {
    chrome.storage.sync.remove(prop);
    delete this[prop];
  }

  reset() {
    return new Promise(function (resolve, reject) {
      chrome.storage.sync.clear(function () {
        resolve(chrome.runtime.lastError ? 1 : 0);
      });
    });
  } // Pass a key to save only that key, otherwise it will save everything


  save(prop) {
    let data = {};
    prop ? data[prop] = this[prop] : data = this.dataToPersist();
    return new Promise(function (resolve, reject) {
      chrome.storage.sync.set(data, function () {
        resolve(chrome.runtime.lastError ? 1 : 0);
      });
    });
  }

  splitWords() {
    let self = this;
    let currentContainerNum = 0;
    let currentWordNum = 0; // let wordsLength = JSON.stringify(self.words).length;
    // let wordContainers = Math.ceil(wordsLength/Config._maxBytes);
    // let wordsNum = Object.keys(self.words).length;

    let words = {};
    words[`_words${currentContainerNum}`] = {};
    Object.keys(self.words).sort().forEach(function (word) {
      if (currentWordNum == _config.default._maxWords) {
        currentContainerNum++;
        currentWordNum = 0;
        words[`_words${currentContainerNum}`] = {};
      }

      words[`_words${currentContainerNum}`][word] = self.words[word];
      currentWordNum++;
    });
    return words;
  }

}

exports.default = WebConfig;

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class Config {
  constructor(config) {
    _defineProperty(this, "advancedDomains", void 0);

    _defineProperty(this, "censorCharacter", void 0);

    _defineProperty(this, "censorFixedLength", void 0);

    _defineProperty(this, "customAudioSites", void 0);

    _defineProperty(this, "defaultSubstitution", void 0);

    _defineProperty(this, "defaultWordMatchMethod", void 0);

    _defineProperty(this, "defaultWordRepeat", void 0);

    _defineProperty(this, "disabledDomains", void 0);

    _defineProperty(this, "filterMethod", void 0);

    _defineProperty(this, "filterWordList", void 0);

    _defineProperty(this, "globalMatchMethod", void 0);

    _defineProperty(this, "muteAudio", void 0);

    _defineProperty(this, "muteAudioOnly", void 0);

    _defineProperty(this, "muteMethod", void 0);

    _defineProperty(this, "password", void 0);

    _defineProperty(this, "preserveCase", void 0);

    _defineProperty(this, "preserveFirst", void 0);

    _defineProperty(this, "preserveLast", void 0);

    _defineProperty(this, "showCounter", void 0);

    _defineProperty(this, "showSubtitles", void 0);

    _defineProperty(this, "showSummary", void 0);

    _defineProperty(this, "showUpdateNotification", void 0);

    _defineProperty(this, "substitutionMark", void 0);

    _defineProperty(this, "words", void 0);

    _defineProperty(this, "youTubeAutoSubsMin", void 0);

    if (typeof config === 'undefined') {
      throw new Error('Cannot be called directly. call build()');
    }

    for (let k in config) this[k] = config[k];
  }

  addWord(str, options) {
    str = str.trim().toLowerCase();

    if (Object.keys(this.words).includes(str)) {
      return false; // Already exists
    } else if (options) {
      options.sub = options.sub.trim().toLowerCase();
      this.words[str] = options;
      return true;
    } else {
      this.words[str] = {
        matchMethod: this.defaultWordMatchMethod,
        repeat: this.defaultWordRepeat,
        sub: ''
      };
      return true;
    }
  }

  repeatForWord(word) {
    if (this.words[word].repeat === true || this.words[word].repeat === false) {
      return this.words[word].repeat;
    } else {
      return this.defaultWordRepeat;
    }
  }

  sanitizeWords() {
    let sanitizedWords = {};
    Object.keys(this.words).sort().forEach(key => {
      sanitizedWords[key.trim().toLowerCase()] = this.words[key];
    });
    this.words = sanitizedWords;
  }

}

exports.default = Config;

_defineProperty(Config, "filterMethods", {
  censor: 0,
  substitute: 1,
  remove: 2
});

_defineProperty(Config, "matchMethods", {
  exact: 0,
  partial: 1,
  whole: 2,
  'Per-Word': 3,
  'RegExp': 4
});

_defineProperty(Config, "_defaults", {
  advancedDomains: [],
  censorCharacter: '',
  censorFixedLength: 0,
  customAudioSites: null,
  defaultSubstitution: '',
  defaultWordMatchMethod: 0,
  defaultWordRepeat: false,
  disabledDomains: [],
  filterMethod: 0,
  // ['Censor', 'Substitute', 'Remove'];
  filterWordList: true,
  globalMatchMethod: 3,
  // ['Exact', 'Partial', 'Whole', 'Per-Word', 'RegExp']
  muteAudio: false,
  // Filter audio
  muteAudioOnly: false,
  muteMethod: 0,
  // 0: Mute Tab, 1: Video Volume
  password: null,
  preserveCase: true,
  preserveFirst: true,
  preserveLast: false,
  showCounter: true,
  showSubtitles: 0,
  showSummary: true,
  showUpdateNotification: true,
  substitutionMark: false,
  youTubeAutoSubsMin: 0
});

_defineProperty(Config, "_maneno", {
  'ass': {
    matchMethod: 0,
    repeat: true,
    sub: 'butt'
  },
  'asses': {
    matchMethod: 0,
    repeat: false,
    sub: 'butts'
  },
  'asshole': {
    matchMethod: 1,
    repeat: true,
    sub: 'jerk'
  },
  'badass': {
    matchMethod: 1,
    repeat: true,
    sub: 'cool'
  },
  'bastard': {
    matchMethod: 1,
    repeat: true,
    sub: 'idiot'
  },
  'bitch': {
    matchMethod: 1,
    repeat: true,
    sub: 'bench'
  },
  'cocksucker': {
    matchMethod: 1,
    repeat: true,
    sub: 'suckup'
  },
  'cunt': {
    matchMethod: 1,
    repeat: true,
    sub: 'expletive'
  },
  'dammit': {
    matchMethod: 1,
    repeat: false,
    sub: 'dangit'
  },
  'damn': {
    matchMethod: 1,
    repeat: false,
    sub: 'dang'
  },
  'dumbass': {
    matchMethod: 1,
    repeat: true,
    sub: 'idiot'
  },
  'fag': {
    matchMethod: 0,
    repeat: true,
    sub: 'gay'
  },
  'faggot': {
    matchMethod: 1,
    repeat: true,
    sub: 'gay'
  },
  'fags': {
    matchMethod: 0,
    repeat: true,
    sub: 'gays'
  },
  'fuck': {
    matchMethod: 1,
    repeat: true,
    sub: 'freak'
  },
  'goddammit': {
    matchMethod: 1,
    repeat: true,
    sub: 'dangit'
  },
  'hell': {
    matchMethod: 0,
    repeat: true,
    sub: 'heck'
  },
  'jackass': {
    matchMethod: 1,
    repeat: true,
    sub: 'jerk'
  },
  'nigga': {
    matchMethod: 0,
    repeat: true,
    sub: 'bruh'
  },
  'nigger': {
    matchMethod: 0,
    repeat: true,
    sub: 'man'
  },
  'niggers': {
    matchMethod: 0,
    repeat: true,
    sub: 'people'
  },
  'piss': {
    matchMethod: 1,
    repeat: true,
    sub: 'pee'
  },
  'pissed': {
    matchMethod: 1,
    repeat: true,
    sub: 'ticked'
  },
  'pussies': {
    matchMethod: 0,
    repeat: true,
    sub: 'softies'
  },
  'pussy': {
    matchMethod: 0,
    repeat: true,
    sub: 'softie'
  },
  'shit': {
    matchMethod: 1,
    repeat: true,
    sub: 'crap'
  },
  'slut': {
    matchMethod: 1,
    repeat: true,
    sub: 'tramp'
  },
  'tits': {
    matchMethod: 1,
    repeat: true,
    sub: 'chest'
  },
  'twat': {
    matchMethod: 1,
    repeat: true,
    sub: 'dumbo'
  },
  'whore': {
    matchMethod: 1,
    repeat: true,
    sub: 'tramp'
  },
  'bolo': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'bwege': {
    matchMethod: 1,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'fala': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'fara': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'fira': {
    matchMethod: 1,
    repeat: true,
    sub: 'kinyume na maumbile'
  },
  'firwa': {
    matchMethod: 1,
    repeat: true,
    sub: 'kinyume na maumbile'
  },
  'kuma': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kike'
  },
  'kumalake': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'kumalamsenge': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'kumamae': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'kundu': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'Kusagana': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'Kutomba': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'Kutombana': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'Kahaba': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'malaya': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'matako': {
    matchMethod: 1,
    repeat: true,
    sub: 'makalio'
  },
  'mavuzi': {
    matchMethod: 1,
    repeat: true,
    sub: 'nywele za sehemu ya siri'
  },
  'mbolo': {
    matchMethod: 1,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'mboo': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'mfiraji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mfirwaji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mjanechuo': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mkundu': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'mngese': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'msagaji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'msenge': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mxenge': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'msengenyaji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mshenzi': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'nyoko': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'nyoo': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'pumbu': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'senge': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'shahawa': {
    matchMethod: 1,
    repeat: true,
    sub: 'manii'
  },
  'shenzi': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'tako': {
    matchMethod: 0,
    repeat: true,
    sub: 'kalio'
  },
  'tiana': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'tiwa': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'tomb': {
    matchMethod: 1,
    repeat: true,
    sub: 'tendo la ndoa'
  },
  'tomba': {
    matchMethod: 1,
    repeat: true,
    sub: 'tendo la ndoa'
  },
  'tombana': {
    matchMethod: 1,
    repeat: true,
    sub: 'tendo la ndoa'
  },
  'tombwa': {
    matchMethod: 1,
    repeat: true,
    sub: 'tendo la ndoa'
  },
  'uboo': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'ubolo': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'kisimi': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'kicmi': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'kixmi': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'usenge': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'ufiraji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'ufirwaji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'tahira': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  }
});

_defineProperty(Config, "_defaultWords", Config._maneno);

_defineProperty(Config, "_filterMethodNames", ['Censor', 'Substitute', 'Remove']);

_defineProperty(Config, "_matchMethodNames", ['Exact', 'Partial', 'Whole', 'Per-Word', 'Regular-Expression']);

_defineProperty(Config, "_maxBytes", 6500);

_defineProperty(Config, "_maxWords", 100);

_defineProperty(Config, "_wordsPattern", /^_words\d+/);

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _helper = __webpack_require__(0);

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class Domain {
  constructor() {
    _defineProperty(this, "tab", void 0);

    _defineProperty(this, "url", void 0);

    _defineProperty(this, "hostname", void 0);
  }

  static domainMatch(domain, domains) {
    let result = false;

    for (let x = 0; x < domains.length; x++) {
      let domainRegex = new RegExp('(^|\.)' + domains[x], 'i');

      if (domainRegex.test(domain)) {
        result = true;
        break;
      }
    }

    return result;
  } // If a parent domain (example.com) is included, it will not match all subdomains.
  // If a subdomain is included, it will match itself and the parent, if present.


  static removeFromList(domain, domains) {
    let domainRegex;
    let newDomainsList = domains;

    for (let x = 0; x < domains.length; x++) {
      domainRegex = new RegExp('(^|\.)' + domains[x], 'i');

      if (domainRegex.test(domain)) {
        newDomainsList = (0, _helper.removeFromArray)(newDomainsList, domains[x]);
      }
    }

    return newDomainsList;
  }

  static getCurrentTab() {
    /* istanbul ignore next */
    return new Promise(function (resolve, reject) {
      chrome.tabs.query({
        active: true,
        currentWindow: true
      }, function (tabs) {
        resolve(tabs[0]);
      });
    });
  }

  async load() {
    this.tab = await Domain.getCurrentTab();
    this.url = new URL(this.tab.url);
    this.hostname = this.url.hostname;
  }

}

exports.default = Domain;

/***/ }),
/* 4 */,
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Filter = void 0;

var _word = _interopRequireDefault(__webpack_require__(6));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class Filter {
  constructor() {
    _defineProperty(this, "cfg", void 0);

    _defineProperty(this, "counter", void 0);

    _defineProperty(this, "wordList", void 0);

    _defineProperty(this, "wordRegExps", void 0);

    this.counter = 0;
    this.wordList = [];
    this.wordRegExps = [];
  }

  foundMatch(word) {
    this.counter++;
  } // Parse the profanity list
  // ["exact", "partial", "whole", "disabled"]


  generateRegexpList() {
    let self = this;
    self.wordRegExps = []; // console.time('generateRegexpList'); // Benchmark - Call Time
    // console.count('generateRegexpList: words to filter'); // Benchmarking - Executaion Count

    if (self.cfg.filterMethod == 2) {
      // Special regexp for "Remove" filter, uses per-word matchMethods
      self.wordList.forEach(word => {
        let repeat = self.cfg.repeatForWord(word);

        if (self.cfg.words[word].matchMethod == 0) {
          // If word matchMethod is exact
          self.wordRegExps.push(_word.default.buildRegexpForRemoveExact(word, repeat));
        } else if (self.cfg.words[word].matchMethod == 4) {
          // If word matchMethod is RegExp
          self.wordRegExps.push(new RegExp(word, 'gi'));
        } else {
          self.wordRegExps.push(_word.default.buildRegexpForRemovePart(word, repeat));
        }
      });
    } else {
      switch (self.cfg.globalMatchMethod) {
        case 0:
          // Global: Exact match
          self.wordList.forEach(word => {
            let repeat = self.cfg.repeatForWord(word);
            self.wordRegExps.push(_word.default.buildExactRegexp(word, repeat));
          });
          break;

        case 2:
          // Global: Whole word match
          self.wordList.forEach(word => {
            let repeat = self.cfg.repeatForWord(word);
            self.wordRegExps.push(_word.default.buildWholeRegexp(word, repeat));
          });
          break;

        case 3:
          // Per-word matching
          self.wordList.forEach(word => {
            let repeat = self.cfg.repeatForWord(word);

            switch (self.cfg.words[word].matchMethod) {
              case 0:
                self.wordRegExps.push(_word.default.buildExactRegexp(word, repeat));
                break;
              // Exact match

              case 2:
                self.wordRegExps.push(_word.default.buildWholeRegexp(word, repeat));
                break;
              // Whole word match

              case 4:
                self.wordRegExps.push(new RegExp(word, 'gi'));
                break;
              // Regular Expression (Advanced)

              default:
                self.wordRegExps.push(_word.default.buildPartRegexp(word, repeat));
                break;
              // case 1 - Partial word match (Default)
            }
          });
          break;

        default:
          // case 1 - Global: Partial word match (Default)
          self.wordList.forEach(word => {
            let repeat = self.cfg.repeatForWord(word);
            self.wordRegExps.push(_word.default.buildPartRegexp(word, repeat));
          });
          break;
      }
    } // console.timeEnd('generateRegexpList'); // Benchmark - Call Time

  } // Sort the words array by longest (most-specific) first
  // Config Dependencies: words


  generateWordList() {
    this.wordList = null;
    this.wordList = Object.keys(this.cfg.words).sort((a, b) => {
      return b.length - a.length;
    });
  } // Config Dependencies: filterMethod, wordList,
  // censorFixedLength, preserveFirst, preserveLast, censorCharacter
  // words, defaultSubstitution, preserveCase


  replaceText(str, stats = true) {
    // console.count('replaceText'); // Benchmarking - Executaion Count
    let self = this;

    switch (self.cfg.filterMethod) {
      case 0:
        // Censor
        self.wordRegExps.forEach((regExp, index) => {
          str = str.replace(regExp, function (match, arg1, arg2, arg3, arg4, arg5) {
            if (stats) {
              self.foundMatch(self.wordList[index]);
            }

            if (regExp.unicode) {
              match = arg2;
            } // Workaround for unicode word boundaries


            let censoredString = '';
            let censorLength = self.cfg.censorFixedLength > 0 ? self.cfg.censorFixedLength : match.length;

            if (self.cfg.preserveFirst && self.cfg.preserveLast) {
              censoredString = match[0] + self.cfg.censorCharacter.repeat(censorLength - 2) + match.slice(-1);
            } else if (self.cfg.preserveFirst) {
              censoredString = match[0] + self.cfg.censorCharacter.repeat(censorLength - 1);
            } else if (self.cfg.preserveLast) {
              censoredString = self.cfg.censorCharacter.repeat(censorLength - 1) + match.slice(-1);
            } else {
              censoredString = self.cfg.censorCharacter.repeat(censorLength);
            }

            if (regExp.unicode) {
              censoredString = arg1 + censoredString + arg3;
            } // Workaround for unicode word boundaries
            // console.log('Censor match:', match, censoredString); // DEBUG


            return censoredString;
          });
        });
        break;

      case 1:
        // Substitute
        self.wordRegExps.forEach((regExp, index) => {
          str = str.replace(regExp, function (match, arg1, arg2, arg3, arg4, arg5) {
            if (stats) {
              self.foundMatch(self.wordList[index]);
            }

            if (regExp.unicode) {
              match = arg2;
            } // Workaround for unicode word boundaries


            let sub = self.cfg.words[self.wordList[index]].sub || self.cfg.defaultSubstitution; // Make substitution match case of original match

            if (self.cfg.preserveCase) {
              if (_word.default.allUpperCase(match)) {
                sub = sub.toUpperCase();
              } else if (_word.default.capitalized(match)) {
                sub = _word.default.capitalize(sub);
              }
            }

            if (self.cfg.substitutionMark) {
              sub = '[' + sub + ']';
            }

            if (regExp.unicode) {
              sub = arg1 + sub + arg3;
            } // Workaround for unicode word boundaries
            // console.log('Substitute match:', match, sub); // DEBUG


            return sub;
          });
        });
        break;

      case 2:
        // Remove
        self.wordRegExps.forEach((regExp, index) => {
          str = str.replace(regExp, function (match, arg1, arg2, arg3, arg4, arg5) {
            // console.log('\nmatch: ', match, '\narg1: ', arg1, '\narg2: ', arg2, '\narg3: ', arg3, '\narg4: ', arg4, '\narg5: ', arg5); // DEBUG
            if (stats) {
              self.foundMatch(self.wordList[index]);
            }

            if (regExp.unicode) {
              // Workaround for unicode word boundaries
              if (_word.default.whitespaceRegExp.test(arg1) && _word.default.whitespaceRegExp.test(arg3)) {
                // If both surrounds are whitespace (only need 1)
                return arg1;
              } else if (_word.default.nonWordRegExp.test(arg1) || _word.default.nonWordRegExp.test(arg3)) {
                // If there is more than just whitesapce (ex. ',')
                return (arg1 + arg3).trim();
              } else {
                return '';
              }
            } else {
              // Don't remove both leading and trailing whitespace
              if (_word.default.whitespaceRegExp.test(match[0]) && _word.default.whitespaceRegExp.test(match[match.length - 1])) {
                return match[0];
              } else {
                // console.log('Remove match:', match); // DEBUG
                return '';
              }
            }
          });
        });
        break;
    }

    return str;
  }

  init() {
    this.generateWordList();
    this.generateRegexpList();
  }

}

exports.Filter = Filter;

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class Word {
  static allLowerCase(string) {
    return string.toLowerCase() === string;
  }

  static allUpperCase(string) {
    return string.toUpperCase() === string;
  } // Word must match exactly (not sub-string)
  // /\bword\b/gi


  static buildExactRegexp(str, matchRepeated = false) {
    try {
      if (Word.containsDoubleByte(str)) {
        // Work around for lack of word boundary support for unicode characters
        // /(^|[\s.,'"+!?|-]+)(word)([\s.,'"+!?|-]+|$)/giu
        return new RegExp('(^|' + Word._unicodeWordBoundary + '+)(' + Word.processPhrase(str, matchRepeated) + ')(' + Word._unicodeWordBoundary + '+|$)', 'giu');
      } else if (str.match(Word._edgePunctuationRegExp)) {
        // Begin or end with punctuation (not \w))
        return new RegExp('(^|\\s)(' + Word.processPhrase(str, matchRepeated) + ')(\\s|$)', 'giu');
      } else {
        return new RegExp('\\b' + Word.processPhrase(str, matchRepeated) + '\\b', 'gi');
      }
    } catch (e) {
      throw new Error('Failed to create RegExp for "' + str + '" - ' + e.name + ' ' + e.message);
    }
  } // Match any part of a word (sub-string)
  // /word/gi


  static buildPartRegexp(str, matchRepeated = false) {
    try {
      return new RegExp(Word.processPhrase(str, matchRepeated), 'gi');
    } catch (e) {
      throw new Error('Failed to create RegExp for "' + str + '" - ' + e.name + ' ' + e.message);
    }
  } // Match entire word that contains sub-string and surrounding whitespace
  // /\s?\bword\b\s?/gi


  static buildRegexpForRemoveExact(str, matchRepeated = false) {
    try {
      if (Word.containsDoubleByte(str)) {
        // Work around for lack of word boundary support for unicode characters
        // /(^|[\s.,'"+!?|-]+)(word)([\s.,'"+!?|-]+|$)/giu
        return new RegExp('(^|' + Word._unicodeWordBoundary + ')(' + Word.processPhrase(str, matchRepeated) + ')(' + Word._unicodeWordBoundary + '|$)', 'giu');
      } else if (str.match(Word._edgePunctuationRegExp)) {
        // Begin or end with punctuation (not \w))
        return new RegExp('(^|\\s)(' + Word.processPhrase(str, matchRepeated) + ')(\\s|$)', 'giu');
      } else {
        return new RegExp('\\s?\\b' + Word.processPhrase(str, matchRepeated) + '\\b\\s?', 'gi');
      }
    } catch (e) {
      throw new Error('Failed to create RegExp for "' + str + '" - ' + e.name + ' ' + e.message);
    }
  } // Match entire word that contains sub-string and surrounding whitespace
  // /\s?\b[\w-]*word[\w-]*\b\s?/gi


  static buildRegexpForRemovePart(str, matchRepeated = false) {
    try {
      if (Word.containsDoubleByte(str)) {
        // Work around for lack of word boundary support for unicode characters
        // /(^|[\s.,'"+!?|-]?)[\w-]*(word)[\w-]*([\s.,'"+!?|-]?|$)/giu
        return new RegExp('(^|' + Word._unicodeWordBoundary + '?)([\\w-]*' + Word.processPhrase(str, matchRepeated) + '[\\w-]*)(' + Word._unicodeWordBoundary + '?|$)', 'giu');
      } else if (str.match(Word._edgePunctuationRegExp)) {
        // Begin or end with punctuation (not \w))
        return new RegExp('(^|\\s)([\\w-]*' + Word.processPhrase(str, matchRepeated) + '[\\w-]*)(\\s|$)', 'giu');
      } else {
        return new RegExp('\\s?\\b[\\w-]*' + Word.processPhrase(str, matchRepeated) + '[\\w-]*\\b\\s?', 'gi');
      }
    } catch (e) {
      throw new Error('Failed to create RegExp for "' + str + '" - ' + e.name + ' ' + e.message);
    }
  } // Match entire word that contains sub-string
  // /\b[\w-]*word[\w-]*\b/gi


  static buildWholeRegexp(str, matchRepeated = false) {
    try {
      if (Word.containsDoubleByte(str)) {
        // Work around for lack of word boundary support for unicode characters
        // (^|[\s.,'"+!?|-]*)([\S]*куче[\S]*)([\s.,'"+!?|-]*|$)/giu
        return new RegExp('(^|' + Word._unicodeWordBoundary + '*)([\\S]*' + Word.processPhrase(str, matchRepeated) + '[\\S]*)(' + Word._unicodeWordBoundary + '*|$)', 'giu');
      } else if (str.match(Word._edgePunctuationRegExp)) {
        // Begin or end with punctuation (not \w))
        return new RegExp('(^|\\s)([\\S]*' + Word.processPhrase(str, matchRepeated) + '[\\S]*)(\\s|$)', 'giu');
      } else {
        return new RegExp('\\b[\\w-]*' + Word.processPhrase(str, matchRepeated) + '[\\w-]*\\b', 'gi');
      }
    } catch (e) {
      throw new Error('Failed to create RegExp for "' + str + '" - ' + e.name + ' ' + e.message);
    }
  }

  static capitalize(string) {
    return string.charAt(0).toUpperCase() + string.substr(1);
  }

  static capitalized(string) {
    return string.charAt(0).toUpperCase() === string.charAt(0);
  }

  static containsDoubleByte(str) {
    if (!str.length) return false;
    if (str.charCodeAt(0) > 127) return true;
    return Word._unicodeRegExp.test(str);
  } // /[-\/\\^$*+?.()|[\]{}]/g
  // /[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g
  // Removing '-' for '/пресс-релиз/, giu'


  static escapeRegExp(str) {
    return str.replace(Word._escapeRegExp, '\\$&');
  } // Process the rest of the word (word excluding first character)
  // This will escape the word and optionally include repeating characters


  static processPhrase(str, matchRepeated) {
    var escaped = Word.escapeRegExp(str);

    if (matchRepeated) {
      return Word.repeatingCharacterRegexp(escaped);
    }

    return escaped;
  } // Regexp to match repeating characters
  // Word: /w+o+r+d+/gi


  static repeatingCharacterRegexp(str) {
    if (str.includes('\\')) {
      var repeat = '';

      for (var i = 0; i < str.length; i++) {
        if (str[i] === '\\') {
          repeat += str[i] + str[i + 1] + '+';
          i++;
        } else {
          repeat += str[i] + '+';
        }
      }

      return repeat;
    } else {
      return str.split('').map(letter => letter + '+').join('');
    }
  }

}

exports.default = Word;

_defineProperty(Word, "_edgePunctuationRegExp", /(^[,.'"!?%$]|[,.'"!?%$]$)/);

_defineProperty(Word, "_escapeRegExp", /[\/\\^$*+?.()|[\]{}]/g);

_defineProperty(Word, "_unicodeRegExp", /[^\u0000-\u00ff]/);

_defineProperty(Word, "_unicodeWordBoundary", '[\\s.,\'"+!?|-]');

_defineProperty(Word, "nonWordRegExp", new RegExp('^\\s*[^\\w]+\\s*$', 'g'));

_defineProperty(Word, "whitespaceRegExp", /^\s+$/);

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class WebAudio {
  constructor(filter) {
    _defineProperty(this, "filter", void 0);

    _defineProperty(this, "lastFilteredNode", void 0);

    _defineProperty(this, "muted", void 0);

    _defineProperty(this, "muteMethod", void 0);

    _defineProperty(this, "showSubtitles", void 0);

    _defineProperty(this, "site", void 0);

    _defineProperty(this, "sites", void 0);

    _defineProperty(this, "subtitleSelector", void 0);

    _defineProperty(this, "supportedNode", void 0);

    _defineProperty(this, "supportedPage", void 0);

    _defineProperty(this, "unmuteDelay", void 0);

    _defineProperty(this, "volume", void 0);

    _defineProperty(this, "youTube", void 0);

    _defineProperty(this, "youTubeAutoSubsMin", void 0);

    this.filter = filter;
    this.lastFilteredNode = null;
    this.muted = false;
    this.muteMethod = filter.cfg.muteMethod;
    this.showSubtitles = filter.cfg.showSubtitles;
    this.sites = Object.assign(WebAudio.sites, filter.cfg.customAudioSites);
    Object.keys(filter.cfg.customAudioSites).forEach(x => {
      this.sites[x]._custom = true;
    });
    this.unmuteDelay = 0;
    this.volume = 1;
    this.youTubeAutoSubsMin = filter.cfg.youTubeAutoSubsMin; // Additional setup

    this.site = this.sites[filter.hostname];
    this.supportedPage = this.site != null;

    if (this.site) {
      if (filter.hostname == 'www.youtube.com') {
        this.youTube = true;
      }

      if (this.site.videoCueMode) {
        this.site = Object.assign(WebAudio._videoModeDefaults, this.site);
        setInterval(this.watchForVideo, this.site.videoInterval, this);
      }

      this.subtitleSelector = this.site.subtitleSelector;
      this.supportedNode = this.buildSupportedNodeFunction();
    }
  }

  buildSupportedNodeFunction() {
    let site = this.site; // Plain text mode

    if (site.textParentSelector) {
      return new Function('node', `
      if (node.nodeName === '#text') {
        let textParent = document.querySelector('${site.textParentSelector}');
        if (textParent && textParent.contains(node)) { return true; }
      }
      return false;`);
    } // Video cue mode


    if (site.videoCueMode) {
      return new Function('node', 'return false;');
    } // Element mode (Default)


    if (!site.tagName) {
      throw 'tagName is required.';
    }

    return new Function('node', `
    if (node.nodeName == '${site.tagName.toUpperCase()}') {
      ${site.className ? `if (!node.className || !node.className.includes('${site.className}')) { return false; }` : ''}
      ${site.dataPropPresent ? `if (!node.dataset || !node.dataset.hasOwnProperty('${site.dataPropPresent}')) { return false; }` : ''}
      ${site.hasChildrenElements ? 'if (typeof node.childElementCount !== "number" || node.childElementCount < 1) { return false; }' : ''}
      ${site.subtitleSelector ? `if (typeof node.querySelector !== 'function' || !node.querySelector('${site.subtitleSelector}')) { return false; }` : ''}
      ${site.containsSelector ? `if (typeof node.querySelector !== 'function' || !node.querySelector('${site.containsSelector}')) { return false; }` : ''}
      return true;
    } else {
      return false;
    }`.replace(/^\s*\n/gm, ''));
  }

  clean(subtitleContainer) {
    let filtered = false;
    let subtitles = this.subtitleSelector ? subtitleContainer.querySelectorAll(this.subtitleSelector) : [subtitleContainer]; // Process subtitles

    subtitles.forEach(subtitle => {
      // innerText handles line feeds/spacing better, but is not available to #text nodes
      let textMethod = subtitle.nodeName === '#text' ? 'textContent' : 'innerText';
      let result = this.filter.replaceTextResult(subtitle[textMethod]);

      if (result.modified) {
        filtered = true;
        subtitle[textMethod] = result.filtered;
        this.mute(); // Mute the audio if we haven't already

        if (subtitle.nodeName === '#text') {
          this.lastFilteredNode = subtitle;
        }
      }
    }); // Subtitle display - 0: Show all, 1: Show only filtered, 2: Show only unfiltered, 3: Hide all

    switch (this.showSubtitles) {
      case 1:
        if (!filtered) {
          subtitles.forEach(subtitle => {
            subtitle.textContent = '';
          });
        }

        break;

      case 2:
        if (filtered) {
          subtitles.forEach(subtitle => {
            subtitle.textContent = '';
          });
        }

        break;

      case 3:
        subtitles.forEach(subtitle => {
          subtitle.textContent = '';
        });
        break;
    }

    if (filtered) {
      this.filter.updateCounterBadge();
    } // Update if modified

  }

  cleanYouTubeAutoSubs(node) {
    let result = this.filter.replaceTextResult(node.textContent);

    if (result.modified) {
      node.textContent = result.filtered;
      this.mute();
      this.unmuteDelay = null;
      this.filter.updateCounterBadge();
    } else {
      if (this.muted) {
        if (this.youTubeAutoSubsMin > 0) {
          let currentTime = document.getElementsByTagName('video')[0].currentTime;

          if (this.unmuteDelay == null) {
            // Start tracking unmuteDelay when next unfiltered word is found
            this.unmuteDelay = currentTime;
          } else {
            if (currentTime < this.unmuteDelay) {
              this.unmuteDelay = 0;
            } // Reset unmuteDelay if video reversed


            if (currentTime > this.unmuteDelay + this.youTubeAutoSubsMin) {
              // Unmute if its been long enough
              this.unmute();
            }
          }
        } else {
          // Unmute immediately if youTubeAutoSubsMin = 0
          this.unmute();
        }
      }
    }
  }

  getVideoTextTrack(video) {
    if (video.textTracks && video.textTracks.length > 0) {
      if (this.site.videoCueLanguage) {
        for (let i = 0; i < video.textTracks.length; i++) {
          if (video.textTracks[i].language == this.site.videoCueLanguage) {
            return video.textTracks[i];
          }
        }
      }

      return video.textTracks[0];
    }
  }

  mute(video) {
    if (!this.muted) {
      this.muted = true;

      switch (this.muteMethod) {
        case 0:
          // Mute tab
          chrome.runtime.sendMessage({
            mute: true
          });
          break;

        case 1:
          {
            // Mute video
            if (!video) {
              video = document.querySelector('video');
            }

            if (video && video.volume != null) {
              this.volume = video.volume; // Save original volume

              video.volume = 0;
            }

            break;
          }
      }
    }
  }

  playing(video) {
    return !!(video.currentTime > 0 && !video.paused && !video.ended && video.readyState > 2);
  }

  processCues(cues) {
    for (let i = 0; i < cues.length; i++) {
      let cue = cues[i];

      if (cue.hasOwnProperty('filtered')) {
        continue;
      }

      if (this.site.videoCueSync) {
        cue.startTime += this.site.videoCueSync;
        cue.endTime += this.site.videoCueSync;
      }

      cue.index = i;
      let result = this.filter.replaceTextResult(cue.text);

      if (result.modified) {
        cue.filtered = true;
        cue.originalText = cue.text;
        cue.text = result.filtered;
      } else {
        cue.filtered = false;
      }
    }
  }

  unmute(video) {
    if (this.muted) {
      this.muted = false;

      switch (this.muteMethod) {
        case 0:
          // Mute tab
          chrome.runtime.sendMessage({
            mute: false
          });
          break;

        case 1:
          {
            // Mute video
            if (!video) {
              video = document.querySelector('video');
            }

            if (video && video.volume != null) {
              video.volume = this.volume;
            }

            break;
          }
      }
    }
  }

  watchForVideo(instance) {
    let video = document.querySelector(instance.site.videoSelector);

    if (video && video.textTracks && instance.playing(video)) {
      let textTrack = instance.getVideoTextTrack(video);

      if (textTrack && !textTrack.oncuechange) {
        if (instance.showSubtitles == 3) {
          textTrack.mode = 'hidden';
        }

        textTrack.oncuechange = () => {
          if (textTrack.activeCues.length > 0) {
            let filtered = false;

            for (let i = 0; i < textTrack.activeCues.length; i++) {
              let activeCue = textTrack.activeCues[i];

              if (!activeCue.hasOwnProperty('filtered')) {
                let cues = textTrack.cues;
                instance.processCues(cues);
              }

              if (activeCue.filtered) {
                filtered = true;
              }
            }

            if (filtered) {
              instance.mute(video);

              switch (instance.showSubtitles) {
                case 1:
                  textTrack.mode = 'showing';
                  break;

                case 2:
                  textTrack.mode = 'hidden';
                  break;
              }
            } else {
              instance.unmute(video);

              switch (instance.showSubtitles) {
                case 1:
                  textTrack.mode = 'hidden';
                  break;

                case 2:
                  textTrack.mode = 'showing';
                  break;
              }
            }
          } else {
            // No active cues
            instance.unmute(video);
          }
        };
      }
    }
  }

  youTubeAutoSubsCurrentRow(node) {
    return !!(node.parentElement.parentElement == node.parentElement.parentElement.parentElement.lastChild);
  }

  youTubeAutoSubsNodeIsSubtitleText(node) {
    let captionWindow = document.querySelector('div.caption-window'); // YouTube Auto-gen subs

    return !!(captionWindow && captionWindow.contains(node));
  }

  youTubeAutoSubsPresent() {
    return !!document.querySelector('div.ytp-caption-window-rollup');
  }

  youTubeAutoSubsSupportedNode(node) {
    if (node.nodeName == '#text' && node.textContent != '') {
      return !!this.youTubeAutoSubsNodeIsSubtitleText(node);
    }

    return false;
  }

}

exports.default = WebAudio;

_defineProperty(WebAudio, "_videoModeDefaults", {
  videoInterval: 200,
  videoSelector: 'video'
});

_defineProperty(WebAudio, "sites", {
  'abc.go.com': {
    className: 'akamai-caption-text',
    tagName: 'DIV'
  },
  'app.plex.tv': {
    dataPropPresent: 'dialogueId',
    subtitleSelector: 'span > span',
    tagName: 'DIV'
  },
  'www.amazon.com': {
    subtitleSelector: 'span.timedTextBackground',
    tagName: 'P'
  },
  'www.dishanywhere.com': {
    className: 'bmpui-ui-subtitle-label',
    tagName: 'SPAN'
  },
  'www.fox.com': {
    className: 'jw-text-track-container',
    subtitleSelector: 'div.jw-text-track-cue',
    tagName: 'DIV'
  },
  'www.hulu.com': {
    className: 'caption-text-box',
    subtitleSelector: 'p',
    tagName: 'DIV'
  },
  'www.nbc.com': {
    className: 'ttr-line',
    subtitleSelector: 'span.ttr-cue',
    tagName: 'DIV'
  },
  'www.netflix.com': {
    className: 'player-timedtext-text-container',
    subtitleSelector: 'span',
    tagName: 'DIV'
  },
  'www.sonycrackle.com': {
    textParentSelector: 'div.clpp-subtitles-container'
  },
  'www.syfy.com': {
    className: 'ttr-line',
    subtitleSelector: 'span.ttr-cue',
    tagName: 'DIV'
  },
  'www.universalkids.com': {
    subtitleSelector: 'div.gwt-HTML',
    tagName: 'DIV'
  },
  'www.usanetwork.com': {
    className: 'ttr-line',
    subtitleSelector: 'span.ttr-cue',
    tagName: 'DIV'
  },
  'www.vudu.com': {
    subtitleSelector: 'span.subtitles',
    tagName: 'DIV'
  },
  'www.youtube.com': {
    className: 'caption-window',
    subtitleSelector: 'span.ytp-caption-segment',
    tagName: 'DIV'
  }
});

/***/ }),
/* 8 */,
/* 9 */,
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _domain = _interopRequireDefault(__webpack_require__(3));

var _filter = __webpack_require__(5);

var _page = _interopRequireDefault(__webpack_require__(11));

var _webAudio = _interopRequireDefault(__webpack_require__(7));

var _webConfig = _interopRequireDefault(__webpack_require__(1));

__webpack_require__(12);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class WebFilter extends _filter.Filter {
  constructor() {
    super();

    _defineProperty(this, "advanced", void 0);

    _defineProperty(this, "audio", void 0);

    _defineProperty(this, "audioOnly", void 0);

    _defineProperty(this, "cfg", void 0);

    _defineProperty(this, "hostname", void 0);

    _defineProperty(this, "iframe", void 0);

    _defineProperty(this, "mutePage", void 0);

    _defineProperty(this, "summary", void 0);

    _defineProperty(this, "youTubeMutePage", void 0);

    this.advanced = false;
    this.mutePage = false;
    this.summary = {};
  } // Always use the top frame for page check


  advancedPage() {
    return _domain.default.domainMatch(this.hostname, this.cfg.advancedDomains);
  }

  advancedReplaceText(node) {
    filter.wordRegExps.forEach(regExp => {
      // @ts-ignore - External library function
      findAndReplaceDOMText(node, {
        preset: 'prose',
        find: regExp,
        replace: function (portion, match) {
          // console.log('[APF] Advanced node match:', node.textContent); // Debug: Filter - Advanced match
          return filter.replaceText(match[0]);
        }
      });
    });
  }

  checkMutationForProfanity(mutation) {
    // console.count('[APF] filter.checkMutationForProfanity() count'); // Benchmark: Filter
    // console.log('[APF] Mutation observed:', mutation); // Debug: Filter - Mutation
    mutation.addedNodes.forEach(node => {
      if (!_page.default.isForbiddenNode(node)) {
        // console.log('[APF] Added node(s):', node); // Debug: Filter - Mutation addedNodes
        if (filter.youTubeMutePage && filter.audio.youTubeAutoSubsPresent()) {
          // YouTube Auto subs
          if (filter.audio.youTubeAutoSubsSupportedNode(node)) {
            if (filter.audio.youTubeAutoSubsCurrentRow(node)) {
              // console.log('[APF] YouTube subtitle node:', node); // Debug: Audio
              filter.audio.cleanYouTubeAutoSubs(node);
            } else {
              filter.cleanNode(node, false);
            }
          } else if (!filter.audio.youTubeAutoSubsNodeIsSubtitleText(node)) {
            filter.cleanNode(node); // Clean the rest of the page
          }
        } else if (filter.mutePage && filter.audio.supportedNode(node)) {
          // console.log('[APF] Audio subtitle node:', node); // Debug: Audio
          filter.audio.clean(node);
        } else if (!filter.audioOnly) {
          // console.log('[APF] New node to filter', node); // Debug: Filter
          if (filter.advanced && node.parentNode) {
            filter.advancedReplaceText(node);
          } else {
            filter.cleanNode(node);
          }
        }
      } // else { console.log('[APF] Forbidden node:', node); } // Debug: Filter - Mutation addedNodes

    }); // Check removed nodes to see if we should unmute

    if (filter.mutePage && filter.audio.muted) {
      mutation.removedNodes.forEach(node => {
        if (filter.audio.supportedNode(node) || node == filter.audio.lastFilteredNode) {
          filter.audio.unmute();
        }
      });
    } // Only process mutation change if target is text


    if (!filter.audioOnly && mutation.target && mutation.target.nodeName == '#text') {
      filter.checkMutationTargetTextForProfanity(mutation);
    }
  }

  checkMutationTargetTextForProfanity(mutation) {
    // console.count('checkMutationTargetTextForProfanity'); // Benchmark: Filter
    // console.log('[APF] Process mutation.target:', mutation.target, mutation.target.data); // Debug: Filter - Mutation text
    if (!_page.default.isForbiddenNode(mutation.target)) {
      let result = this.replaceTextResult(mutation.target.data);

      if (result.modified) {
        // console.log('[APF] Text target changed:', result.original, result.filtered); // Debug: Filter - Mutation text
        mutation.target.data = result.filtered;
      }
    } // else { console.log('[APF] Forbidden mutation.target node:', mutation.target); } // Debug: Filter - Mutation text

  }

  cleanNode(node, stats = true) {
    if (_page.default.isForbiddenNode(node)) {
      return false;
    }

    if (node.childElementCount > 0) {
      // Tree node
      let treeWalker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT);

      while (treeWalker.nextNode()) {
        if (treeWalker.currentNode.childNodes.length > 0) {
          treeWalker.currentNode.childNodes.forEach(childNode => {
            this.cleanNode(childNode, stats);
          });
        } else {
          this.cleanNode(treeWalker.currentNode, stats);
        }
      }
    } else {
      // Leaf node
      if (node.nodeName) {
        if (node.textContent && node.textContent.trim() != '') {
          let result = this.replaceTextResult(node.textContent, stats);

          if (result.modified) {
            // console.log('[APF] Normal node changed:', result.original, result.filtered); // Debug: Filter - Mutation node filtered
            node.textContent = result.filtered;
          }
        } else if (node.shadowRoot != undefined) {
          shadowObserver.observe(node.shadowRoot, observerConfig);
        }
      } // else { console.log('[APF] node without nodeName:', node); } // Debug: Filter

    }
  }

  async cleanPage() {
    // @ts-ignore: Type WebConfig is not assignable to type Config
    this.cfg = await _webConfig.default.build(); // console.log('[APF] Config loaded', this.cfg); // Debug: General
    // Exit if the topmost frame is a disabled domain

    let message = {
      disabled: this.disabledPage()
    };

    if (message.disabled) {
      // console.log(`[APF] Disabled page: ${this.hostname} - exiting`); // Debug: General
      chrome.runtime.sendMessage(message);
      return false;
    } // Check for advanced mode on current domain


    this.advanced = this.advancedPage(); // if (this.advanced) { console.log(`[APF] Enabling advanced match mode on ${this.hostname}`); } // Debug: General
    // Detect if we should mute audio for the current page

    if (this.cfg.muteAudio) {
      this.audio = new _webAudio.default(this);
      this.mutePage = this.audio.supportedPage; // if (this.mutePage) { console.log(`[APF] Enabling audio muting on ${this.hostname}`); } // Debug: Audio

      this.youTubeMutePage = this.audio.youTube;
    } // Disable if muteAudioOnly mode is active and this is not a suported page


    if (this.cfg.muteAudioOnly) {
      if (this.mutePage) {
        this.audioOnly = true;
      } else {
        message.disabled = true; // console.log('[APF] Non audio page in audio only mode - exiting'); // Debug: Audio

        chrome.runtime.sendMessage(message);
        return false;
      }
    }

    this.sendInitState(message);
    this.popupListener(); // Remove profanity from the main document and watch for new nodes

    this.init(); // console.log('[APF] Filter initialized.', this); // Debug: General

    if (!this.audioOnly) {
      this.advanced ? this.advancedReplaceText(document) : this.cleanNode(document);
    }

    this.updateCounterBadge();
    observer.observe(document, observerConfig);
  } // Always use the top frame for page check


  disabledPage() {
    return _domain.default.domainMatch(this.hostname, this.cfg.disabledDomains);
  }

  foundMatch(word) {
    super.foundMatch(word);

    if (this.cfg.showSummary) {
      if (this.summary[word]) {
        this.summary[word].count += 1;
      } else {
        let result;

        if (this.cfg.words[word].matchMethod == 4) {
          // Regexp
          result = this.cfg.words[word].sub || this.cfg.defaultSubstitution;
        } else {
          result = filter.replaceText(word, false);
        }

        this.summary[word] = {
          filtered: result,
          count: 1
        };
      }
    }
  } // Listen for data requests from Popup


  popupListener() {
    /* istanbul ignore next */
    chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
      if (filter.cfg.showSummary && request.popup && (filter.counter > 0 || filter.mutePage)) {
        chrome.runtime.sendMessage({
          mutePage: filter.mutePage,
          summary: filter.summary
        });
      }
    });
  }

  processMutations(mutations) {
    mutations.forEach(function (mutation) {
      filter.checkMutationForProfanity(mutation);
    });
    filter.updateCounterBadge();
  }

  replaceTextResult(string, stats = true) {
    let result = {};
    result.original = string;
    result.filtered = filter.replaceText(string, stats);
    result.modified = result.filtered != string;
    return result;
  }

  sendInitState(message) {
    // Reset muted state on page load if we muted the tab audio
    if (this.cfg.muteAudio && this.cfg.muteMethod == 0) {
      message.clearMute = true;
    } // Send page state to color icon badge


    message.setBadgeColor = true;
    message.advanced = this.advanced;
    message.mutePage = this.mutePage;

    if (this.mutePage && this.cfg.showCounter) {
      message.counter = this.counter;
    } // Always show counter when muting audio


    chrome.runtime.sendMessage(message);
  }

  updateCounterBadge() {
    /* istanbul ignore next */
    // console.count('updateCounterBadge'); // Benchmark: Filter
    if (this.counter > 0) {
      try {
        if (this.cfg.showCounter) chrome.runtime.sendMessage({
          counter: this.counter
        });
        if (this.cfg.showSummary) chrome.runtime.sendMessage({
          summary: this.summary
        });
      } catch (e) {// console.log('Failed to sendMessage', e); // Error - Extension context invalidated.
      }
    }
  }

} // Global


exports.default = WebFilter;
let filter = new WebFilter();
let observer;
let shadowObserver;
let observerConfig = {
  characterData: true,
  characterDataOldValue: true,
  childList: true,
  subtree: true
};

if (typeof window !== 'undefined' && ['[object Window]', '[object ContentScriptGlobalScope]'].includes({}.toString.call(window))) {
  observer = new MutationObserver(filter.processMutations);
  shadowObserver = new MutationObserver(filter.processMutations);
  filter.iframe = window != window.top; // The hostname should resolve to the browser window's URI (or the parent of an IFRAME) for disabled/advanced page checks

  if (window.location == window.parent.location || document.referrer == '') {
    filter.hostname = document.location.hostname;
  } else if (document.referrer != '') {
    filter.hostname = new URL(document.referrer).hostname;
  }
  /* istanbul ignore next */


  filter.cleanPage();
}

/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class Page {
  constructor() {
    _defineProperty(this, "xpathDocText", void 0);

    _defineProperty(this, "xpathNodeText", void 0);
  }

  // Returns true if a node should *not* be altered in any way
  static isForbiddenNode(node) {
    if (node.isContentEditable) {
      return true;
    } // Check if parentNode is a forbidden tag


    if (node.parentNode && (node.parentNode.isContentEditable || Page.forbiddenTags.includes(node.parentNode.nodeName))) {
      return true;
    } // Check if node is a forbidden tag


    return Page.forbiddenTags.includes(node.nodeName);
  }

}

exports.default = Page;

_defineProperty(Page, "forbiddenNodeRegExp", new RegExp('^\s*(<[a-z].+?\/?>|{.+?:.+?;.*}|https?:\/\/[^\s]+$)'));

_defineProperty(Page, "forbiddenTags", ['SCRIPT', 'STYLE', 'INPUT', 'TEXTAREA', 'IFRAME', 'LINK']);

/***/ }),
/* 12 */
/***/ (function(module, exports) {

/**
 * findAndReplaceDOMText v 0.4.6
 * @author James Padolsey http://james.padolsey.com
 * @license http://unlicense.org/UNLICENSE
 *
 * Matches the text of a DOM node against a regular expression
 * and replaces each match (or node-separated portions of the match)
 * in the specified element.
 */
(function (root, factory) {
	/////////////////////////////
	// Modifications:
	// 1. Comment out below code
	// 2. Attach function to global scope
	//
	// if (typeof module === 'object' && module.exports) {
	// 		// Node/CommonJS
	// 		module.exports = factory();
	// } else if (typeof define === 'function' && define.amd) {
	// 		// AMD. Register as an anonymous module.
	// 		define(factory);
	// } else {
	// 		// Browser globals
	// 		root.findAndReplaceDOMText = factory();
	// }

	// Only run in a browser
	if (typeof window !== 'undefined') {
		// Attach function to global scope
		window.findAndReplaceDOMText = factory();
	}
}(this, function factory() {

var PORTION_MODE_RETAIN = 'retain';
var PORTION_MODE_FIRST = 'first';

var doc = document;
var hasOwn = {}.hasOwnProperty;

function escapeRegExp(s) {
 return String(s).replace(/([.*+?^=!:${}()|[\]\/\\])/g, '\\$1');
}

function exposed() {
 // Try deprecated arg signature first:
 return deprecated.apply(null, arguments) || findAndReplaceDOMText.apply(null, arguments);
}

function deprecated(regex, node, replacement, captureGroup, elFilter) {
 if ((node && !node.nodeType) && arguments.length <= 2) {
	 return false;
 }
 var isReplacementFunction = typeof replacement == 'function';

 if (isReplacementFunction) {
	 replacement = (function(original) {
		 return function(portion, match) {
			 return original(portion.text, match.startIndex);
		 };
	 }(replacement));
 }

 // Awkward support for deprecated argument signature (<0.4.0)
 var instance = findAndReplaceDOMText(node, {

	 find: regex,

	 wrap: isReplacementFunction ? null : replacement,
	 replace: isReplacementFunction ? replacement : '$' + (captureGroup || '&'),

	 prepMatch: function(m, mi) {

		 // Support captureGroup (a deprecated feature)

		 if (!m[0]) throw 'findAndReplaceDOMText cannot handle zero-length matches';

		 if (captureGroup > 0) {
			 var cg = m[captureGroup];
			 m.index += m[0].indexOf(cg);
			 m[0] = cg;
		 }

		 m.endIndex = m.index + m[0].length;
		 m.startIndex = m.index;
		 m.index = mi;

		 return m;
	 },
	 filterElements: elFilter
 });

 exposed.revert = function() {
	 return instance.revert();
 };

 return true;
}

/**
* findAndReplaceDOMText
*
* Locates matches and replaces with replacementNode
*
* @param {Node} node Element or Text node to search within
* @param {RegExp} options.find The regular expression to match
* @param {String|Element} [options.wrap] A NodeName, or a Node to clone
* @param {String} [options.wrapClass] A classname to append to the wrapping element
* @param {String|Function} [options.replace='$&'] What to replace each match with
* @param {Function} [options.filterElements] A Function to be called to check whether to
*	process an element. (returning true = process element,
*	returning false = avoid element)
*/
function findAndReplaceDOMText(node, options) {
 return new Finder(node, options);
}

exposed.NON_PROSE_ELEMENTS = {
 br:1, hr:1,
 // Media / Source elements:
 script:1, style:1, img:1, video:1, audio:1, canvas:1, svg:1, map:1, object:1,
 // Input elements
 input:1, textarea:1, select:1, option:1, optgroup: 1, button:1
};

exposed.NON_CONTIGUOUS_PROSE_ELEMENTS = {

 // Elements that will not contain prose or block elements where we don't
 // want prose to be matches across element borders:

 // Block Elements
 address:1, article:1, aside:1, blockquote:1, dd:1, div:1,
 dl:1, fieldset:1, figcaption:1, figure:1, footer:1, form:1, h1:1, h2:1, h3:1,
 h4:1, h5:1, h6:1, header:1, hgroup:1, hr:1, main:1, nav:1, noscript:1, ol:1,
 output:1, p:1, pre:1, section:1, ul:1,
 // Other misc. elements that are not part of continuous inline prose:
 br:1, li: 1, summary: 1, dt:1, details:1, rp:1, rt:1, rtc:1,
 // Media / Source elements:
 script:1, style:1, img:1, video:1, audio:1, canvas:1, svg:1, map:1, object:1,
 // Input elements
 input:1, textarea:1, select:1, option:1, optgroup:1, button:1,
 // Table related elements:
 table:1, tbody:1, thead:1, th:1, tr:1, td:1, caption:1, col:1, tfoot:1, colgroup:1

};

exposed.NON_INLINE_PROSE = function(el) {
 return hasOwn.call(exposed.NON_CONTIGUOUS_PROSE_ELEMENTS, el.nodeName.toLowerCase());
};

// Presets accessed via `options.preset` when calling findAndReplaceDOMText():
exposed.PRESETS = {
 prose: {
	 forceContext: exposed.NON_INLINE_PROSE,
	 filterElements: function(el) {
		 return !hasOwn.call(exposed.NON_PROSE_ELEMENTS, el.nodeName.toLowerCase());
	 }
 }
};

exposed.Finder = Finder;

/**
* Finder -- encapsulates logic to find and replace.
*/
function Finder(node, options) {

 var preset = options.preset && exposed.PRESETS[options.preset];

 options.portionMode = options.portionMode || PORTION_MODE_RETAIN;

 if (preset) {
	 for (var i in preset) {
		 if (hasOwn.call(preset, i) && !hasOwn.call(options, i)) {
			 options[i] = preset[i];
		 }
	 }
 }

 this.node = node;
 this.options = options;

 // Enable match-preparation method to be passed as option:
 this.prepMatch = options.prepMatch || this.prepMatch;

 this.reverts = [];

 this.matches = this.search();

 if (this.matches.length) {
	 this.processMatches();
 }

}

Finder.prototype = {

 /**
	* Searches for all matches that comply with the instance's 'match' option
	*/
 search: function() {

	 var match;
	 var matchIndex = 0;
	 var offset = 0;
	 var regex = this.options.find;
	 var textAggregation = this.getAggregateText();
	 var matches = [];
	 var self = this;

	 regex = typeof regex === 'string' ? RegExp(escapeRegExp(regex), 'g') : regex;

	 matchAggregation(textAggregation);

	 function matchAggregation(textAggregation) {
		 for (var i = 0, l = textAggregation.length; i < l; ++i) {

			 var text = textAggregation[i];

			 if (typeof text !== 'string') {
				 // Deal with nested contexts: (recursive)
				 matchAggregation(text);
				 continue;
			 }

			 if (regex.global) {
				 while (match = regex.exec(text)) {
					 matches.push(self.prepMatch(match, matchIndex++, offset));
				 }
			 } else {
				 if (match = text.match(regex)) {
					 matches.push(self.prepMatch(match, 0, offset));
				 }
			 }

			 offset += text.length;
		 }
	 }

	 return matches;

 },

 /**
	* Prepares a single match with useful meta info:
	*/
 prepMatch: function(match, matchIndex, characterOffset) {

	 if (!match[0]) {
		 throw new Error('findAndReplaceDOMText cannot handle zero-length matches');
	 }

	 match.endIndex = characterOffset + match.index + match[0].length;
	 match.startIndex = characterOffset + match.index;
	 match.index = matchIndex;

	 return match;
 },

 /**
	* Gets aggregate text within subject node
	*/
 getAggregateText: function() {

	 var elementFilter = this.options.filterElements;
	 var forceContext = this.options.forceContext;

	 return getText(this.node);

	 /**
		* Gets aggregate text of a node without resorting
		* to broken innerText/textContent
		*/
	 function getText(node) {

		 if (node.nodeType === Node.TEXT_NODE) {
			 return [node.data];
		 }

		 if (elementFilter && !elementFilter(node)) {
			 return [];
		 }

		 var txt = [''];
		 var i = 0;

		 if (node = node.firstChild) do {

			 if (node.nodeType === Node.TEXT_NODE) {
				 txt[i] += node.data;
				 continue;
			 }

			 var innerText = getText(node);

			 if (
				 forceContext &&
				 node.nodeType === Node.ELEMENT_NODE &&
				 (forceContext === true || forceContext(node))
			 ) {
				 txt[++i] = innerText;
				 txt[++i] = '';
			 } else {
				 if (typeof innerText[0] === 'string') {
					 // Bridge nested text-node data so that they're
					 // not considered their own contexts:
					 // I.e. ['some', ['thing']] -> ['something']
					 txt[i] += innerText.shift();
				 }
				 if (innerText.length) {
					 txt[++i] = innerText;
					 txt[++i] = '';
				 }
			 }
		 } while (node = node.nextSibling);

		 return txt;

	 }

 },

 /**
	* Steps through the target node, looking for matches, and
	* calling replaceFn when a match is found.
	*/
 processMatches: function() {

	 var matches = this.matches;
	 var node = this.node;
	 var elementFilter = this.options.filterElements;

	 var startPortion,
		 endPortion,
		 innerPortions = [],
		 curNode = node,
		 match = matches.shift(),
		 atIndex = 0, // i.e. nodeAtIndex
		 matchIndex = 0,
		 portionIndex = 0,
		 doAvoidNode,
		 nodeStack = [node];

	 out: while (true) {

		 if (curNode.nodeType === Node.TEXT_NODE) {

			 if (!endPortion && curNode.length + atIndex >= match.endIndex) {
				 // We've found the ending
				 // (Note that, in the case of a single portion, it'll be an
				 // endPortion, not a startPortion.)
				 endPortion = {
					 node: curNode,
					 index: portionIndex++,
					 text: curNode.data.substring(match.startIndex - atIndex, match.endIndex - atIndex),

					 // If it's the first match (atIndex==0) we should just return 0
					 indexInMatch: atIndex === 0 ? 0 : atIndex - match.startIndex,

					 indexInNode: match.startIndex - atIndex,
					 endIndexInNode: match.endIndex - atIndex,
					 isEnd: true
				 };

			 } else if (startPortion) {
				 // Intersecting node
				 innerPortions.push({
					 node: curNode,
					 index: portionIndex++,
					 text: curNode.data,
					 indexInMatch: atIndex - match.startIndex,
					 indexInNode: 0 // always zero for inner-portions
				 });
			 }

			 if (!startPortion && curNode.length + atIndex > match.startIndex) {
				 // We've found the match start
				 startPortion = {
					 node: curNode,
					 index: portionIndex++,
					 indexInMatch: 0,
					 indexInNode: match.startIndex - atIndex,
					 endIndexInNode: match.endIndex - atIndex,
					 text: curNode.data.substring(match.startIndex - atIndex, match.endIndex - atIndex)
				 };
			 }

			 atIndex += curNode.data.length;

		 }

		 doAvoidNode = curNode.nodeType === Node.ELEMENT_NODE && elementFilter && !elementFilter(curNode);

		 if (startPortion && endPortion) {

			 curNode = this.replaceMatch(match, startPortion, innerPortions, endPortion);

			 // processMatches has to return the node that replaced the endNode
			 // and then we step back so we can continue from the end of the
			 // match:

			 atIndex -= (endPortion.node.data.length - endPortion.endIndexInNode);

			 startPortion = null;
			 endPortion = null;
			 innerPortions = [];
			 match = matches.shift();
			 portionIndex = 0;
			 matchIndex++;

			 if (!match) {
				 break; // no more matches
			 }

		 } else if (
			 !doAvoidNode &&
			 (curNode.firstChild || curNode.nextSibling)
		 ) {
			 // Move down or forward:
			 if (curNode.firstChild) {
				 nodeStack.push(curNode);
				 curNode = curNode.firstChild;
			 } else {
				 curNode = curNode.nextSibling;
			 }
			 continue;
		 }

		 // Move forward or up:
		 while (true) {
			 if (curNode.nextSibling) {
				 curNode = curNode.nextSibling;
				 break;
			 }
			 curNode = nodeStack.pop();
			 if (curNode === node) {
				 break out;
			 }
		 }

	 }

 },

 /**
	* Reverts ... TODO
	*/
 revert: function() {
	 // Reversion occurs backwards so as to avoid nodes subsequently
	 // replaced during the matching phase (a forward process):
	 for (var l = this.reverts.length; l--;) {
		 this.reverts[l]();
	 }
	 this.reverts = [];
 },

 prepareReplacementString: function(string, portion, match) {
	 var portionMode = this.options.portionMode;
	 if (
		 portionMode === PORTION_MODE_FIRST &&
		 portion.indexInMatch > 0
	 ) {
		 return '';
	 }
	 string = string.replace(/\$(\d+|&|`|')/g, function($0, t) {
		 var replacement;
		 switch(t) {
			 case '&':
				 replacement = match[0];
				 break;
			 case '`':
				 replacement = match.input.substring(0, match.startIndex);
				 break;
			 case '\'':
				 replacement = match.input.substring(match.endIndex);
				 break;
			 default:
				 replacement = match[+t] || '';
		 }
		 return replacement;
	 });

	 if (portionMode === PORTION_MODE_FIRST) {
		 return string;
	 }

	 if (portion.isEnd) {
		 return string.substring(portion.indexInMatch);
	 }

	 return string.substring(portion.indexInMatch, portion.indexInMatch + portion.text.length);
 },

 getPortionReplacementNode: function(portion, match) {

	 var replacement = this.options.replace || '$&';
	 var wrapper = this.options.wrap;
	 var wrapperClass = this.options.wrapClass;

	 if (wrapper && wrapper.nodeType) {
		 // Wrapper has been provided as a stencil-node for us to clone:
		 var clone = doc.createElement('div');
		 clone.innerHTML = wrapper.outerHTML || new XMLSerializer().serializeToString(wrapper);
		 wrapper = clone.firstChild;
	 }

	 if (typeof replacement == 'function') {
		 replacement = replacement(portion, match);
		 if (replacement && replacement.nodeType) {
			 return replacement;
		 }
		 return doc.createTextNode(String(replacement));
	 }

	 var el = typeof wrapper == 'string' ? doc.createElement(wrapper) : wrapper;

		if (el && wrapperClass) {
		 el.className = wrapperClass;
	 }

	 replacement = doc.createTextNode(
		 this.prepareReplacementString(
			 replacement, portion, match
		 )
	 );

	 if (!replacement.data) {
		 return replacement;
	 }

	 if (!el) {
		 return replacement;
	 }

	 el.appendChild(replacement);

	 return el;
 },

 replaceMatch: function(match, startPortion, innerPortions, endPortion) {

	 var matchStartNode = startPortion.node;
	 var matchEndNode = endPortion.node;

	 var precedingTextNode;
	 var followingTextNode;

	 if (matchStartNode === matchEndNode) {

		 var node = matchStartNode;

		 if (startPortion.indexInNode > 0) {
			 // Add `before` text node (before the match)
			 precedingTextNode = doc.createTextNode(node.data.substring(0, startPortion.indexInNode));
			 node.parentNode.insertBefore(precedingTextNode, node);
		 }

		 // Create the replacement node:
		 var newNode = this.getPortionReplacementNode(
			 endPortion,
			 match
		 );

		 node.parentNode.insertBefore(newNode, node);

		 if (endPortion.endIndexInNode < node.length) { // ?????
			 // Add `after` text node (after the match)
			 followingTextNode = doc.createTextNode(node.data.substring(endPortion.endIndexInNode));
			 node.parentNode.insertBefore(followingTextNode, node);
		 }

		 node.parentNode.removeChild(node);

		 this.reverts.push(function() {
			 if (precedingTextNode === newNode.previousSibling) {
				 precedingTextNode.parentNode.removeChild(precedingTextNode);
			 }
			 if (followingTextNode === newNode.nextSibling) {
				 followingTextNode.parentNode.removeChild(followingTextNode);
			 }
			 newNode.parentNode.replaceChild(node, newNode);
		 });

		 return newNode;

	 } else {
		 // Replace matchStartNode -> [innerMatchNodes...] -> matchEndNode (in that order)


		 precedingTextNode = doc.createTextNode(
			 matchStartNode.data.substring(0, startPortion.indexInNode)
		 );

		 followingTextNode = doc.createTextNode(
			 matchEndNode.data.substring(endPortion.endIndexInNode)
		 );

		 var firstNode = this.getPortionReplacementNode(
			 startPortion,
			 match
		 );

		 var innerNodes = [];

		 for (var i = 0, l = innerPortions.length; i < l; ++i) {
			 var portion = innerPortions[i];
			 var innerNode = this.getPortionReplacementNode(
				 portion,
				 match
			 );
			 portion.node.parentNode.replaceChild(innerNode, portion.node);
			 this.reverts.push((function(portion, innerNode) {
				 return function() {
					 innerNode.parentNode.replaceChild(portion.node, innerNode);
				 };
			 }(portion, innerNode)));
			 innerNodes.push(innerNode);
		 }

		 var lastNode = this.getPortionReplacementNode(
			 endPortion,
			 match
		 );

		 matchStartNode.parentNode.insertBefore(precedingTextNode, matchStartNode);
		 matchStartNode.parentNode.insertBefore(firstNode, matchStartNode);
		 matchStartNode.parentNode.removeChild(matchStartNode);

		 matchEndNode.parentNode.insertBefore(lastNode, matchEndNode);
		 matchEndNode.parentNode.insertBefore(followingTextNode, matchEndNode);
		 matchEndNode.parentNode.removeChild(matchEndNode);

		 this.reverts.push(function() {
			 precedingTextNode.parentNode.removeChild(precedingTextNode);
			 firstNode.parentNode.replaceChild(matchStartNode, firstNode);
			 followingTextNode.parentNode.removeChild(followingTextNode);
			 lastNode.parentNode.replaceChild(matchEndNode, lastNode);
		 });

		 return lastNode;
	 }
 }

};

return exposed;

}));

/***/ })
/******/ ]);
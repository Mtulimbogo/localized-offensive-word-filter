/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 8);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.dynamicList = dynamicList;
exports.escapeHTML = escapeHTML;
exports.exportToFile = exportToFile;
exports.getVersion = getVersion;
exports.isVersionOlder = isVersionOlder;
exports.readFile = readFile;
exports.removeFromArray = removeFromArray;

/* istanbul ignore next */
function dynamicList(list, selectEm, title) {
  let options = '';

  if (title !== undefined) {
    options = '<option value="" disabled selected>' + title + '</option>';
  }

  for (let i = 0; i < list.length; i++) {
    options += '<option value="' + list[i] + '">' + list[i] + '</option>';
  }

  document.getElementById(selectEm).innerHTML = options;
}

function escapeHTML(str) {
  return str.replace(/([<>&"'])/g, (match, p1) => ({
    '<': '&lt;',
    '>': '&gt;',
    '&': '&amp;',
    '"': '&quot;',
    "'": '&apos;'
  })[p1]);
}

function exportToFile(dataStr, fileName = 'data.txt') {
  let dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
  let linkElement = document.createElement('a');
  linkElement.setAttribute('href', dataUri);
  linkElement.setAttribute('download', fileName);
  linkElement.click();
  linkElement.remove();
} // /^\d+\.\d+\.\d+$/


function getVersion(version) {
  let versionValues = version.split('.');
  return {
    major: parseInt(versionValues[0]),
    minor: parseInt(versionValues[1]),
    patch: parseInt(versionValues[2])
  };
} // Is the provided version lower than the minimum version?


function isVersionOlder(version, minimum) {
  if (version.major < minimum.major) {
    return true;
  } else if (version.major == minimum.major && version.minor < minimum.minor) {
    return true;
  } else if (version.major == minimum.major && version.minor == minimum.minor && version.patch < minimum.patch) {
    return true;
  }

  return false;
}

function readFile(file) {
  return new Promise((resolve, reject) => {
    let fr = new FileReader();

    fr.onload = () => {
      resolve(fr.result);
    };

    fr.readAsText(file);
  });
}

function removeFromArray(array, element) {
  return array.filter(e => e !== element);
}

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _config = _interopRequireDefault(__webpack_require__(2));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class WebConfig extends _config.default {
  static async build(keys) {
    let asyncResult = await WebConfig.getConfig(keys);
    let instance = new WebConfig(asyncResult);
    return instance;
  } // Call build() to create a new instance


  constructor(asyncParam) {
    super(asyncParam);
  } // Compile words


  static combineWords(items) {
    items.words = {};

    if (items._words0 !== undefined) {
      // Find all _words* to combine
      let wordKeys = Object.keys(items).filter(function (key) {
        return _config.default._wordsPattern.test(key);
      }); // Add all _words* to words and remove _words*

      wordKeys.forEach(function (key) {
        Object.assign(items.words, items[key]);
        delete items[key];
      });
    } // console.log('combineWords', items); // DEBUG

  } // Persist all configs from defaults and split _words*


  dataToPersist() {
    let self = this;
    let data = {}; // Save all settings using keys from _defaults

    Object.keys(_config.default._defaults).forEach(function (key) {
      if (self[key] !== undefined) {
        data[key] = self[key];
      }
    });

    if (self.words) {
      // Split words back into _words* for storage
      let splitWords = self.splitWords();
      Object.keys(splitWords).forEach(function (key) {
        data[key] = splitWords[key];
      });
      let wordKeys = Object.keys(self).filter(function (key) {
        return _config.default._wordsPattern.test(key);
      });
      wordKeys.forEach(function (key) {
        data[key] = self[key];
      });
    } // console.log('dataToPersist', data); // DEBUG - Config


    return data;
  } // Async call to get provided keys (or default keys) from chrome storage
  // TODO: Keys: Doesn't support getting words


  static getConfig(keys) {
    return new Promise(function (resolve, reject) {
      // Generate a request to use with chrome.storage
      let request = null;

      if (keys !== undefined) {
        request = {};

        for (let k of keys) {
          request[k] = _config.default._defaults[k];
        }
      }

      chrome.storage.sync.get(request, function (items) {
        // Ensure defaults for undefined settings
        Object.keys(_config.default._defaults).forEach(function (defaultKey) {
          if (request == null || Object.keys(request).includes(defaultKey)) {
            if (items[defaultKey] === undefined) {
              items[defaultKey] = _config.default._defaults[defaultKey];
            }
          }
        }); // Add words if requested, and provide _defaultWords if needed

        if (keys === undefined || keys.includes('words')) {
          // Use default words if none were provided
          if (items._words0 === undefined || Object.keys(items._words0).length == 0) {
            items._words0 = _config.default._defaultWords;
          }

          WebConfig.combineWords(items);
        }

        resolve(items);
      });
    });
  }

  removeProp(prop) {
    chrome.storage.sync.remove(prop);
    delete this[prop];
  }

  reset() {
    return new Promise(function (resolve, reject) {
      chrome.storage.sync.clear(function () {
        resolve(chrome.runtime.lastError ? 1 : 0);
      });
    });
  } // Pass a key to save only that key, otherwise it will save everything


  save(prop) {
    let data = {};
    prop ? data[prop] = this[prop] : data = this.dataToPersist();
    return new Promise(function (resolve, reject) {
      chrome.storage.sync.set(data, function () {
        resolve(chrome.runtime.lastError ? 1 : 0);
      });
    });
  }

  splitWords() {
    let self = this;
    let currentContainerNum = 0;
    let currentWordNum = 0; // let wordsLength = JSON.stringify(self.words).length;
    // let wordContainers = Math.ceil(wordsLength/Config._maxBytes);
    // let wordsNum = Object.keys(self.words).length;

    let words = {};
    words[`_words${currentContainerNum}`] = {};
    Object.keys(self.words).sort().forEach(function (word) {
      if (currentWordNum == _config.default._maxWords) {
        currentContainerNum++;
        currentWordNum = 0;
        words[`_words${currentContainerNum}`] = {};
      }

      words[`_words${currentContainerNum}`][word] = self.words[word];
      currentWordNum++;
    });
    return words;
  }

}

exports.default = WebConfig;

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class Config {
  constructor(config) {
    _defineProperty(this, "advancedDomains", void 0);

    _defineProperty(this, "censorCharacter", void 0);

    _defineProperty(this, "censorFixedLength", void 0);

    _defineProperty(this, "customAudioSites", void 0);

    _defineProperty(this, "defaultSubstitution", void 0);

    _defineProperty(this, "defaultWordMatchMethod", void 0);

    _defineProperty(this, "defaultWordRepeat", void 0);

    _defineProperty(this, "disabledDomains", void 0);

    _defineProperty(this, "filterMethod", void 0);

    _defineProperty(this, "filterWordList", void 0);

    _defineProperty(this, "globalMatchMethod", void 0);

    _defineProperty(this, "muteAudio", void 0);

    _defineProperty(this, "muteAudioOnly", void 0);

    _defineProperty(this, "muteMethod", void 0);

    _defineProperty(this, "password", void 0);

    _defineProperty(this, "preserveCase", void 0);

    _defineProperty(this, "preserveFirst", void 0);

    _defineProperty(this, "preserveLast", void 0);

    _defineProperty(this, "showCounter", void 0);

    _defineProperty(this, "showSubtitles", void 0);

    _defineProperty(this, "showSummary", void 0);

    _defineProperty(this, "showUpdateNotification", void 0);

    _defineProperty(this, "substitutionMark", void 0);

    _defineProperty(this, "words", void 0);

    _defineProperty(this, "youTubeAutoSubsMin", void 0);

    if (typeof config === 'undefined') {
      throw new Error('Cannot be called directly. call build()');
    }

    for (let k in config) this[k] = config[k];
  }

  addWord(str, options) {
    str = str.trim().toLowerCase();

    if (Object.keys(this.words).includes(str)) {
      return false; // Already exists
    } else if (options) {
      options.sub = options.sub.trim().toLowerCase();
      this.words[str] = options;
      return true;
    } else {
      this.words[str] = {
        matchMethod: this.defaultWordMatchMethod,
        repeat: this.defaultWordRepeat,
        sub: ''
      };
      return true;
    }
  }

  repeatForWord(word) {
    if (this.words[word].repeat === true || this.words[word].repeat === false) {
      return this.words[word].repeat;
    } else {
      return this.defaultWordRepeat;
    }
  }

  sanitizeWords() {
    let sanitizedWords = {};
    Object.keys(this.words).sort().forEach(key => {
      sanitizedWords[key.trim().toLowerCase()] = this.words[key];
    });
    this.words = sanitizedWords;
  }

}

exports.default = Config;

_defineProperty(Config, "filterMethods", {
  censor: 0,
  substitute: 1,
  remove: 2
});

_defineProperty(Config, "matchMethods", {
  exact: 0,
  partial: 1,
  whole: 2,
  'Per-Word': 3,
  'RegExp': 4
});

_defineProperty(Config, "_defaults", {
  advancedDomains: [],
  censorCharacter: '',
  censorFixedLength: 0,
  customAudioSites: null,
  defaultSubstitution: '',
  defaultWordMatchMethod: 0,
  defaultWordRepeat: false,
  disabledDomains: [],
  filterMethod: 0,
  // ['Censor', 'Substitute', 'Remove'];
  filterWordList: true,
  globalMatchMethod: 3,
  // ['Exact', 'Partial', 'Whole', 'Per-Word', 'RegExp']
  muteAudio: false,
  // Filter audio
  muteAudioOnly: false,
  muteMethod: 0,
  // 0: Mute Tab, 1: Video Volume
  password: null,
  preserveCase: true,
  preserveFirst: true,
  preserveLast: false,
  showCounter: true,
  showSubtitles: 0,
  showSummary: true,
  showUpdateNotification: true,
  substitutionMark: false,
  youTubeAutoSubsMin: 0
});

_defineProperty(Config, "_maneno", {
  'ass': {
    matchMethod: 0,
    repeat: true,
    sub: 'butt'
  },
  'asses': {
    matchMethod: 0,
    repeat: false,
    sub: 'butts'
  },
  'asshole': {
    matchMethod: 1,
    repeat: true,
    sub: 'jerk'
  },
  'badass': {
    matchMethod: 1,
    repeat: true,
    sub: 'cool'
  },
  'bastard': {
    matchMethod: 1,
    repeat: true,
    sub: 'idiot'
  },
  'bitch': {
    matchMethod: 1,
    repeat: true,
    sub: 'bench'
  },
  'cocksucker': {
    matchMethod: 1,
    repeat: true,
    sub: 'suckup'
  },
  'cunt': {
    matchMethod: 1,
    repeat: true,
    sub: 'expletive'
  },
  'dammit': {
    matchMethod: 1,
    repeat: false,
    sub: 'dangit'
  },
  'damn': {
    matchMethod: 1,
    repeat: false,
    sub: 'dang'
  },
  'dumbass': {
    matchMethod: 1,
    repeat: true,
    sub: 'idiot'
  },
  'fag': {
    matchMethod: 0,
    repeat: true,
    sub: 'gay'
  },
  'faggot': {
    matchMethod: 1,
    repeat: true,
    sub: 'gay'
  },
  'fags': {
    matchMethod: 0,
    repeat: true,
    sub: 'gays'
  },
  'fuck': {
    matchMethod: 1,
    repeat: true,
    sub: 'freak'
  },
  'goddammit': {
    matchMethod: 1,
    repeat: true,
    sub: 'dangit'
  },
  'hell': {
    matchMethod: 0,
    repeat: true,
    sub: 'heck'
  },
  'jackass': {
    matchMethod: 1,
    repeat: true,
    sub: 'jerk'
  },
  'nigga': {
    matchMethod: 0,
    repeat: true,
    sub: 'bruh'
  },
  'nigger': {
    matchMethod: 0,
    repeat: true,
    sub: 'man'
  },
  'niggers': {
    matchMethod: 0,
    repeat: true,
    sub: 'people'
  },
  'piss': {
    matchMethod: 1,
    repeat: true,
    sub: 'pee'
  },
  'pissed': {
    matchMethod: 1,
    repeat: true,
    sub: 'ticked'
  },
  'pussies': {
    matchMethod: 0,
    repeat: true,
    sub: 'softies'
  },
  'pussy': {
    matchMethod: 0,
    repeat: true,
    sub: 'softie'
  },
  'shit': {
    matchMethod: 1,
    repeat: true,
    sub: 'crap'
  },
  'slut': {
    matchMethod: 1,
    repeat: true,
    sub: 'tramp'
  },
  'tits': {
    matchMethod: 1,
    repeat: true,
    sub: 'chest'
  },
  'twat': {
    matchMethod: 1,
    repeat: true,
    sub: 'dumbo'
  },
  'whore': {
    matchMethod: 1,
    repeat: true,
    sub: 'tramp'
  },
  'bolo': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'bwege': {
    matchMethod: 1,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'fala': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'fara': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'fira': {
    matchMethod: 1,
    repeat: true,
    sub: 'kinyume na maumbile'
  },
  'firwa': {
    matchMethod: 1,
    repeat: true,
    sub: 'kinyume na maumbile'
  },
  'kuma': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kike'
  },
  'kumalake': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'kumalamsenge': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'kumamae': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'kundu': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'Kusagana': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'Kutomba': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'Kutombana': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'Kahaba': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'malaya': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'matako': {
    matchMethod: 1,
    repeat: true,
    sub: 'makalio'
  },
  'mavuzi': {
    matchMethod: 1,
    repeat: true,
    sub: 'nywele za sehemu ya siri'
  },
  'mbolo': {
    matchMethod: 1,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'mboo': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'mfiraji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mfirwaji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mjanechuo': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mkundu': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'mngese': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'msagaji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'msenge': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mxenge': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'msengenyaji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'mshenzi': {
    matchMethod: 1,
    repeat: true,
    sub: ''
  },
  'nyoko': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'nyoo': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'pumbu': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'senge': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'shahawa': {
    matchMethod: 1,
    repeat: true,
    sub: 'manii'
  },
  'shenzi': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'tako': {
    matchMethod: 0,
    repeat: true,
    sub: 'kalio'
  },
  'tiana': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'tiwa': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'tomb': {
    matchMethod: 1,
    repeat: true,
    sub: 'tendo la ndoa'
  },
  'tomba': {
    matchMethod: 1,
    repeat: true,
    sub: 'tendo la ndoa'
  },
  'tombana': {
    matchMethod: 1,
    repeat: true,
    sub: 'tendo la ndoa'
  },
  'tombwa': {
    matchMethod: 1,
    repeat: true,
    sub: 'tendo la ndoa'
  },
  'uboo': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'ubolo': {
    matchMethod: 0,
    repeat: true,
    sub: 'maumbile ya kiume'
  },
  'kisimi': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'kicmi': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'kixmi': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'usenge': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'ufiraji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'ufirwaji': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  },
  'tahira': {
    matchMethod: 0,
    repeat: true,
    sub: ''
  }
});

_defineProperty(Config, "_defaultWords", Config._maneno);

_defineProperty(Config, "_filterMethodNames", ['Censor', 'Substitute', 'Remove']);

_defineProperty(Config, "_matchMethodNames", ['Exact', 'Partial', 'Whole', 'Per-Word', 'Regular-Expression']);

_defineProperty(Config, "_maxBytes", 6500);

_defineProperty(Config, "_maxWords", 100);

_defineProperty(Config, "_wordsPattern", /^_words\d+/);

/***/ }),
/* 3 */,
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _helper = __webpack_require__(0);

var _webConfig = _interopRequireDefault(__webpack_require__(1));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class DataMigration {
  // Migration required by any version less than this
  constructor(config) {
    _defineProperty(this, "cfg", void 0);

    this.cfg = config;
  }

  static async build() {
    let cfg = await _webConfig.default.build();
    return new DataMigration(cfg);
  }

  static migrationNeeded(oldVersion) {
    return (0, _helper.isVersionOlder)((0, _helper.getVersion)(oldVersion), (0, _helper.getVersion)(DataMigration.newestMigration));
  } // This will look at the version (from before the update) and perform data migrations if necessary
  // Only append so the order stays the same (oldest first).


  byVersion(oldVersion) {
    let version = (0, _helper.getVersion)(oldVersion);
    let migrated = false;

    if ((0, _helper.isVersionOlder)(version, (0, _helper.getVersion)('1.0.13'))) {
      migrated = true;
      this.moveToNewWordsStorage();
    }

    if ((0, _helper.isVersionOlder)(version, (0, _helper.getVersion)('1.1.0'))) {
      migrated = true;
      this.sanitizeWords();
    }

    if ((0, _helper.isVersionOlder)(version, (0, _helper.getVersion)('1.2.0'))) {
      migrated = true;
      this.singleWordSubstitution();
    }

    if ((0, _helper.isVersionOlder)(version, (0, _helper.getVersion)('2.1.4'))) {
      migrated = true;
      this.updateDefaultSubs();
    }

    return migrated;
  } // [2.1.4] - Update default sub values


  updateDefaultSubs() {
    let cfg = this.cfg;
    let updatedWords = {
      bastard: {
        original: 'jerk',
        update: 'idiot'
      },
      bitch: {
        original: 'jerk',
        update: 'bench'
      },
      cocksucker: {
        original: 'idiot',
        update: 'suckup'
      },
      cunt: {
        original: 'explative',
        update: 'expletive'
      },
      fag: {
        original: 'slur',
        update: 'gay'
      },
      faggot: {
        original: 'slur',
        update: 'gay'
      },
      fags: {
        original: 'slur',
        update: 'gays'
      },
      fala: {
        original: 'fudge',
        update: 'freak'
      },
      goddammit: {
        original: 'goshdangit',
        update: 'dangit'
      },
      jackass: {
        original: 'idiot',
        update: 'jerk'
      },
      nigga: {
        original: 'ethnic slur',
        update: 'bruh'
      },
      nigger: {
        original: 'ethnic slur',
        update: 'man'
      },
      niggers: {
        original: 'ethnic slurs',
        update: 'people'
      },
      tits: {
        original: 'explative',
        update: 'chest'
      },
      twat: {
        original: 'explative',
        update: 'dumbo'
      }
    };
    Object.keys(updatedWords).forEach(updatedWord => {
      if (cfg.words[updatedWord]) {
        let wordObj = cfg.words[updatedWord];

        if (wordObj.sub == updatedWords[updatedWord].original) {
          wordObj.sub = updatedWords[updatedWord].update;
        }
      }
    });
  } // [1.0.13] - updateRemoveWordsFromStorage - transition from previous words structure under the hood


  moveToNewWordsStorage() {
    chrome.storage.sync.get({
      'words': null
    }, function (oldWords) {
      if (oldWords.words) {
        chrome.storage.sync.set({
          '_words0': oldWords.words
        }, function () {
          if (!chrome.runtime.lastError) {
            chrome.storage.sync.remove('words', function () {// Removed old words
            });
          }
        });
      }
    });
  }

  runImportMigrations() {
    this.sanitizeWords(); // 1.1.0

    this.singleWordSubstitution(); // 1.2.0

    this.updateDefaultSubs(); // 2.1.4
  } // [1.1.0] - Downcase and trim each word in the list (NOTE: This MAY result in losing some words)


  sanitizeWords() {
    this.cfg.sanitizeWords();
  } // [1.2.0] - Change from a word having many substitutions to a single substitution ({words: []} to {sub: ''})


  singleWordSubstitution() {
    let cfg = this.cfg; // console.log('before', JSON.stringify(cfg.words));

    Object.keys(cfg.words).forEach(word => {
      let wordObj = cfg.words[word];

      if (wordObj.hasOwnProperty('words')) {
        // @ts-ignore: Old 'words' doesn't exist on Interface.
        wordObj.sub = wordObj.words[0] || ''; // @ts-ignore: Old 'words' doesn't exist on Interface.

        delete wordObj.words;
      }
    }); // console.log('after', JSON.stringify(cfg.words));
  }

}

exports.default = DataMigration;

_defineProperty(DataMigration, "newestMigration", '2.1.4');

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Filter = void 0;

var _word = _interopRequireDefault(__webpack_require__(6));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class Filter {
  constructor() {
    _defineProperty(this, "cfg", void 0);

    _defineProperty(this, "counter", void 0);

    _defineProperty(this, "wordList", void 0);

    _defineProperty(this, "wordRegExps", void 0);

    this.counter = 0;
    this.wordList = [];
    this.wordRegExps = [];
  }

  foundMatch(word) {
    this.counter++;
  } // Parse the profanity list
  // ["exact", "partial", "whole", "disabled"]


  generateRegexpList() {
    let self = this;
    self.wordRegExps = []; // console.time('generateRegexpList'); // Benchmark - Call Time
    // console.count('generateRegexpList: words to filter'); // Benchmarking - Executaion Count

    if (self.cfg.filterMethod == 2) {
      // Special regexp for "Remove" filter, uses per-word matchMethods
      self.wordList.forEach(word => {
        let repeat = self.cfg.repeatForWord(word);

        if (self.cfg.words[word].matchMethod == 0) {
          // If word matchMethod is exact
          self.wordRegExps.push(_word.default.buildRegexpForRemoveExact(word, repeat));
        } else if (self.cfg.words[word].matchMethod == 4) {
          // If word matchMethod is RegExp
          self.wordRegExps.push(new RegExp(word, 'gi'));
        } else {
          self.wordRegExps.push(_word.default.buildRegexpForRemovePart(word, repeat));
        }
      });
    } else {
      switch (self.cfg.globalMatchMethod) {
        case 0:
          // Global: Exact match
          self.wordList.forEach(word => {
            let repeat = self.cfg.repeatForWord(word);
            self.wordRegExps.push(_word.default.buildExactRegexp(word, repeat));
          });
          break;

        case 2:
          // Global: Whole word match
          self.wordList.forEach(word => {
            let repeat = self.cfg.repeatForWord(word);
            self.wordRegExps.push(_word.default.buildWholeRegexp(word, repeat));
          });
          break;

        case 3:
          // Per-word matching
          self.wordList.forEach(word => {
            let repeat = self.cfg.repeatForWord(word);

            switch (self.cfg.words[word].matchMethod) {
              case 0:
                self.wordRegExps.push(_word.default.buildExactRegexp(word, repeat));
                break;
              // Exact match

              case 2:
                self.wordRegExps.push(_word.default.buildWholeRegexp(word, repeat));
                break;
              // Whole word match

              case 4:
                self.wordRegExps.push(new RegExp(word, 'gi'));
                break;
              // Regular Expression (Advanced)

              default:
                self.wordRegExps.push(_word.default.buildPartRegexp(word, repeat));
                break;
              // case 1 - Partial word match (Default)
            }
          });
          break;

        default:
          // case 1 - Global: Partial word match (Default)
          self.wordList.forEach(word => {
            let repeat = self.cfg.repeatForWord(word);
            self.wordRegExps.push(_word.default.buildPartRegexp(word, repeat));
          });
          break;
      }
    } // console.timeEnd('generateRegexpList'); // Benchmark - Call Time

  } // Sort the words array by longest (most-specific) first
  // Config Dependencies: words


  generateWordList() {
    this.wordList = null;
    this.wordList = Object.keys(this.cfg.words).sort((a, b) => {
      return b.length - a.length;
    });
  } // Config Dependencies: filterMethod, wordList,
  // censorFixedLength, preserveFirst, preserveLast, censorCharacter
  // words, defaultSubstitution, preserveCase


  replaceText(str, stats = true) {
    // console.count('replaceText'); // Benchmarking - Executaion Count
    let self = this;

    switch (self.cfg.filterMethod) {
      case 0:
        // Censor
        self.wordRegExps.forEach((regExp, index) => {
          str = str.replace(regExp, function (match, arg1, arg2, arg3, arg4, arg5) {
            if (stats) {
              self.foundMatch(self.wordList[index]);
            }

            if (regExp.unicode) {
              match = arg2;
            } // Workaround for unicode word boundaries


            let censoredString = '';
            let censorLength = self.cfg.censorFixedLength > 0 ? self.cfg.censorFixedLength : match.length;

            if (self.cfg.preserveFirst && self.cfg.preserveLast) {
              censoredString = match[0] + self.cfg.censorCharacter.repeat(censorLength - 2) + match.slice(-1);
            } else if (self.cfg.preserveFirst) {
              censoredString = match[0] + self.cfg.censorCharacter.repeat(censorLength - 1);
            } else if (self.cfg.preserveLast) {
              censoredString = self.cfg.censorCharacter.repeat(censorLength - 1) + match.slice(-1);
            } else {
              censoredString = self.cfg.censorCharacter.repeat(censorLength);
            }

            if (regExp.unicode) {
              censoredString = arg1 + censoredString + arg3;
            } // Workaround for unicode word boundaries
            // console.log('Censor match:', match, censoredString); // DEBUG


            return censoredString;
          });
        });
        break;

      case 1:
        // Substitute
        self.wordRegExps.forEach((regExp, index) => {
          str = str.replace(regExp, function (match, arg1, arg2, arg3, arg4, arg5) {
            if (stats) {
              self.foundMatch(self.wordList[index]);
            }

            if (regExp.unicode) {
              match = arg2;
            } // Workaround for unicode word boundaries


            let sub = self.cfg.words[self.wordList[index]].sub || self.cfg.defaultSubstitution; // Make substitution match case of original match

            if (self.cfg.preserveCase) {
              if (_word.default.allUpperCase(match)) {
                sub = sub.toUpperCase();
              } else if (_word.default.capitalized(match)) {
                sub = _word.default.capitalize(sub);
              }
            }

            if (self.cfg.substitutionMark) {
              sub = '[' + sub + ']';
            }

            if (regExp.unicode) {
              sub = arg1 + sub + arg3;
            } // Workaround for unicode word boundaries
            // console.log('Substitute match:', match, sub); // DEBUG


            return sub;
          });
        });
        break;

      case 2:
        // Remove
        self.wordRegExps.forEach((regExp, index) => {
          str = str.replace(regExp, function (match, arg1, arg2, arg3, arg4, arg5) {
            // console.log('\nmatch: ', match, '\narg1: ', arg1, '\narg2: ', arg2, '\narg3: ', arg3, '\narg4: ', arg4, '\narg5: ', arg5); // DEBUG
            if (stats) {
              self.foundMatch(self.wordList[index]);
            }

            if (regExp.unicode) {
              // Workaround for unicode word boundaries
              if (_word.default.whitespaceRegExp.test(arg1) && _word.default.whitespaceRegExp.test(arg3)) {
                // If both surrounds are whitespace (only need 1)
                return arg1;
              } else if (_word.default.nonWordRegExp.test(arg1) || _word.default.nonWordRegExp.test(arg3)) {
                // If there is more than just whitesapce (ex. ',')
                return (arg1 + arg3).trim();
              } else {
                return '';
              }
            } else {
              // Don't remove both leading and trailing whitespace
              if (_word.default.whitespaceRegExp.test(match[0]) && _word.default.whitespaceRegExp.test(match[match.length - 1])) {
                return match[0];
              } else {
                // console.log('Remove match:', match); // DEBUG
                return '';
              }
            }
          });
        });
        break;
    }

    return str;
  }

  init() {
    this.generateWordList();
    this.generateRegexpList();
  }

}

exports.Filter = Filter;

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class Word {
  static allLowerCase(string) {
    return string.toLowerCase() === string;
  }

  static allUpperCase(string) {
    return string.toUpperCase() === string;
  } // Word must match exactly (not sub-string)
  // /\bword\b/gi


  static buildExactRegexp(str, matchRepeated = false) {
    try {
      if (Word.containsDoubleByte(str)) {
        // Work around for lack of word boundary support for unicode characters
        // /(^|[\s.,'"+!?|-]+)(word)([\s.,'"+!?|-]+|$)/giu
        return new RegExp('(^|' + Word._unicodeWordBoundary + '+)(' + Word.processPhrase(str, matchRepeated) + ')(' + Word._unicodeWordBoundary + '+|$)', 'giu');
      } else if (str.match(Word._edgePunctuationRegExp)) {
        // Begin or end with punctuation (not \w))
        return new RegExp('(^|\\s)(' + Word.processPhrase(str, matchRepeated) + ')(\\s|$)', 'giu');
      } else {
        return new RegExp('\\b' + Word.processPhrase(str, matchRepeated) + '\\b', 'gi');
      }
    } catch (e) {
      throw new Error('Failed to create RegExp for "' + str + '" - ' + e.name + ' ' + e.message);
    }
  } // Match any part of a word (sub-string)
  // /word/gi


  static buildPartRegexp(str, matchRepeated = false) {
    try {
      return new RegExp(Word.processPhrase(str, matchRepeated), 'gi');
    } catch (e) {
      throw new Error('Failed to create RegExp for "' + str + '" - ' + e.name + ' ' + e.message);
    }
  } // Match entire word that contains sub-string and surrounding whitespace
  // /\s?\bword\b\s?/gi


  static buildRegexpForRemoveExact(str, matchRepeated = false) {
    try {
      if (Word.containsDoubleByte(str)) {
        // Work around for lack of word boundary support for unicode characters
        // /(^|[\s.,'"+!?|-]+)(word)([\s.,'"+!?|-]+|$)/giu
        return new RegExp('(^|' + Word._unicodeWordBoundary + ')(' + Word.processPhrase(str, matchRepeated) + ')(' + Word._unicodeWordBoundary + '|$)', 'giu');
      } else if (str.match(Word._edgePunctuationRegExp)) {
        // Begin or end with punctuation (not \w))
        return new RegExp('(^|\\s)(' + Word.processPhrase(str, matchRepeated) + ')(\\s|$)', 'giu');
      } else {
        return new RegExp('\\s?\\b' + Word.processPhrase(str, matchRepeated) + '\\b\\s?', 'gi');
      }
    } catch (e) {
      throw new Error('Failed to create RegExp for "' + str + '" - ' + e.name + ' ' + e.message);
    }
  } // Match entire word that contains sub-string and surrounding whitespace
  // /\s?\b[\w-]*word[\w-]*\b\s?/gi


  static buildRegexpForRemovePart(str, matchRepeated = false) {
    try {
      if (Word.containsDoubleByte(str)) {
        // Work around for lack of word boundary support for unicode characters
        // /(^|[\s.,'"+!?|-]?)[\w-]*(word)[\w-]*([\s.,'"+!?|-]?|$)/giu
        return new RegExp('(^|' + Word._unicodeWordBoundary + '?)([\\w-]*' + Word.processPhrase(str, matchRepeated) + '[\\w-]*)(' + Word._unicodeWordBoundary + '?|$)', 'giu');
      } else if (str.match(Word._edgePunctuationRegExp)) {
        // Begin or end with punctuation (not \w))
        return new RegExp('(^|\\s)([\\w-]*' + Word.processPhrase(str, matchRepeated) + '[\\w-]*)(\\s|$)', 'giu');
      } else {
        return new RegExp('\\s?\\b[\\w-]*' + Word.processPhrase(str, matchRepeated) + '[\\w-]*\\b\\s?', 'gi');
      }
    } catch (e) {
      throw new Error('Failed to create RegExp for "' + str + '" - ' + e.name + ' ' + e.message);
    }
  } // Match entire word that contains sub-string
  // /\b[\w-]*word[\w-]*\b/gi


  static buildWholeRegexp(str, matchRepeated = false) {
    try {
      if (Word.containsDoubleByte(str)) {
        // Work around for lack of word boundary support for unicode characters
        // (^|[\s.,'"+!?|-]*)([\S]*куче[\S]*)([\s.,'"+!?|-]*|$)/giu
        return new RegExp('(^|' + Word._unicodeWordBoundary + '*)([\\S]*' + Word.processPhrase(str, matchRepeated) + '[\\S]*)(' + Word._unicodeWordBoundary + '*|$)', 'giu');
      } else if (str.match(Word._edgePunctuationRegExp)) {
        // Begin or end with punctuation (not \w))
        return new RegExp('(^|\\s)([\\S]*' + Word.processPhrase(str, matchRepeated) + '[\\S]*)(\\s|$)', 'giu');
      } else {
        return new RegExp('\\b[\\w-]*' + Word.processPhrase(str, matchRepeated) + '[\\w-]*\\b', 'gi');
      }
    } catch (e) {
      throw new Error('Failed to create RegExp for "' + str + '" - ' + e.name + ' ' + e.message);
    }
  }

  static capitalize(string) {
    return string.charAt(0).toUpperCase() + string.substr(1);
  }

  static capitalized(string) {
    return string.charAt(0).toUpperCase() === string.charAt(0);
  }

  static containsDoubleByte(str) {
    if (!str.length) return false;
    if (str.charCodeAt(0) > 127) return true;
    return Word._unicodeRegExp.test(str);
  } // /[-\/\\^$*+?.()|[\]{}]/g
  // /[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g
  // Removing '-' for '/пресс-релиз/, giu'


  static escapeRegExp(str) {
    return str.replace(Word._escapeRegExp, '\\$&');
  } // Process the rest of the word (word excluding first character)
  // This will escape the word and optionally include repeating characters


  static processPhrase(str, matchRepeated) {
    var escaped = Word.escapeRegExp(str);

    if (matchRepeated) {
      return Word.repeatingCharacterRegexp(escaped);
    }

    return escaped;
  } // Regexp to match repeating characters
  // Word: /w+o+r+d+/gi


  static repeatingCharacterRegexp(str) {
    if (str.includes('\\')) {
      var repeat = '';

      for (var i = 0; i < str.length; i++) {
        if (str[i] === '\\') {
          repeat += str[i] + str[i + 1] + '+';
          i++;
        } else {
          repeat += str[i] + '+';
        }
      }

      return repeat;
    } else {
      return str.split('').map(letter => letter + '+').join('');
    }
  }

}

exports.default = Word;

_defineProperty(Word, "_edgePunctuationRegExp", /(^[,.'"!?%$]|[,.'"!?%$]$)/);

_defineProperty(Word, "_escapeRegExp", /[\/\\^$*+?.()|[\]{}]/g);

_defineProperty(Word, "_unicodeRegExp", /[^\u0000-\u00ff]/);

_defineProperty(Word, "_unicodeWordBoundary", '[\\s.,\'"+!?|-]');

_defineProperty(Word, "nonWordRegExp", new RegExp('^\\s*[^\\w]+\\s*$', 'g'));

_defineProperty(Word, "whitespaceRegExp", /^\s+$/);

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class WebAudio {
  constructor(filter) {
    _defineProperty(this, "filter", void 0);

    _defineProperty(this, "lastFilteredNode", void 0);

    _defineProperty(this, "muted", void 0);

    _defineProperty(this, "muteMethod", void 0);

    _defineProperty(this, "showSubtitles", void 0);

    _defineProperty(this, "site", void 0);

    _defineProperty(this, "sites", void 0);

    _defineProperty(this, "subtitleSelector", void 0);

    _defineProperty(this, "supportedNode", void 0);

    _defineProperty(this, "supportedPage", void 0);

    _defineProperty(this, "unmuteDelay", void 0);

    _defineProperty(this, "volume", void 0);

    _defineProperty(this, "youTube", void 0);

    _defineProperty(this, "youTubeAutoSubsMin", void 0);

    this.filter = filter;
    this.lastFilteredNode = null;
    this.muted = false;
    this.muteMethod = filter.cfg.muteMethod;
    this.showSubtitles = filter.cfg.showSubtitles;
    this.sites = Object.assign(WebAudio.sites, filter.cfg.customAudioSites);
    Object.keys(filter.cfg.customAudioSites).forEach(x => {
      this.sites[x]._custom = true;
    });
    this.unmuteDelay = 0;
    this.volume = 1;
    this.youTubeAutoSubsMin = filter.cfg.youTubeAutoSubsMin; // Additional setup

    this.site = this.sites[filter.hostname];
    this.supportedPage = this.site != null;

    if (this.site) {
      if (filter.hostname == 'www.youtube.com') {
        this.youTube = true;
      }

      if (this.site.videoCueMode) {
        this.site = Object.assign(WebAudio._videoModeDefaults, this.site);
        setInterval(this.watchForVideo, this.site.videoInterval, this);
      }

      this.subtitleSelector = this.site.subtitleSelector;
      this.supportedNode = this.buildSupportedNodeFunction();
    }
  }

  buildSupportedNodeFunction() {
    let site = this.site; // Plain text mode

    if (site.textParentSelector) {
      return new Function('node', `
      if (node.nodeName === '#text') {
        let textParent = document.querySelector('${site.textParentSelector}');
        if (textParent && textParent.contains(node)) { return true; }
      }
      return false;`);
    } // Video cue mode


    if (site.videoCueMode) {
      return new Function('node', 'return false;');
    } // Element mode (Default)


    if (!site.tagName) {
      throw 'tagName is required.';
    }

    return new Function('node', `
    if (node.nodeName == '${site.tagName.toUpperCase()}') {
      ${site.className ? `if (!node.className || !node.className.includes('${site.className}')) { return false; }` : ''}
      ${site.dataPropPresent ? `if (!node.dataset || !node.dataset.hasOwnProperty('${site.dataPropPresent}')) { return false; }` : ''}
      ${site.hasChildrenElements ? 'if (typeof node.childElementCount !== "number" || node.childElementCount < 1) { return false; }' : ''}
      ${site.subtitleSelector ? `if (typeof node.querySelector !== 'function' || !node.querySelector('${site.subtitleSelector}')) { return false; }` : ''}
      ${site.containsSelector ? `if (typeof node.querySelector !== 'function' || !node.querySelector('${site.containsSelector}')) { return false; }` : ''}
      return true;
    } else {
      return false;
    }`.replace(/^\s*\n/gm, ''));
  }

  clean(subtitleContainer) {
    let filtered = false;
    let subtitles = this.subtitleSelector ? subtitleContainer.querySelectorAll(this.subtitleSelector) : [subtitleContainer]; // Process subtitles

    subtitles.forEach(subtitle => {
      // innerText handles line feeds/spacing better, but is not available to #text nodes
      let textMethod = subtitle.nodeName === '#text' ? 'textContent' : 'innerText';
      let result = this.filter.replaceTextResult(subtitle[textMethod]);

      if (result.modified) {
        filtered = true;
        subtitle[textMethod] = result.filtered;
        this.mute(); // Mute the audio if we haven't already

        if (subtitle.nodeName === '#text') {
          this.lastFilteredNode = subtitle;
        }
      }
    }); // Subtitle display - 0: Show all, 1: Show only filtered, 2: Show only unfiltered, 3: Hide all

    switch (this.showSubtitles) {
      case 1:
        if (!filtered) {
          subtitles.forEach(subtitle => {
            subtitle.textContent = '';
          });
        }

        break;

      case 2:
        if (filtered) {
          subtitles.forEach(subtitle => {
            subtitle.textContent = '';
          });
        }

        break;

      case 3:
        subtitles.forEach(subtitle => {
          subtitle.textContent = '';
        });
        break;
    }

    if (filtered) {
      this.filter.updateCounterBadge();
    } // Update if modified

  }

  cleanYouTubeAutoSubs(node) {
    let result = this.filter.replaceTextResult(node.textContent);

    if (result.modified) {
      node.textContent = result.filtered;
      this.mute();
      this.unmuteDelay = null;
      this.filter.updateCounterBadge();
    } else {
      if (this.muted) {
        if (this.youTubeAutoSubsMin > 0) {
          let currentTime = document.getElementsByTagName('video')[0].currentTime;

          if (this.unmuteDelay == null) {
            // Start tracking unmuteDelay when next unfiltered word is found
            this.unmuteDelay = currentTime;
          } else {
            if (currentTime < this.unmuteDelay) {
              this.unmuteDelay = 0;
            } // Reset unmuteDelay if video reversed


            if (currentTime > this.unmuteDelay + this.youTubeAutoSubsMin) {
              // Unmute if its been long enough
              this.unmute();
            }
          }
        } else {
          // Unmute immediately if youTubeAutoSubsMin = 0
          this.unmute();
        }
      }
    }
  }

  getVideoTextTrack(video) {
    if (video.textTracks && video.textTracks.length > 0) {
      if (this.site.videoCueLanguage) {
        for (let i = 0; i < video.textTracks.length; i++) {
          if (video.textTracks[i].language == this.site.videoCueLanguage) {
            return video.textTracks[i];
          }
        }
      }

      return video.textTracks[0];
    }
  }

  mute(video) {
    if (!this.muted) {
      this.muted = true;

      switch (this.muteMethod) {
        case 0:
          // Mute tab
          chrome.runtime.sendMessage({
            mute: true
          });
          break;

        case 1:
          {
            // Mute video
            if (!video) {
              video = document.querySelector('video');
            }

            if (video && video.volume != null) {
              this.volume = video.volume; // Save original volume

              video.volume = 0;
            }

            break;
          }
      }
    }
  }

  playing(video) {
    return !!(video.currentTime > 0 && !video.paused && !video.ended && video.readyState > 2);
  }

  processCues(cues) {
    for (let i = 0; i < cues.length; i++) {
      let cue = cues[i];

      if (cue.hasOwnProperty('filtered')) {
        continue;
      }

      if (this.site.videoCueSync) {
        cue.startTime += this.site.videoCueSync;
        cue.endTime += this.site.videoCueSync;
      }

      cue.index = i;
      let result = this.filter.replaceTextResult(cue.text);

      if (result.modified) {
        cue.filtered = true;
        cue.originalText = cue.text;
        cue.text = result.filtered;
      } else {
        cue.filtered = false;
      }
    }
  }

  unmute(video) {
    if (this.muted) {
      this.muted = false;

      switch (this.muteMethod) {
        case 0:
          // Mute tab
          chrome.runtime.sendMessage({
            mute: false
          });
          break;

        case 1:
          {
            // Mute video
            if (!video) {
              video = document.querySelector('video');
            }

            if (video && video.volume != null) {
              video.volume = this.volume;
            }

            break;
          }
      }
    }
  }

  watchForVideo(instance) {
    let video = document.querySelector(instance.site.videoSelector);

    if (video && video.textTracks && instance.playing(video)) {
      let textTrack = instance.getVideoTextTrack(video);

      if (textTrack && !textTrack.oncuechange) {
        if (instance.showSubtitles == 3) {
          textTrack.mode = 'hidden';
        }

        textTrack.oncuechange = () => {
          if (textTrack.activeCues.length > 0) {
            let filtered = false;

            for (let i = 0; i < textTrack.activeCues.length; i++) {
              let activeCue = textTrack.activeCues[i];

              if (!activeCue.hasOwnProperty('filtered')) {
                let cues = textTrack.cues;
                instance.processCues(cues);
              }

              if (activeCue.filtered) {
                filtered = true;
              }
            }

            if (filtered) {
              instance.mute(video);

              switch (instance.showSubtitles) {
                case 1:
                  textTrack.mode = 'showing';
                  break;

                case 2:
                  textTrack.mode = 'hidden';
                  break;
              }
            } else {
              instance.unmute(video);

              switch (instance.showSubtitles) {
                case 1:
                  textTrack.mode = 'hidden';
                  break;

                case 2:
                  textTrack.mode = 'showing';
                  break;
              }
            }
          } else {
            // No active cues
            instance.unmute(video);
          }
        };
      }
    }
  }

  youTubeAutoSubsCurrentRow(node) {
    return !!(node.parentElement.parentElement == node.parentElement.parentElement.parentElement.lastChild);
  }

  youTubeAutoSubsNodeIsSubtitleText(node) {
    let captionWindow = document.querySelector('div.caption-window'); // YouTube Auto-gen subs

    return !!(captionWindow && captionWindow.contains(node));
  }

  youTubeAutoSubsPresent() {
    return !!document.querySelector('div.ytp-caption-window-rollup');
  }

  youTubeAutoSubsSupportedNode(node) {
    if (node.nodeName == '#text' && node.textContent != '') {
      return !!this.youTubeAutoSubsNodeIsSubtitleText(node);
    }

    return false;
  }

}

exports.default = WebAudio;

_defineProperty(WebAudio, "_videoModeDefaults", {
  videoInterval: 200,
  videoSelector: 'video'
});

_defineProperty(WebAudio, "sites", {
  'abc.go.com': {
    className: 'akamai-caption-text',
    tagName: 'DIV'
  },
  'app.plex.tv': {
    dataPropPresent: 'dialogueId',
    subtitleSelector: 'span > span',
    tagName: 'DIV'
  },
  'www.amazon.com': {
    subtitleSelector: 'span.timedTextBackground',
    tagName: 'P'
  },
  'www.dishanywhere.com': {
    className: 'bmpui-ui-subtitle-label',
    tagName: 'SPAN'
  },
  'www.fox.com': {
    className: 'jw-text-track-container',
    subtitleSelector: 'div.jw-text-track-cue',
    tagName: 'DIV'
  },
  'www.hulu.com': {
    className: 'caption-text-box',
    subtitleSelector: 'p',
    tagName: 'DIV'
  },
  'www.nbc.com': {
    className: 'ttr-line',
    subtitleSelector: 'span.ttr-cue',
    tagName: 'DIV'
  },
  'www.netflix.com': {
    className: 'player-timedtext-text-container',
    subtitleSelector: 'span',
    tagName: 'DIV'
  },
  'www.sonycrackle.com': {
    textParentSelector: 'div.clpp-subtitles-container'
  },
  'www.syfy.com': {
    className: 'ttr-line',
    subtitleSelector: 'span.ttr-cue',
    tagName: 'DIV'
  },
  'www.universalkids.com': {
    subtitleSelector: 'div.gwt-HTML',
    tagName: 'DIV'
  },
  'www.usanetwork.com': {
    className: 'ttr-line',
    subtitleSelector: 'span.ttr-cue',
    tagName: 'DIV'
  },
  'www.vudu.com': {
    subtitleSelector: 'span.subtitles',
    tagName: 'DIV'
  },
  'www.youtube.com': {
    className: 'caption-window',
    subtitleSelector: 'span.ytp-caption-segment',
    tagName: 'DIV'
  }
});

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _helper = __webpack_require__(0);

var _webConfig = _interopRequireDefault(__webpack_require__(1));

var _filter = __webpack_require__(5);

var _optionAuth = _interopRequireDefault(__webpack_require__(13));

var _dataMigration = _interopRequireDefault(__webpack_require__(4));

var _bookmarklet = _interopRequireDefault(__webpack_require__(14));

var _webAudio = _interopRequireDefault(__webpack_require__(7));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class OptionPage {
  constructor() {
    _defineProperty(this, "cfg", void 0);

    _defineProperty(this, "auth", void 0);
  }

  static closeModal(id) {
    OptionPage.hide(document.getElementById(id));
  }

  static configureConfirmModal(content = 'Are you sure?', title = 'Please Confirm', titleColor = 'w3-flat-peter-river') {
    let modalTitle = document.getElementById('confirmModalTitle');
    let modalContent = document.getElementById('confirmModalContent');
    let modalHeader = document.querySelector('#confirmModal header');
    modalTitle.innerText = title;
    modalContent.innerHTML = content;
    modalHeader.className = `w3-container ${titleColor}`;
  }

  static configureStatusModal(content, title, titleColor) {
    let modalTitle = document.getElementById('statusModalTitle');
    let modalContent = document.getElementById('statusModalContent');
    let modalHeader = document.querySelector('#statusModal header');
    modalTitle.innerText = title;
    modalContent.innerHTML = content;
    modalHeader.className = `w3-container ${titleColor}`;
  }

  static disableBtn(element) {
    element.classList.add('disabled');
    element.classList.add('w3-flat-silver');
  }

  static enableBtn(element) {
    element.classList.remove('disabled');
    element.classList.remove('w3-flat-silver');
  }

  static hide(element) {
    element.classList.remove('w3-show');
    element.classList.add('w3-hide');
  }

  static hideInputError(element) {
    element.classList.remove('w3-border-red');

    try {
      element.setCustomValidity('');
    } catch (e) {// If HTML5 validation not supported, the modal will suffice
    }
  }

  static hideStatus() {
    let notificationPanel = document.getElementById('notificationPanel');
    OptionPage.hide(notificationPanel);
  }

  static async load(instance) {
    instance.cfg = await _webConfig.default.build();
  }

  static openModal(id) {
    OptionPage.show(document.getElementById(id));
  }

  static show(element) {
    element.classList.remove('w3-hide');
    element.classList.add('w3-show');
  }

  static showErrorModal(content = 'The requested action failed. Please try again or contact support.', title = 'Error', titleColor = 'w3-red') {
    this.configureStatusModal(content, title, titleColor);
    OptionPage.openModal('statusModal');
  }

  static showInputError(element, message = '') {
    element.classList.add('w3-border-red');

    if (message) {
      try {
        element.setCustomValidity(message);
        element.reportValidity();
      } catch (e) {
        OptionPage.showWarningModal(message);
      }
    }
  }

  static showStatusModal(content = 'Status updated.', title = 'Status', titleColor = 'w3-flat-peter-river') {
    this.configureStatusModal(content, title, titleColor);
    OptionPage.openModal('statusModal');
  }

  static showWarningModal(content = 'Invalid input.', title = 'Warning', titleColor = 'w3-orange') {
    this.configureStatusModal(content, title, titleColor);
    OptionPage.openModal('statusModal');
  }

  advancedDomainList() {
    let advDomains = document.getElementById('advDomainSelect');
    let domainListHTML = '<option selected value="">Add...</option>';
    this.cfg.advancedDomains.forEach(domain => {
      domainListHTML += `<option value="${domain}">${domain}</option>`;
    });
    advDomains.innerHTML = domainListHTML;
    this.advancedDomainPopulate();
  }

  advancedDomainPopulate() {
    let advDomains = document.getElementById('advDomainSelect');
    let advDomainText = document.getElementById('advDomainText');
    let advDomainRemove = document.getElementById('advDomainRemove');
    OptionPage.hideInputError(advDomainText);
    advDomains.value !== '' ? OptionPage.enableBtn(advDomainRemove) : OptionPage.disableBtn(advDomainRemove);
    advDomainText.value = advDomains.value;
  }

  async advancedDomainRemove(evt) {
    if (evt.target.classList.contains('disabled')) return false;
    let advDomains = document.getElementById('advDomainSelect');
    option.cfg['advancedDomains'].splice(option.cfg['advancedDomains'].indexOf(advDomains.value), 1);
    if (await option.saveProp('advancedDomains')) this.advancedDomainList();
  }

  async advancedDomainSave(evt) {
    let advDomains = document.getElementById('advDomainSelect');
    let advDomainText = document.getElementById('advDomainText');
    let invalidMessage = 'Valid domain example: google.com or www.google.com';
    let success;

    if (advDomains.value == '') {
      // New record
      success = option.updateItemList(evt, advDomainText, 'advancedDomains', invalidMessage);
    } else {
      // Updating existing record
      success = option.updateItemList(evt, advDomainText, 'advancedDomains', invalidMessage, advDomains.value);
    }

    if (success) {
      if (await option.saveProp('advancedDomains')) this.advancedDomainList();
    }
  }

  configInlineToggle() {
    let input = document.getElementById('configInlineInput');
    let configText = document.getElementById('configText');

    if (input.checked) {
      OptionPage.show(configText);
      option.exportConfig();
    } else {
      OptionPage.hide(configText);
      configText.value = '';
    }
  }

  confirm(evt, action) {
    let ok = document.getElementById('confirmModalOK');
    ok.removeEventListener('click', importConfig);
    ok.removeEventListener('click', removeAllWords);
    ok.removeEventListener('click', restoreDefaults);
    ok.removeEventListener('click', setPassword);

    switch (action) {
      case 'importConfig':
        {
          OptionPage.configureConfirmModal('Are you sure you want to overwrite your existing settings?');
          ok.addEventListener('click', importConfig);
          break;
        }

      case 'removeAllWords':
        OptionPage.configureConfirmModal('Are you sure you want to remove all words?<br><br><i>(Note: The default words will return if no words are added.)</i>');
        ok.addEventListener('click', removeAllWords);
        break;

      case 'restoreDefaults':
        OptionPage.configureConfirmModal('Are you sure you want to restore defaults?');
        ok.addEventListener('click', restoreDefaults);
        break;

      case 'setPassword':
        {
          let passwordText = document.getElementById('setPassword');
          let passwordBtn = document.getElementById('setPasswordBtn');
          if (passwordBtn.classList.contains('disabled')) return false;
          let message = passwordText.value == '' ? 'Are you sure you want to remove the password?' : `Are you sure you want to set the password to '${passwordText.value}'?`;
          OptionPage.configureConfirmModal(message);
          ok.addEventListener('click', setPassword);
          break;
        }
    }

    OptionPage.openModal('confirmModal');
  }

  createBookmarklet() {
    let bookmarkletLink = document.getElementById('bookmarkletLink');
    let bookmarkletHostedURLInput = document.getElementById('bookmarkletHostedURL');
    OptionPage.hideInputError(bookmarkletHostedURLInput);

    if (bookmarkletHostedURLInput.checkValidity()) {
      let bookmarkletHostedURL = bookmarkletHostedURLInput.value;
      let bookmarklet = new _bookmarklet.default(bookmarkletHostedURL);
      bookmarkletLink.href = bookmarklet.destination();
      OptionPage.enableBtn(bookmarkletLink);
    } else {
      OptionPage.showInputError(bookmarkletHostedURLInput, 'Please enter a valid URL.');
      bookmarkletLink.href = '#';
      OptionPage.disableBtn(bookmarkletLink);
      return false;
    }
  }

  disabledDomainList() {
    let disabledDomains = document.getElementById('disabledDomainSelect');
    let domainListHTML = '<option selected value="">Add...</option>';
    this.cfg.disabledDomains.forEach(domain => {
      domainListHTML += `<option value="${domain}">${domain}</option>`;
    });
    disabledDomains.innerHTML = domainListHTML;
    this.disabledDomainPopulate();
  }

  disabledDomainPopulate() {
    let disabledDomains = document.getElementById('disabledDomainSelect');
    let disabledDomainText = document.getElementById('disabledDomainText');
    let disabledDomainRemove = document.getElementById('disabledDomainRemove');
    OptionPage.hideInputError(disabledDomainText);
    disabledDomains.value !== '' ? OptionPage.enableBtn(disabledDomainRemove) : OptionPage.disableBtn(disabledDomainRemove);
    disabledDomainText.value = disabledDomains.value;
  }

  async disabledDomainRemove(evt) {
    if (evt.target.classList.contains('disabled')) return false;
    let disabledDomains = document.getElementById('disabledDomainSelect');
    option.cfg['disabledDomains'].splice(option.cfg['disabledDomains'].indexOf(disabledDomains.value), 1);
    if (await option.saveProp('disabledDomains')) this.disabledDomainList();
  }

  async disabledDomainSave(evt) {
    let disabledDomains = document.getElementById('disabledDomainSelect');
    let disabledDomainText = document.getElementById('disabledDomainText');
    let invalidMessage = 'Valid domain example: google.com or www.google.com';
    let success;

    if (disabledDomains.value == '') {
      // New record
      success = option.updateItemList(evt, disabledDomainText, 'disabledDomains', invalidMessage);
    } else {
      // Updating existing record
      success = option.updateItemList(evt, disabledDomainText, 'disabledDomains', invalidMessage, disabledDomains.value);
    }

    if (success) {
      if (await option.saveProp('disabledDomains')) this.disabledDomainList();
    }
  }

  async exportBookmarkletFile() {
    let code = await _bookmarklet.default.injectConfig(option.cfg);
    (0, _helper.exportToFile)(code, 'apfBookmarklet.js');
  }

  exportConfig() {
    let input = document.getElementById('configInlineInput');

    if (input.checked) {
      // inline editor
      let configText = document.getElementById('configText');
      configText.value = JSON.stringify(this.cfg, null, 2);
    } else {
      let date = new Date();
      let today = `${date.getUTCFullYear()}-${('0' + (date.getUTCMonth() + 1)).slice(-2)}-${('0' + (date.getUTCDate() + 1)).slice(-2)}`;
      (0, _helper.exportToFile)(JSON.stringify(this.cfg, null, 2), `apf-backup-${today}.json`);
    }
  }

  async importConfig(e) {
    let input = document.getElementById('configInlineInput');

    if (input.checked) {
      // inline editor
      let configText = document.getElementById('configText');
      this.importConfigText(configText.value);
    } else {
      let importFileInput = document.getElementById('importFileInput');
      importFileInput.click();
    }
  }

  async importConfigFile(e) {
    let file = e.target.files[0];
    let importFileInput = document.getElementById('importFileInput');
    let fileText = await (0, _helper.readFile)(file);
    option.importConfigText(fileText);
    importFileInput.value = '';
  }

  async importConfigText(cfg) {
    let self = this;

    try {
      let importedCfg = new _webConfig.default(JSON.parse(cfg));
      let migration = new _dataMigration.default(importedCfg);
      migration.runImportMigrations();
      let resetSuccess = await self.restoreDefaults(null, true);

      if (resetSuccess) {
        self.cfg = importedCfg;
        let error = await self.cfg.save();

        if (!error) {
          OptionPage.showStatusModal('Settings imported successfully.');
          self.init();
        } else {
          OptionPage.showErrorModal('Failed to import settings.');
        }
      }
    } catch (e) {
      OptionPage.showErrorModal('Failed to import settings.');
    }
  }

  async init() {
    let self = this;
    await OptionPage.load(self);
    if (!self.auth) self.auth = new _optionAuth.default(self.cfg.password); // @ts-ignore: Type WebConfig is not assignable to type Config

    filter.cfg = option.cfg; // console.log('Password:', cfg.password, 'Authenticated:', authenticated); // DEBUG Password

    if (self.cfg.password && !self.auth.authenticated) {
      // console.log('Prompt for password'); // DEBUG Password
      OptionPage.openModal('passwordModal');
      document.getElementById('passwordInput').focus();
    } else {
      OptionPage.show(document.getElementById('main'));
    }

    self.populateOptions();
  }

  populateAudio() {
    let muteAudioInput = document.getElementById('muteAudio');
    let muteAudioOnlyInput = document.getElementById('muteAudioOnly');
    let selectedMuteMethod = document.querySelector(`input[name=audioMuteMethod][value='${this.cfg.muteMethod}']`);
    let selectedshowSubtitle = document.querySelector(`input[name=audioShowSubtitles][value='${this.cfg.showSubtitles}']`);
    let muteAudioOptionsContainer = document.getElementById('muteAudioOptionsContainer');
    let audioYouTubeAutoSubsMin = document.getElementById('audioYouTubeAutoSubsMin');
    let customAudioSitesTextArea = document.getElementById('customAudioSitesText');
    muteAudioInput.checked = this.cfg.muteAudio;
    muteAudioOnlyInput.checked = this.cfg.muteAudioOnly;
    this.cfg.muteAudio ? OptionPage.show(muteAudioOptionsContainer) : OptionPage.hide(muteAudioOptionsContainer);
    selectedMuteMethod.checked = true;
    selectedshowSubtitle.checked = true;
    audioYouTubeAutoSubsMin.value = this.cfg.youTubeAutoSubsMin.toString();
    customAudioSitesTextArea.value = this.cfg.customAudioSites ? JSON.stringify(this.cfg.customAudioSites, null, 2) : '';
  }

  populateConfig() {
    this.auth.setPasswordButton(option);
  }

  async populateOptions() {
    filter.init();
    this.populateSettings();
    this.populateWordsList();
    this.advancedDomainList();
    this.disabledDomainList();
    this.populateAudio();
    this.populateConfig();
    this.populateTest();
  }

  populateSettings() {
    this.updateFilterOptions(); // Settings

    let selectedFilter = document.getElementById(`filter${_webConfig.default._filterMethodNames[option.cfg.filterMethod]}`);
    let showCounter = document.getElementById('showCounter');
    let showSummary = document.getElementById('showSummary');
    let showUpdateNotification = document.getElementById('showUpdateNotification');
    let globalMatchMethodSelect = document.getElementById('globalMatchMethodSelect');
    let filterWordList = document.getElementById('filterWordList');
    selectedFilter.checked = true;
    (0, _helper.dynamicList)(_webConfig.default._matchMethodNames.slice(0, -1), 'globalMatchMethodSelect');
    globalMatchMethodSelect.selectedIndex = this.cfg.globalMatchMethod;
    showCounter.checked = this.cfg.showCounter;
    showSummary.checked = this.cfg.showSummary;
    showUpdateNotification.checked = this.cfg.showUpdateNotification;
    filterWordList.checked = this.cfg.filterWordList; // Censor Settings

    let preserveFirst = document.getElementById('preserveFirst');
    let preserveLast = document.getElementById('preserveLast');
    let censorCharacterSelect = document.getElementById('censorCharacterSelect');
    let censorFixedLengthSelect = document.getElementById('censorFixedLengthSelect');
    preserveFirst.checked = this.cfg.preserveFirst;
    preserveLast.checked = this.cfg.preserveLast;
    censorCharacterSelect.value = this.cfg.censorCharacter;
    censorFixedLengthSelect.selectedIndex = this.cfg.censorFixedLength; // Substitution Settings

    let preserveCase = document.getElementById('preserveCase');
    let substitutionMark = document.getElementById('substitutionMark');
    preserveCase.checked = this.cfg.preserveCase;
    substitutionMark.checked = this.cfg.substitutionMark; // Default Settings

    let defaultWordRepeat = document.getElementById('defaultWordRepeat');
    let defaultWordMatchMethodSelect = document.getElementById('defaultWordMatchMethodSelect');
    defaultWordRepeat.checked = this.cfg.defaultWordRepeat;
    let defaultWordSubstitution = document.getElementById('defaultWordSubstitutionText');
    defaultWordSubstitution.value = this.cfg.defaultSubstitution;
    let defaultWordMatchMethodSelectHTML = '';

    for (let i = 0; i < _webConfig.default._matchMethodNames.slice(0, -2).length; i++) {
      defaultWordMatchMethodSelectHTML += '<option value="' + _webConfig.default._matchMethodNames[i] + '">' + _webConfig.default._matchMethodNames[i] + '</option>';
    }

    defaultWordMatchMethodSelect.innerHTML = defaultWordMatchMethodSelectHTML;
    defaultWordMatchMethodSelect.selectedIndex = this.cfg.defaultWordMatchMethod;
  }

  populateTest() {
    let testText = document.getElementById('testText');
    let filteredTestText = document.getElementById('filteredTestText');

    if (testText.value === '') {
      filteredTestText.innerText = 'Enter some text above to test the filter...';
    } else {
      filteredTestText.innerText = filter.replaceText(testText.value);
    }
  }

  populateWord() {
    let wordList = document.getElementById('wordList');
    let wordText = document.getElementById('wordText');
    let wordMatchRepeated = document.getElementById('wordMatchRepeated');
    let substitutionText = document.getElementById('substitutionText');
    let wordRemove = document.getElementById('wordRemove');
    let word = wordList.value;

    if (word == '') {
      // New word
      wordText.value = '';
      OptionPage.disableBtn(wordRemove);
      let selectedMatchMethod = document.getElementById(`wordMatch${_webConfig.default._matchMethodNames[option.cfg.defaultWordMatchMethod]}`);
      selectedMatchMethod.checked = true;
      wordMatchRepeated.checked = option.cfg.defaultWordRepeat;
      substitutionText.value = '';
    } else {
      // Existing word
      OptionPage.enableBtn(wordRemove);
      let wordCfg = option.cfg.words[word];
      wordText.value = word;
      let selectedMatchMethod = document.getElementById(`wordMatch${_webConfig.default._matchMethodNames[wordCfg.matchMethod]}`);
      selectedMatchMethod.checked = true;
      wordMatchRepeated.checked = wordCfg.repeat;
      substitutionText.value = wordCfg.sub;
    }
  }

  populateWordsList() {
    filter.init();
    let wordList = document.getElementById('wordList');
    let wordListHTML = '<option selected value="">Add...</option>'; // Workaround for Remove filter (use censor)

    let filterMethod = filter.cfg.filterMethod;

    if (filterMethod === 2) {
      filter.cfg.filterMethod = 0;
      filter.init();
    }

    Object.keys(option.cfg.words).sort().forEach(word => {
      let filteredWord = word;

      if (filter.cfg.filterWordList) {
        if (filter.cfg.words[word].matchMethod == 4) {
          // Regexp
          filteredWord = filter.cfg.words[word].sub || filter.cfg.defaultSubstitution;
        } else {
          filteredWord = filter.replaceText(word, false);
        }
      }

      wordListHTML += `<option value="${word}" data-filtered="${filteredWord}">${(0, _helper.escapeHTML)(filteredWord)}</option>`;
    }); // Workaround for Remove filter (use censor)

    if (filterMethod === 2) {
      filter.cfg.filterMethod = filterMethod;
      filter.init();
    }

    wordList.innerHTML = wordListHTML;
    this.populateWord();
  }

  removeAllWords(evt) {
    this.cfg.words = {};
    let wordList = document.getElementById('wordList');
    wordList.selectedIndex = 0;
    this.populateWordsList();
  }

  async removeWord(evt) {
    if (evt.target.classList.contains('disabled')) return false;
    let wordList = document.getElementById('wordList');
    let word = wordList.value;
    delete this.cfg.words[word];
    let success = await this.saveOptions(evt);

    if (success) {
      // Update states and Reset word form
      wordList.selectedIndex = 0;
      this.populateWordsList();
    }
  }

  async restoreDefaults(evt, silent = false) {
    this.exportConfig();
    let error = await this.cfg.reset();

    if (error) {
      OptionPage.showErrorModal('Error restoring defaults!');
      return false;
    } else {
      if (!silent) OptionPage.showStatusModal('Default settings restored');
      this.init();
      return true;
    }
  }

  async saveCustomAudioSites() {
    let self = this;
    let customAudioSitesTextArea = document.getElementById('customAudioSitesText');

    try {
      let text = customAudioSitesTextArea.value;
      self.cfg.customAudioSites = text == '' ? null : JSON.parse(text);

      if (await option.saveProp('customAudioSites')) {
        OptionPage.showStatusModal('Custom Audio Sites saved.');
      }
    } catch (e) {
      OptionPage.showErrorModal('Invalid custom audio sites');
    }
  }

  async saveOptions(evt) {
    let self = this; // Gather current settings

    let censorCharacterSelect = document.getElementById('censorCharacterSelect');
    let censorFixedLengthSelect = document.getElementById('censorFixedLengthSelect');
    let defaultWordMatchMethodSelect = document.getElementById('defaultWordMatchMethodSelect');
    let defaultWordRepeat = document.getElementById('defaultWordRepeat');
    let globalMatchMethodSelect = document.getElementById('globalMatchMethodSelect');
    let preserveCase = document.getElementById('preserveCase');
    let preserveFirst = document.getElementById('preserveFirst');
    let preserveLast = document.getElementById('preserveLast');
    let showCounter = document.getElementById('showCounter');
    let showSummary = document.getElementById('showSummary');
    let showUpdateNotification = document.getElementById('showUpdateNotification');
    let filterWordList = document.getElementById('filterWordList');
    let substitutionMark = document.getElementById('substitutionMark');
    let defaultWordSubstitution = document.getElementById('defaultWordSubstitutionText');
    let muteAudioInput = document.getElementById('muteAudio');
    let muteAudioOnlyInput = document.getElementById('muteAudioOnly');
    let muteMethodInput = document.querySelector('input[name="audioMuteMethod"]:checked');
    let showSubtitlesInput = document.querySelector('input[name="audioShowSubtitles"]:checked');
    self.cfg.censorCharacter = censorCharacterSelect.value;
    self.cfg.censorFixedLength = censorFixedLengthSelect.selectedIndex;
    self.cfg.defaultWordMatchMethod = defaultWordMatchMethodSelect.selectedIndex;
    self.cfg.defaultWordRepeat = defaultWordRepeat.checked;
    self.cfg.globalMatchMethod = globalMatchMethodSelect.selectedIndex;
    self.cfg.preserveCase = preserveCase.checked;
    self.cfg.preserveFirst = preserveFirst.checked;
    self.cfg.preserveLast = preserveLast.checked;
    self.cfg.showCounter = showCounter.checked;
    self.cfg.showSummary = showSummary.checked;
    self.cfg.showUpdateNotification = showUpdateNotification.checked;
    self.cfg.filterWordList = filterWordList.checked;
    self.cfg.substitutionMark = substitutionMark.checked;
    self.cfg.defaultSubstitution = defaultWordSubstitution.value.trim().toLowerCase();
    self.cfg.muteAudio = muteAudioInput.checked;
    self.cfg.muteAudioOnly = muteAudioOnlyInput.checked;
    self.cfg.muteMethod = parseInt(muteMethodInput.value);
    self.cfg.showSubtitles = parseInt(showSubtitlesInput.value); // Save settings

    let error = await self.cfg.save();

    if (error) {
      OptionPage.showErrorModal('Settings not saved! Please try again.');
      return false;
    } else {
      self.init();
      return true;
    }
  }

  async saveProp(prop) {
    let error = await option.cfg.save(prop);

    if (error) {
      OptionPage.showErrorModal();
      return false;
    }

    return true;
  }

  async saveWord(evt) {
    let wordList = document.getElementById('wordList');
    let wordText = document.getElementById('wordText');
    let wordMatchRepeated = document.getElementById('wordMatchRepeated');
    let substitutionText = document.getElementById('substitutionText');
    let selectedMatchMethod = document.querySelector('input[name="wordMatchMethod"]:checked');
    let word = wordText.value.trim().toLowerCase();
    let sub = substitutionText.value.trim().toLowerCase();
    let added = true;

    if (word == '') {
      OptionPage.showInputError(wordText, 'Please enter a valid word/phrase.');
      return false;
    } // Make sure word and substitution are different
    // TODO: More in-depth checking might be needed


    if (word == sub) {
      OptionPage.showInputError(substitutionText, 'Word and substitution must be different.');
      return false;
    }

    if (wordText.checkValidity()) {
      let wordOptions = {
        matchMethod: _webConfig.default._matchMethodNames.indexOf(selectedMatchMethod.value),
        repeat: wordMatchRepeated.checked,
        sub: sub
      };

      if (wordList.value === '') {
        // New record
        // console.log('Adding new word: ', word, wordOptions); // DEBUG
        added = this.cfg.addWord(word, wordOptions);
      } else {
        // Updating existing record
        let originalWord = wordList.value;

        if (originalWord == word) {
          // Word options changed
          // console.log('Modifying existing word options: ', word, wordOptions); // DEBUG
          this.cfg.words[word] = wordOptions;
        } else {
          // Existing word modified
          // console.log('Modifying existing word: ', word, wordOptions); // DEBUG
          added = this.cfg.addWord(word, wordOptions);

          if (added) {
            delete this.cfg.words[originalWord];
          } else {
            OptionPage.showInputError(wordText, `'${word}' already in list.`);
          }
        }
      }

      if (added) {
        let success = await this.saveOptions(evt);

        if (!success) {
          OptionPage.showErrorModal();
          return false;
        } // Update states and Reset word form


        filter.init();
        wordList.selectedIndex = 0;
        this.populateWordsList();
      }
    } else {
      OptionPage.showInputError(wordText, 'Please enter a valid word/phrase.');
    }
  }

  async selectFilterMethod(evt) {
    option.cfg.filterMethod = _webConfig.default._filterMethodNames.indexOf(evt.target.value);
    if (await option.saveProp('filterMethod')) this.init();
  }

  showSupportedAudioSites() {
    let title = document.querySelector('#supportedAudioSitesModal h5.modalTitle');
    let content = document.querySelector('#supportedAudioSitesModal div.modalContent');
    let sites = [];
    let sortedSites = Object.keys(_webAudio.default.sites).sort(function (a, b) {
      let domainA = a.match(/\w*\.\w*$/)[0];
      let domainB = b.match(/\w*\.\w*$/)[0];
      return domainA < domainB ? -1 : domainA > domainB ? 1 : 0;
    });
    sortedSites.forEach(site => {
      sites.push(`<li><a href="https://${site}" target="_blank">${site}</a></li>`);
    });
    title.textContent = 'Supported Audio Sites';
    content.innerHTML = `<ul>${sites.join('\n')}</ul>`;
    OptionPage.openModal('supportedAudioSitesModal');
  }

  switchPage(evt) {
    let currentTab = document.querySelector(`#menu a.${OptionPage.activeClass}`);
    let newTab = evt.target;

    if (newTab.classList.contains('donationTab')) {
      return false;
    }

    currentTab.classList.remove(OptionPage.activeClass);
    newTab.classList.add(OptionPage.activeClass);
    let currentPage = document.getElementById(currentTab.innerText.toLowerCase() + 'Page');
    let newPage = document.getElementById(newTab.innerText.toLowerCase() + 'Page');
    OptionPage.hide(currentPage);
    OptionPage.show(newPage);

    switch (newTab.innerText.toLowerCase()) {
      case 'test':
        document.getElementById('testText').focus();
        break;
    }
  }

  updateFilterOptions() {
    // Show/hide options as needed
    switch (this.cfg.filterMethod) {
      case 0:
        // Censor
        OptionPage.show(document.getElementById('censorSettings'));
        OptionPage.hide(document.getElementById('substitutionSettings'));
        OptionPage.show(document.getElementById('globalMatchMethod'));
        OptionPage.hide(document.getElementById('wordSubstitution'));
        break;

      case 1:
        // Substitution
        OptionPage.hide(document.getElementById('censorSettings'));
        OptionPage.show(document.getElementById('substitutionSettings'));
        OptionPage.show(document.getElementById('globalMatchMethod'));
        OptionPage.show(document.getElementById('wordSubstitution'));
        break;

      case 2:
        // Remove
        OptionPage.hide(document.getElementById('censorSettings'));
        OptionPage.hide(document.getElementById('substitutionSettings'));
        OptionPage.hide(document.getElementById('globalMatchMethod'));
        OptionPage.hide(document.getElementById('wordSubstitution'));
        break;
    }
  }

  updateItemList(evt, input, attr, invalidMessage, original = '') {
    let item = input.value.trim().toLowerCase();

    if (item == '') {
      // No data
      OptionPage.showInputError(input, 'Please enter a value.');
      return false;
    } else {
      if (input.checkValidity()) {
        OptionPage.hideInputError(input);

        if (!option.cfg[attr].includes(item)) {
          if (original != '' && option.cfg[attr].includes(original)) {
            // Update existing record (remove it before adding the new record)
            option.cfg[attr].splice(option.cfg[attr].indexOf(original), 1);
          } // Save new record


          option.cfg[attr].push(item);
          option.cfg[attr] = option.cfg[attr].sort();
          return true;
        } else {
          OptionPage.showInputError(input, 'Already in list.');
          return false;
        }
      } else {
        OptionPage.showInputError(input, invalidMessage);
        return false;
      }
    }
  }

  async updateYouTubeAutoMin(target) {
    OptionPage.hideInputError(target);

    if (target.checkValidity()) {
      this.cfg.youTubeAutoSubsMin = parseFloat(target.value);
      await option.saveProp('youTubeAutoSubsMin');
    } else {
      OptionPage.showInputError(target, 'Please enter a valid number of seconds.');
    }
  }

}

exports.default = OptionPage;

_defineProperty(OptionPage, "activeClass", 'w3-flat-belize-hole');

let filter = new _filter.Filter();
let option = new OptionPage(); ////
// Events
// Functions

function importConfig(e) {
  option.importConfig(e);
}

function removeAllWords(e) {
  option.removeAllWords(e);
}

function restoreDefaults(e) {
  option.restoreDefaults(e);
}

function setPassword(e) {
  option.auth.setPassword(option);
} // Add event listeners to DOM


window.addEventListener('load', e => {
  option.init();
});
document.querySelectorAll('#menu a').forEach(el => {
  el.addEventListener('click', e => {
    option.switchPage(e);
  });
}); // Modals

document.getElementById('submitPassword').addEventListener('click', e => {
  option.auth.authenticate(e);
});
document.getElementById('confirmModalOK').addEventListener('click', e => {
  OptionPage.closeModal('confirmModal');
});
document.getElementById('confirmModalCancel').addEventListener('click', e => {
  OptionPage.closeModal('confirmModal');
});
document.getElementById('statusModalOK').addEventListener('click', e => {
  OptionPage.closeModal('statusModal');
});
document.querySelector('#supportedAudioSitesModal button.modalOK').addEventListener('click', e => {
  OptionPage.closeModal('supportedAudioSitesModal');
}); // Settings

document.querySelectorAll('#filterMethod input').forEach(el => {
  el.addEventListener('click', e => {
    option.selectFilterMethod(e);
  });
});
document.getElementById('censorCharacterSelect').addEventListener('click', e => {
  option.saveOptions(e);
});
document.getElementById('censorFixedLengthSelect').addEventListener('click', e => {
  option.saveOptions(e);
});
document.getElementById('defaultWordMatchMethodSelect').addEventListener('click', e => {
  option.saveOptions(e);
});
document.getElementById('defaultWordRepeat').addEventListener('click', e => {
  option.saveOptions(e);
});
document.getElementById('globalMatchMethodSelect').addEventListener('click', e => {
  option.saveOptions(e);
});
document.getElementById('preserveCase').addEventListener('click', e => {
  option.saveOptions(e);
});
document.getElementById('preserveFirst').addEventListener('click', e => {
  option.saveOptions(e);
});
document.getElementById('preserveLast').addEventListener('click', e => {
  option.saveOptions(e);
});
document.getElementById('showCounter').addEventListener('click', e => {
  option.saveOptions(e);
});
document.getElementById('showSummary').addEventListener('click', e => {
  option.saveOptions(e);
});
document.getElementById('showUpdateNotification').addEventListener('click', e => {
  option.saveOptions(e);
});
document.getElementById('filterWordList').addEventListener('click', e => {
  option.saveOptions(e);
});
document.getElementById('substitutionMark').addEventListener('click', e => {
  option.saveOptions(e);
});
document.getElementById('defaultWordSubstitutionText').addEventListener('change', e => {
  option.saveOptions(e);
}); // Words/Phrases

document.getElementById('wordList').addEventListener('click', e => {
  option.populateWord();
});
document.getElementById('wordText').addEventListener('input', e => {
  OptionPage.hideInputError(e.target);
});
document.getElementById('wordSave').addEventListener('click', e => {
  option.saveWord(e);
});
document.getElementById('wordRemove').addEventListener('click', e => {
  option.removeWord(e);
});
document.getElementById('wordRemoveAll').addEventListener('click', e => {
  option.confirm(e, 'removeAllWords');
}); // Domains

document.getElementById('advDomainSelect').addEventListener('change', e => {
  option.advancedDomainPopulate();
});
document.getElementById('advDomainText').addEventListener('input', e => {
  OptionPage.hideInputError(e.target);
});
document.getElementById('advDomainSave').addEventListener('click', e => {
  option.advancedDomainSave(e);
});
document.getElementById('advDomainRemove').addEventListener('click', e => {
  option.advancedDomainRemove(e);
});
document.getElementById('disabledDomainSelect').addEventListener('change', e => {
  option.disabledDomainPopulate();
});
document.getElementById('disabledDomainText').addEventListener('input', e => {
  OptionPage.hideInputError(e.target);
});
document.getElementById('disabledDomainSave').addEventListener('click', e => {
  option.disabledDomainSave(e);
});
document.getElementById('disabledDomainRemove').addEventListener('click', e => {
  option.disabledDomainRemove(e);
}); // Audio

document.getElementById('muteAudio').addEventListener('click', e => {
  option.saveOptions(e);
});
document.getElementById('supportedAudioSites').addEventListener('click', e => {
  option.showSupportedAudioSites();
});
document.getElementById('muteAudioOnly').addEventListener('click', e => {
  option.saveOptions(e);
});
document.querySelectorAll('#audioMuteMethod input').forEach(el => {
  el.addEventListener('click', e => {
    option.saveOptions(e);
  });
});
document.querySelectorAll('#audioSubtitleSelection input').forEach(el => {
  el.addEventListener('click', e => {
    option.saveOptions(e);
  });
});
document.getElementById('audioYouTubeAutoSubsMin').addEventListener('input', e => {
  option.updateYouTubeAutoMin(e.target);
});
document.getElementById('customAudioSitesSave').addEventListener('click', e => {
  option.saveCustomAudioSites();
}); // Bookmarklet

document.getElementById('bookmarkletFile').addEventListener('click', e => {
  option.exportBookmarkletFile();
});
document.getElementById('bookmarkletHostedURL').addEventListener('input', e => {
  option.createBookmarklet();
}); // Config

document.getElementById('configInlineInput').addEventListener('click', e => {
  option.configInlineToggle();
});
document.getElementById('importFileInput').addEventListener('change', e => {
  option.importConfigFile(e);
});
document.getElementById('configReset').addEventListener('click', e => {
  option.confirm(e, 'restoreDefaults');
});
document.getElementById('configExport').addEventListener('click', e => {
  option.exportConfig();
});
document.getElementById('configImport').addEventListener('click', e => {
  option.confirm(e, 'importConfig');
});
document.getElementById('setPassword').addEventListener('input', e => {
  option.auth.setPasswordButton(option);
});
document.getElementById('setPasswordBtn').addEventListener('click', e => {
  option.confirm(e, 'setPassword');
}); // Test

document.getElementById('testText').addEventListener('input', e => {
  option.populateTest();
});

/***/ }),
/* 9 */,
/* 10 */,
/* 11 */,
/* 12 */,
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _optionPage = _interopRequireDefault(__webpack_require__(8));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class OptionAuth {
  authenticate(evt) {
    let passwordInput = document.getElementById('passwordInput');

    if (passwordInput.value == this.password) {
      this.authenticated = true;

      _optionPage.default.closeModal('passwordModal');

      _optionPage.default.show(document.getElementById('main'));

      _optionPage.default.hideInputError(passwordInput);
    } else {
      _optionPage.default.showInputError(passwordInput);
    }
  }

  constructor(password) {
    _defineProperty(this, "authenticated", void 0);

    _defineProperty(this, "password", void 0);

    this.password = password;
    this.authenticated = false;
  }

  setPassword(optionPage) {
    var password = document.getElementById('setPassword');
    optionPage.cfg.password = password.value;
    optionPage.saveProp('password');
    password.value = '';
    this.setPasswordButton(optionPage);
  }

  setPasswordButton(optionPage) {
    let passwordText = document.getElementById('setPassword');
    let passwordBtn = document.getElementById('setPasswordBtn');

    if (optionPage.cfg.password) {
      // Password already set
      _optionPage.default.enableBtn(passwordBtn);

      if (passwordText.value) {
        // Password field filled
        passwordBtn.innerText = 'SET';
      } else {
        // Empty password field
        passwordBtn.innerText = 'REMOVE';
      }
    } else {
      // Password not already set
      passwordBtn.innerText = 'SET';

      if (passwordText.value) {
        // Password field filled
        _optionPage.default.enableBtn(passwordBtn);
      } else {
        // Empty password field
        _optionPage.default.disableBtn(passwordBtn);
      }
    }
  }

}

exports.default = OptionAuth;

/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class Bookmarklet {
  static dropboxDownloadURL(url) {
    let match = url.match(Bookmarklet.dropboxRegExp);

    if (match) {
      return url.replace(/\/www\./, '/dl.').replace(/\?dl=0/, '?raw=1');
    }

    return url;
  }

  static gitHubGistDownloadURL(url) {
    let match = url.match(Bookmarklet.gitHubGistRegExp);

    if (match && match[1] && match[2]) {
      // return `https://gist.githubusercontent.com/${match[1]}/${match[2]}/raw`; // Have to use a CDN
      return `https://cdn.statically.com/gist/${match[1]}/${match[2]}/raw/apfBookmarklet.js?env=dev`;
    }

    return url;
  }

  static googleDriveDownloadURL(url) {
    let match = url.match(Bookmarklet.googleDriveRegExp);

    if (match && match[1]) {
      return `https://drive.google.com/uc?export=view&id=${match[1]}`;
    }

    return url;
  }

  static processDownloadURL(url) {
    url = Bookmarklet.gitHubGistDownloadURL(url);
    url = Bookmarklet.googleDriveDownloadURL(url);
    url = Bookmarklet.dropboxDownloadURL(url);
    return url;
  }

  static async injectConfig(config = null) {
    const prefix = '/* @preserve - Start User Config */';
    const postfix = '/* @preserve - End User Config */';
    const configRegExp = new RegExp(`${prefix.replace(/[\/\*]/g, '\\$&')}[\\S\\s]\*${postfix.replace(/[\/\*]/g, '\\$&')}`, 'm');
    const origURL = './bookmarkletFilter.js';
    let response = await fetch(origURL);
    let code = await response.text();
    let cfgCode = code.match(configRegExp).toString();

    try {
      let variable = cfgCode.match(/^var ([a-z])=/m)[1];

      if (variable.match(/^[a-z]$/)) {
        return code.replace(configRegExp, `${prefix}\nvar ${variable}=${JSON.stringify(config)}\n${postfix}`);
      } else {
        throw 'Unable to set user config - using defaults';
      }
    } catch (e) {
      window.alert('Unable to read config - using defaults');
      return code;
    }
  }

  constructor(url) {
    _defineProperty(this, "hostedUrl", void 0);

    this.hostedUrl = Bookmarklet.processDownloadURL(url);
  }

  destination() {
    let prefix = '(function(){if(!document.querySelector("script.apfBookmarklet")){let apfScriptEl=document.body.appendChild(document.createElement("script"));apfScriptEl.src="';
    let postfix = '";apfScriptEl.className="apfBookmarklet";}})()';
    return 'javascript:' + encodeURIComponent(prefix + this.hostedUrl + postfix);
  }

}

exports.default = Bookmarklet;

_defineProperty(Bookmarklet, "dropboxRegExp", /^https:\/\/www\.dropbox\.com\/[a-z]\/\w+?\/[\w\-\.]+?\?dl=0$/);

_defineProperty(Bookmarklet, "gitHubGistRegExp", /^https:\/\/gist\.github\.com\/([\w\-]+?)\/([\w\-]+?)$/);

_defineProperty(Bookmarklet, "googleDriveRegExp", /^https:\/\/drive\.google\.com\/file\/[a-z]\/(.+?)\/view/);

/***/ })
/******/ ]);